import { storage } from "./storage";
import type { Integration, InsertCapacityData, InsertSyncLog } from "@shared/schema";

export class IntegrationService {
  
  /**
   * Syncs capacity data from a TMS/WMS system
   */
  static async syncCapacityData(integrationId: string): Promise<void> {
    const integration = await storage.getIntegration(integrationId);
    if (!integration) {
      throw new Error(`Integration ${integrationId} not found`);
    }

    if (integration.status !== "active") {
      throw new Error(`Integration ${integrationId} is not active`);
    }

    // Start sync log
    const syncLog = await storage.createSyncLog({
      integrationId,
      operation: "sync",
      status: "pending",
      recordsProcessed: 0,
    });

    try {
      // Update integration status to indicate sync in progress
      await storage.updateIntegrationStatus(integrationId, "active");

      const capacityRecords = await this.fetchCapacityFromAPI(integration);
      
      let recordsCreated = 0;
      let recordsUpdated = 0;
      let errorCount = 0;

      for (const record of capacityRecords) {
        try {
          // Check if record already exists
          const existingData = await storage.getCapacityData(integrationId);
          const exists = existingData.find(d => d.externalId === record.externalId);

          if (exists) {
            recordsUpdated++;
          } else {
            await storage.createCapacityData({
              ...record,
              integrationId,
            });
            recordsCreated++;
          }
        } catch (error) {
          console.error("Error processing capacity record:", error);
          errorCount++;
        }
      }

      // Update sync log with completion details
      await storage.updateSyncLogCompletion(syncLog.id, "success", {
        recordsProcessed: capacityRecords.length,
        recordsCreated,
        recordsUpdated,
        errorCount,
        completedAt: new Date().toISOString(),
      });

      // Update integration last sync time
      await storage.updateIntegrationLastSync(integrationId);

    } catch (error: any) {
      console.error("Sync failed:", error);
      
      await storage.updateIntegrationStatus(integrationId, "error", error.message);
      await storage.updateSyncLogCompletion(syncLog.id, "error", {
        error: error.message,
        completedAt: new Date().toISOString(),
      });
      
      throw error;
    }
  }

  /**
   * Fetches capacity data from external API
   */
  private static async fetchCapacityFromAPI(integration: Integration): Promise<InsertCapacityData[]> {
    if (!integration.apiEndpoint || !integration.apiKey) {
      throw new Error("Integration missing API configuration");
    }

    // This is a placeholder for actual API integration
    // In a real implementation, you would:
    // 1. Make HTTP requests to the TMS/WMS API
    // 2. Parse the response data
    // 3. Transform it to match your schema
    
    // For demonstration, we'll create some mock data based on integration type
    const mockData: InsertCapacityData[] = [];
    
    if (integration.type === "tms") {
      // Mock TMS capacity data
      mockData.push({
        integrationId: integration.id,
        externalId: `ext_${Date.now()}_1`,
        serviceType: "ftl",
        origin: "Chicago, IL",
        destination: "Detroit, MI",
        availableCapacity: 5,
        totalCapacity: 10,
        equipmentType: "53ft Dry Van",
        availableDate: new Date(),
        expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        pricing: "1500.00",
        metadata: {
          driverCount: 2,
          hazmatCapable: false,
          temperatureControlled: false,
        },
      });
    } else if (integration.type === "wms") {
      // Mock WMS capacity data
      mockData.push({
        integrationId: integration.id,
        externalId: `ext_${Date.now()}_2`,
        serviceType: "ltl",
        origin: "Dallas, TX",
        destination: null, // Flexible destination
        availableCapacity: 1000,
        totalCapacity: 2000,
        equipmentType: "Warehouse Space",
        availableDate: new Date(),
        expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        pricing: "25.00",
        metadata: {
          warehouseId: "WH-TX-001",
          temperatureControlled: true,
          securityLevel: "high",
        },
      });
    }

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    return mockData;
  }

  /**
   * Tests connection to external API
   */
  static async testConnection(integration: Integration): Promise<boolean> {
    try {
      if (!integration.apiEndpoint) {
        return false;
      }

      // In a real implementation, you would make a test API call here
      // For now, we'll simulate a successful connection test
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return true;
    } catch (error) {
      console.error("Connection test failed:", error);
      return false;
    }
  }

  /**
   * Schedules automatic syncing for active integrations
   */
  static async scheduleSync(integrationId: string): Promise<void> {
    const integration = await storage.getIntegration(integrationId);
    if (!integration || integration.status !== "active") {
      return;
    }

    // Schedule next sync based on syncInterval
    setTimeout(async () => {
      try {
        await this.syncCapacityData(integrationId);
        // Schedule next sync
        this.scheduleSync(integrationId);
      } catch (error) {
        console.error(`Scheduled sync failed for integration ${integrationId}:`, error);
      }
    }, (integration.syncInterval || 300) * 1000);
  }

  /**
   * Clean up expired capacity data
   */
  static async cleanupExpiredData(): Promise<void> {
    try {
      await storage.deleteExpiredCapacityData();
      console.log("Expired capacity data cleaned up successfully");
    } catch (error) {
      console.error("Failed to clean up expired data:", error);
    }
  }
}

// Export convenience functions
export const syncCapacityData = IntegrationService.syncCapacityData.bind(IntegrationService);
export const testConnection = IntegrationService.testConnection.bind(IntegrationService);
export const scheduleSync = IntegrationService.scheduleSync.bind(IntegrationService);
export const cleanupExpiredData = IntegrationService.cleanupExpiredData.bind(IntegrationService);