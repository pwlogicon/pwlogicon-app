import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CapacityAnalysisInput {
  lane: string;
  historicalData: {
    volume: number;
    capacity: number;
    utilization: number;
    date: string;
  }[];
  currentMarketConditions: {
    demandLevel: 'high' | 'medium' | 'low';
    seasonality: string;
    economicFactors: string[];
  };
}

export interface PriceOptimizationInput {
  lane: string;
  currentRate: number;
  competitorRates: number[];
  demandLevel: number;
  capacityUtilization: number;
  marketTrends: string[];
}

export class AILogisticsService {
  async analyzeCapacityGaps(input: CapacityAnalysisInput): Promise<{
    predictedGap: number;
    confidence: number;
    timeframe: string;
    impact: 'high' | 'medium' | 'low';
    suggestedActions: string[];
  }> {
    try {
      const prompt = `
Analyze the following logistics capacity data and predict potential gaps:

Lane: ${input.lane}
Historical Data: ${JSON.stringify(input.historicalData)}
Market Conditions: ${JSON.stringify(input.currentMarketConditions)}

Based on this data, provide a comprehensive capacity gap analysis including:
1. Predicted capacity gap (number of loads)
2. Confidence level (0-100%)
3. Timeframe for the prediction
4. Impact level (high/medium/low)
5. 3-5 specific actionable recommendations

Respond in JSON format with keys: predictedGap, confidence, timeframe, impact, suggestedActions
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert logistics analyst with deep knowledge of capacity planning, market dynamics, and transportation optimization. Provide accurate, data-driven insights."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error in capacity gap analysis:", error);
      throw new Error("Failed to analyze capacity gaps");
    }
  }

  async optimizePricing(input: PriceOptimizationInput): Promise<{
    suggestedRate: number;
    confidence: number;
    marketTrend: 'up' | 'down' | 'stable';
    reasoning: string;
    competitivePosition: string;
  }> {
    try {
      const prompt = `
Analyze the following pricing data for logistics optimization:

Lane: ${input.lane}
Current Rate: $${input.currentRate}
Competitor Rates: ${input.competitorRates.map(r => `$${r}`).join(', ')}
Demand Level: ${input.demandLevel}/10
Capacity Utilization: ${input.capacityUtilization}%
Market Trends: ${input.marketTrends.join(', ')}

Provide optimal pricing strategy including:
1. Suggested rate (dollar amount)
2. Confidence level (0-100%)
3. Market trend direction (up/down/stable)
4. Detailed reasoning for the recommendation
5. Competitive positioning analysis

Respond in JSON format with keys: suggestedRate, confidence, marketTrend, reasoning, competitivePosition
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a pricing optimization expert specializing in logistics and transportation. Your recommendations should maximize profitability while remaining competitive."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error in price optimization:", error);
      throw new Error("Failed to optimize pricing");
    }
  }

  async forecastDemand(regionData: {
    region: string;
    historicalVolumes: { month: string; volume: number }[];
    seasonalFactors: string[];
    economicIndicators: { gdp: number; unemployment: number; fuel: number };
  }): Promise<{
    predictedDemand: number;
    growthPercentage: number;
    peakPeriods: string[];
    confidence: number;
    factors: string[];
  }> {
    try {
      const prompt = `
Forecast logistics demand for the following region:

Region: ${regionData.region}
Historical Volumes: ${JSON.stringify(regionData.historicalVolumes)}
Seasonal Factors: ${regionData.seasonalFactors.join(', ')}
Economic Indicators: GDP Growth: ${regionData.economicIndicators.gdp}%, Unemployment: ${regionData.economicIndicators.unemployment}%, Fuel Price Change: ${regionData.economicIndicators.fuel}%

Provide comprehensive demand forecast including:
1. Predicted demand (loads per week)
2. Growth percentage vs current
3. Expected peak periods
4. Confidence level (0-100%)
5. Key driving factors

Respond in JSON format with keys: predictedDemand, growthPercentage, peakPeriods, confidence, factors
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a demand forecasting specialist with expertise in logistics market analysis, economic indicators, and seasonal patterns."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error in demand forecasting:", error);
      throw new Error("Failed to forecast demand");
    }
  }

  async analyzeException(exceptionData: {
    type: string;
    description: string;
    context: {
      shipmentId: string;
      carrier: string;
      route: string;
      conditions: string[];
    };
    historicalPatterns: {
      similarExceptions: number;
      resolutionMethods: string[];
      averageResolutionTime: number;
    };
  }): Promise<{
    severity: 'critical' | 'high' | 'medium' | 'low';
    prediction: string;
    autoResolution: boolean;
    estimatedImpact: string;
    suggestedAction: string;
    preventionStrategy: string;
  }> {
    try {
      const prompt = `
Analyze the following logistics exception for optimal resolution:

Exception Type: ${exceptionData.type}
Description: ${exceptionData.description}
Context: ${JSON.stringify(exceptionData.context)}
Historical Patterns: ${JSON.stringify(exceptionData.historicalPatterns)}

Provide comprehensive exception analysis including:
1. Severity level (critical/high/medium/low)
2. Detailed prediction of outcomes
3. Whether auto-resolution is recommended (true/false)
4. Estimated business impact
5. Specific suggested action
6. Prevention strategy for future

Respond in JSON format with keys: severity, prediction, autoResolution, estimatedImpact, suggestedAction, preventionStrategy
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert in logistics operations and exception handling. Your analysis should be precise, actionable, and focused on minimizing business impact."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error in exception analysis:", error);
      throw new Error("Failed to analyze exception");
    }
  }

  async generateMarketInsights(data: {
    lanes: string[];
    timeframe: string;
    region: string;
    marketData: {
      fuelPrices: number[];
      driverShortage: number;
      ecommerceGrowth: number;
      regulatoryChanges: string[];
    };
  }): Promise<{
    insights: string[];
    opportunities: string[];
    risks: string[];
    recommendations: string[];
    confidence: number;
  }> {
    try {
      const prompt = `
Generate strategic market insights for logistics operations:

Target Lanes: ${data.lanes.join(', ')}
Timeframe: ${data.timeframe}
Region: ${data.region}
Market Data: ${JSON.stringify(data.marketData)}

Provide comprehensive market intelligence including:
1. 5-7 key market insights
2. 3-5 business opportunities
3. 3-5 potential risks
4. 5-7 strategic recommendations
5. Overall confidence level (0-100%)

Respond in JSON format with keys: insights, opportunities, risks, recommendations, confidence
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a senior logistics market analyst with deep industry knowledge. Provide strategic, actionable insights that drive business decisions."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error("Error generating market insights:", error);
      throw new Error("Failed to generate market insights");
    }
  }
}

export const aiLogisticsService = new AILogisticsService();