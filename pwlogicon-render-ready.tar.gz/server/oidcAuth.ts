import type { Express } from "express";
import cookieSession from 'cookie-session';
import { storage } from './storage';

// OIDC Client will be dynamically imported
let Issuer: any = null;

// OIDC Client instance
let oidcClient: any = null;

// Initialize OIDC Client
async function initOIDC(): Promise<void> {
  try {
    if (!process.env.REPLIT_CLIENT_ID || !process.env.REPLIT_CLIENT_SECRET) {
      console.warn('Missing REPLIT_CLIENT_ID or REPLIT_CLIENT_SECRET, OIDC authentication disabled');
      return;
    }

    // For now, fall back to development mode until OIDC module is stable
    console.log('OIDC module integration pending, using development authentication');
    return;
    
    oidcClient = new issuer.Client({
      client_id: process.env.REPLIT_CLIENT_ID,
      client_secret: process.env.REPLIT_CLIENT_SECRET,
      redirect_uris: ['https://pwlogicon.replit.app/api/callback'],
      response_types: ['code']
    });

    console.log('OIDC client initialized successfully');
  } catch (err) {
    console.error('OIDC Init Failed:', err);
    oidcClient = null;
  }
}

// Session middleware
export function getSessionMiddleware() {
  return cookieSession({
    name: 'pwlogicon.session',
    secret: process.env.SESSION_SECRET || 'fallback-development-secret-key-pwlogicon-2025',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  });
}

// User upsert helper
async function upsertUser(userinfo: any): Promise<any> {
  try {
    const userData = {
      id: userinfo.sub,
      email: userinfo.email,
      firstName: userinfo.given_name || userinfo.name?.split(' ')[0] || '',
      lastName: userinfo.family_name || userinfo.name?.split(' ')[1] || '',
      profileImageUrl: userinfo.picture || '',
    };

    await storage.upsertUser(userData);
    console.log(`User upserted: ${userinfo.email}`);
    return userData;
  } catch (error) {
    console.error('Error upserting user:', error);
    throw error;
  }
}

// Authentication middleware
export function requireAuth(req: any, res: any, next: any) {
  // Development mode: always allow access
  if (process.env.NODE_ENV === 'development') {
    req.user = {
      id: 'dev-user-1',
      email: 'dev@pwlogicon.com',
      firstName: 'Development',
      lastName: 'User'
    };
    return next();
  }

  // Check session for authenticated user
  if (req.session?.user) {
    req.user = req.session.user;
    return next();
  }

  // Redirect to login if not authenticated
  res.redirect('/api/login');
}

// Setup OIDC authentication routes
export async function setupOIDCAuth(app: Express): Promise<void> {
  try {
    // Initialize session middleware
    app.use(getSessionMiddleware());

    // Initialize OIDC client
    await initOIDC();

    // Login Route
    app.get('/api/login', async (req: any, res) => {
      if (!oidcClient) {
        // Fallback for development or when OIDC is not configured
        console.log('OIDC not available, using development mode');
        req.session.user = {
          id: 'dev-user-1',
          email: 'dev@pwlogicon.com',
          firstName: 'Development',
          lastName: 'User'
        };
        return res.redirect('/dashboard?sid=dev-session-login');
      }

      try {
        const authUrl = oidcClient.authorizationUrl({
          scope: 'openid profile email',
          state: Math.random().toString(36).substr(2, 9),
          nonce: Math.random().toString(36).substr(2, 9)
        });
        
        console.log('Redirecting to OIDC auth:', authUrl);
        res.redirect(authUrl);
      } catch (error) {
        console.error('Error generating auth URL:', error);
        res.status(500).send("Authentication service not ready. Try again.");
      }
    });

    // Callback Route
    app.get('/api/callback', async (req: any, res) => {
      if (!oidcClient) {
        console.log('OIDC not available in callback, redirecting to dashboard');
        return res.redirect('/dashboard?sid=dev-session-callback');
      }

      try {
        const params = oidcClient.callbackParams(req);
        const tokenSet = await oidcClient.callback('https://pwlogicon.replit.app/api/callback', params);
        const userinfo = tokenSet.claims();

        console.log("OIDC Login successful:", userinfo.email);

        // Upsert user to database
        const userData = await upsertUser(userinfo);

        // Save user to session
        req.session.user = userData;

        // Redirect to dashboard with session ID
        res.redirect(`/dashboard?sid=${userData.id}`);

      } catch (err) {
        console.error('OIDC Callback Error:', err);
        res.status(500).send("Login failed. Check console for details.");
      }
    });

    // Logout Route
    app.get('/api/logout', (req: any, res) => {
      req.session = null;
      res.redirect('/');
    });

    // User info endpoint
    app.get('/api/auth/user', requireAuth, (req: any, res) => {
      res.json(req.user);
    });

    console.log('OIDC authentication routes registered successfully');

  } catch (error) {
    console.error('Failed to setup OIDC authentication:', error);
    throw error;
  }
}

// Check if user is authenticated
export function isAuthenticated(req: any): boolean {
  if (process.env.NODE_ENV === 'development') {
    return true; // Always authenticated in development
  }
  return !!req.session?.user;
}

// Get current user from request
export function getCurrentUser(req: any): any {
  if (process.env.NODE_ENV === 'development') {
    return {
      id: 'dev-user-1',
      email: 'dev@pwlogicon.com',
      firstName: 'Development',
      lastName: 'User'
    };
  }
  return req.session?.user || null;
}