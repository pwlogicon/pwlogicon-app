import { eq, desc, and, or, inArray } from "drizzle-orm";
import { db } from "./db";
import { 
  conversations, 
  conversationParticipants, 
  messages, 
  users,
  type Conversation,
  type Message,
  type InsertConversation,
  type InsertMessage,
  type InsertConversationParticipant
} from "@shared/schema";

export class MessagingService {
  // Create a new conversation
  async createConversation(data: {
    subject: string;
    participantIds: string[];
    creatorId: string;
    relatedOpportunityId?: string;
    relatedPartnershipId?: string;
    relatedTransactionId?: string;
  }): Promise<Conversation> {
    const { participantIds, creatorId, ...conversationData } = data;
    
    // Create conversation
    const [conversation] = await db
      .insert(conversations)
      .values(conversationData)
      .returning();

    // Add all participants including creator
    const allParticipantIds = Array.from(new Set([creatorId, ...participantIds]));
    const participantData = allParticipantIds.map(userId => ({
      conversationId: conversation.id,
      userId,
      isAdmin: userId === creatorId,
    }));

    await db.insert(conversationParticipants).values(participantData);

    return conversation;
  }

  // Get user's conversations with unread counts
  async getUserConversations(userId: string): Promise<any[]> {
    const result = await db
      .select({
        conversation: conversations,
        participant: conversationParticipants,
        lastMessage: {
          id: messages.id,
          content: messages.content,
          createdAt: messages.createdAt,
          senderName: users.firstName,
        },
      })
      .from(conversations)
      .innerJoin(
        conversationParticipants,
        eq(conversations.id, conversationParticipants.conversationId)
      )
      .leftJoin(
        messages,
        eq(conversations.id, messages.conversationId)
      )
      .leftJoin(
        users,
        eq(messages.senderId, users.id)
      )
      .where(eq(conversationParticipants.userId, userId))
      .orderBy(desc(conversations.lastMessageAt));

    // Get unread counts for each conversation
    const conversationIds = result.map(r => r.conversation.id);
    const unreadCounts = await this.getUnreadCounts(userId, conversationIds);

    // Group by conversation and add unread counts
    const conversationMap = new Map();
    result.forEach(row => {
      const convId = row.conversation.id;
      if (!conversationMap.has(convId)) {
        conversationMap.set(convId, {
          ...row.conversation,
          lastMessage: row.lastMessage,
          unreadCount: unreadCounts[convId] || 0,
        });
      }
    });

    return Array.from(conversationMap.values());
  }

  // Get messages for a conversation
  async getConversationMessages(conversationId: string, userId: string, limit = 50, offset = 0): Promise<any[]> {
    // Verify user is participant
    const participant = await db
      .select()
      .from(conversationParticipants)
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, userId)
        )
      )
      .limit(1);

    if (!participant.length) {
      throw new Error("Access denied: Not a participant in this conversation");
    }

    // Get messages with sender info
    const result = await db
      .select({
        message: messages,
        sender: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          companyName: users.companyName,
          role: users.role,
        },
      })
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id))
      .where(
        and(
          eq(messages.conversationId, conversationId),
          eq(messages.isDeleted, false)
        )
      )
      .orderBy(desc(messages.createdAt))
      .limit(limit)
      .offset(offset);

    return result.reverse(); // Return in chronological order
  }

  // Send a message
  async sendMessage(data: {
    conversationId: string;
    senderId: string;
    content: string;
    messageType?: "text" | "file" | "system";
    attachmentUrl?: string;
    attachmentName?: string;
  }): Promise<Message> {
    // Verify sender is participant
    const participant = await db
      .select()
      .from(conversationParticipants)
      .where(
        and(
          eq(conversationParticipants.conversationId, data.conversationId),
          eq(conversationParticipants.userId, data.senderId)
        )
      )
      .limit(1);

    if (!participant.length) {
      throw new Error("Access denied: Not a participant in this conversation");
    }

    // Insert message
    const [message] = await db
      .insert(messages)
      .values({
        conversationId: data.conversationId,
        senderId: data.senderId,
        content: data.content,
        messageType: data.messageType || "text",
        attachmentUrl: data.attachmentUrl,
        attachmentName: data.attachmentName,
      })
      .returning();

    // Update conversation's last message timestamp
    await db
      .update(conversations)
      .set({ 
        lastMessageAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(conversations.id, data.conversationId));

    return message;
  }

  // Mark messages as read
  async markAsRead(conversationId: string, userId: string): Promise<void> {
    await db
      .update(conversationParticipants)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, userId)
        )
      );
  }

  // Get unread message counts
  private async getUnreadCounts(userId: string, conversationIds: string[]): Promise<Record<string, number>> {
    if (!conversationIds.length) return {};

    const result = await db
      .select({
        conversationId: messages.conversationId,
        count: messages.id,
        lastReadAt: conversationParticipants.lastReadAt,
        messageCreatedAt: messages.createdAt,
      })
      .from(messages)
      .innerJoin(
        conversationParticipants,
        and(
          eq(messages.conversationId, conversationParticipants.conversationId),
          eq(conversationParticipants.userId, userId)
        )
      )
      .where(
        and(
          inArray(messages.conversationId, conversationIds),
          eq(messages.isDeleted, false)
        )
      );

    // Count unread messages per conversation
    const counts: Record<string, number> = {};
    result.forEach(row => {
      const convId = row.conversationId;
      if (!counts[convId]) counts[convId] = 0;
      
      // Message is unread if created after last read time
      if (!row.lastReadAt || (row.messageCreatedAt && row.messageCreatedAt > row.lastReadAt)) {
        counts[convId]++;
      }
    });

    return counts;
  }

  // Search conversations and messages
  async searchConversations(userId: string, query: string): Promise<any[]> {
    const result = await db
      .select({
        conversation: conversations,
        message: messages,
        sender: {
          firstName: users.firstName,
          lastName: users.lastName,
        },
      })
      .from(conversations)
      .innerJoin(
        conversationParticipants,
        eq(conversations.id, conversationParticipants.conversationId)
      )
      .leftJoin(messages, eq(conversations.id, messages.conversationId))
      .leftJoin(users, eq(messages.senderId, users.id))
      .where(
        and(
          eq(conversationParticipants.userId, userId),
          or(
            eq(conversations.subject, query),
            eq(messages.content, query)
          )
        )
      )
      .orderBy(desc(conversations.lastMessageAt));

    return result;
  }

  // Get conversation participants
  async getConversationParticipants(conversationId: string): Promise<any[]> {
    const result = await db
      .select({
        participant: conversationParticipants,
        user: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          companyName: users.companyName,
          role: users.role,
          email: users.email,
        },
      })
      .from(conversationParticipants)
      .innerJoin(users, eq(conversationParticipants.userId, users.id))
      .where(eq(conversationParticipants.conversationId, conversationId))
      .orderBy(conversationParticipants.joinedAt);

    return result;
  }

  // Archive conversation
  async archiveConversation(conversationId: string, userId: string): Promise<void> {
    // Verify user is admin participant
    const participant = await db
      .select()
      .from(conversationParticipants)
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, userId),
          eq(conversationParticipants.isAdmin, true)
        )
      )
      .limit(1);

    if (!participant.length) {
      throw new Error("Access denied: Only conversation admins can archive conversations");
    }

    await db
      .update(conversations)
      .set({ 
        status: "archived",
        updatedAt: new Date(),
      })
      .where(eq(conversations.id, conversationId));
  }
}

export const messagingService = new MessagingService();