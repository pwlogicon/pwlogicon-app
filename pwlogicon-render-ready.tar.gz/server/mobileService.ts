import { db } from "./db";
import { 
  fieldOperations, 
  locationTracking, 
  mobileSessions, 
  offlineQueue,
  fieldOperationLogs,
  type FieldOperation,
  type LocationTracking,
  type MobileSession,
  type OfflineQueue,
  type FieldOperationLog,
  type InsertFieldOperation,
  type InsertLocationTracking,
  type InsertMobileSession,
  type InsertOfflineQueue,
  type InsertFieldOperationLog
} from "@shared/schema";
import { eq, and, gte, lte, desc, count } from "drizzle-orm";

export class MobileService {
  // Field Operations Management
  async getFieldOperations(userId: string, status?: string): Promise<FieldOperation[]> {
    let query = db.select().from(fieldOperations).where(eq(fieldOperations.userId, userId));
    
    if (status) {
      query = query.where(and(
        eq(fieldOperations.userId, userId),
        eq(fieldOperations.status, status)
      ));
    }
    
    return await query.orderBy(desc(fieldOperations.createdAt));
  }

  async createFieldOperation(data: InsertFieldOperation): Promise<FieldOperation> {
    const [operation] = await db.insert(fieldOperations).values(data).returning();
    return operation;
  }

  async getFieldOperation(id: string, userId: string): Promise<FieldOperation | undefined> {
    const [operation] = await db
      .select()
      .from(fieldOperations)
      .where(and(
        eq(fieldOperations.id, id),
        eq(fieldOperations.userId, userId)
      ));
    return operation;
  }

  async updateFieldOperation(id: string, userId: string, data: Partial<InsertFieldOperation>): Promise<FieldOperation> {
    const [operation] = await db
      .update(fieldOperations)
      .set({ ...data, updatedAt: new Date() })
      .where(and(
        eq(fieldOperations.id, id),
        eq(fieldOperations.userId, userId)
      ))
      .returning();
    return operation;
  }

  async deleteFieldOperation(id: string, userId: string): Promise<void> {
    await db
      .delete(fieldOperations)
      .where(and(
        eq(fieldOperations.id, id),
        eq(fieldOperations.userId, userId)
      ));
  }

  async getActiveFieldOperationsCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(fieldOperations)
      .where(and(
        eq(fieldOperations.userId, userId),
        eq(fieldOperations.status, 'in_progress')
      ));
    return result.count;
  }

  async getTodaysFieldOperations(userId: string): Promise<FieldOperation[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    return await db
      .select()
      .from(fieldOperations)
      .where(and(
        eq(fieldOperations.userId, userId),
        gte(fieldOperations.createdAt, today),
        lte(fieldOperations.createdAt, tomorrow)
      ))
      .orderBy(desc(fieldOperations.createdAt));
  }

  // Location Tracking
  async recordLocation(data: InsertLocationTracking): Promise<LocationTracking> {
    const [location] = await db.insert(locationTracking).values(data).returning();
    return location;
  }

  async getLocationHistory(
    userId: string, 
    fieldOperationId?: string, 
    startTime?: Date, 
    endTime?: Date
  ): Promise<LocationTracking[]> {
    let query = db.select().from(locationTracking).where(eq(locationTracking.userId, userId));

    const conditions = [eq(locationTracking.userId, userId)];
    
    if (fieldOperationId) {
      conditions.push(eq(locationTracking.fieldOperationId, fieldOperationId));
    }
    
    if (startTime) {
      conditions.push(gte(locationTracking.createdAt, startTime));
    }
    
    if (endTime) {
      conditions.push(lte(locationTracking.createdAt, endTime));
    }

    return await db
      .select()
      .from(locationTracking)
      .where(and(...conditions))
      .orderBy(desc(locationTracking.timestamp));
  }

  async getLatestLocation(userId: string): Promise<LocationTracking | undefined> {
    const [location] = await db
      .select()
      .from(locationTracking)
      .where(eq(locationTracking.userId, userId))
      .orderBy(desc(locationTracking.timestamp))
      .limit(1);
    return location;
  }

  // Mobile Session Management
  async createOrUpdateMobileSession(data: InsertMobileSession): Promise<MobileSession> {
    // Try to find existing session for this user and device
    const [existingSession] = await db
      .select()
      .from(mobileSessions)
      .where(and(
        eq(mobileSessions.userId, data.userId),
        eq(mobileSessions.deviceId, data.deviceId || '')
      ));

    if (existingSession) {
      const [session] = await db
        .update(mobileSessions)
        .set({ ...data, updatedAt: new Date(), lastSync: new Date() })
        .where(eq(mobileSessions.id, existingSession.id))
        .returning();
      return session;
    } else {
      const [session] = await db.insert(mobileSessions).values(data).returning();
      return session;
    }
  }

  async updateSessionStatus(userId: string, deviceId: string, isOnline: boolean): Promise<void> {
    await db
      .update(mobileSessions)
      .set({ 
        isOnline, 
        lastSync: new Date(),
        updatedAt: new Date()
      })
      .where(and(
        eq(mobileSessions.userId, userId),
        eq(mobileSessions.deviceId, deviceId)
      ));
  }

  async getUserSessions(userId: string): Promise<MobileSession[]> {
    return await db
      .select()
      .from(mobileSessions)
      .where(eq(mobileSessions.userId, userId))
      .orderBy(desc(mobileSessions.lastSync));
  }

  // Offline Queue Management
  async addToOfflineQueue(data: InsertOfflineQueue): Promise<OfflineQueue> {
    const [queueItem] = await db.insert(offlineQueue).values(data).returning();
    return queueItem;
  }

  async syncOfflineData(userId: string): Promise<{ success: number; failed: number }> {
    const pendingItems = await db
      .select()
      .from(offlineQueue)
      .where(and(
        eq(offlineQueue.userId, userId),
        eq(offlineQueue.synced, false)
      ))
      .orderBy(offlineQueue.createdAt);

    let successCount = 0;
    let failedCount = 0;

    for (const item of pendingItems) {
      try {
        // Process the queued item based on its action and resource
        await this.processOfflineQueueItem(item);
        
        // Mark as synced
        await db
          .update(offlineQueue)
          .set({ synced: true, syncedAt: new Date() })
          .where(eq(offlineQueue.id, item.id));
          
        successCount++;
      } catch (error) {
        console.error(`Failed to sync queue item ${item.id}:`, error);
        failedCount++;
      }
    }

    return { success: successCount, failed: failedCount };
  }

  private async processOfflineQueueItem(item: OfflineQueue): Promise<void> {
    const { action, resource, resourceId, data } = item;

    switch (resource) {
      case 'field_operations':
        if (action === 'CREATE') {
          await db.insert(fieldOperations).values(data);
        } else if (action === 'UPDATE' && resourceId) {
          await db
            .update(fieldOperations)
            .set(data)
            .where(eq(fieldOperations.id, resourceId));
        } else if (action === 'DELETE' && resourceId) {
          await db
            .delete(fieldOperations)
            .where(eq(fieldOperations.id, resourceId));
        }
        break;

      case 'location_tracking':
        if (action === 'CREATE') {
          await db.insert(locationTracking).values(data);
        }
        break;

      case 'field_operation_logs':
        if (action === 'CREATE') {
          await db.insert(fieldOperationLogs).values(data);
        }
        break;

      default:
        throw new Error(`Unknown resource type: ${resource}`);
    }
  }

  // Field Operation Logs
  async addFieldOperationLog(data: InsertFieldOperationLog): Promise<FieldOperationLog> {
    const [log] = await db.insert(fieldOperationLogs).values(data).returning();
    return log;
  }

  async getFieldOperationLogs(fieldOperationId: string): Promise<FieldOperationLog[]> {
    return await db
      .select()
      .from(fieldOperationLogs)
      .where(eq(fieldOperationLogs.fieldOperationId, fieldOperationId))
      .orderBy(desc(fieldOperationLogs.createdAt));
  }
}

export const mobileService = new MobileService();