import cookieSession from "cookie-session";
import type { Express } from "express";
import { storage } from "./storage";

// Simple authentication state
let authConfig = {
  clientId: '',
  clientSecret: '',
  redirectUri: '',
  authUrl: '',
  tokenUrl: '',
  userInfoUrl: ''
};

async function initSimpleAuth() {
  try {
    console.log('Setting up simple authentication...');
    
    if (!process.env.REPLIT_CLIENT_ID || !process.env.REPLIT_CLIENT_SECRET) {
      console.warn('Missing REPLIT_CLIENT_ID or REPLIT_CLIENT_SECRET, using development mode');
      return;
    }
    
    authConfig = {
      clientId: process.env.REPLIT_CLIENT_ID,
      clientSecret: process.env.REPLIT_CLIENT_SECRET,
      redirectUri: process.env.NODE_ENV === 'production' 
        ? 'https://your-render-app.onrender.com/api/callback'  // Update this with your actual Render URL
        : 'https://pwlogicon.replit.app/api/callback',
      authUrl: 'https://replit.com/oidc/authorize',
      tokenUrl: 'https://replit.com/oidc/token',
      userInfoUrl: 'https://replit.com/oidc/userinfo'
    };
    
    console.log('Authentication configuration ready');
  } catch (err) {
    console.error('Authentication setup failed:', err);
  }
}

export function getSession() {
  return cookieSession({
    name: 'pwlogicon.session',
    secret: process.env.SESSION_SECRET || 'fallback-development-secret-key-pwlogicon-2025',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  });
}

async function upsertUser(userinfo: any) {
  try {
    await storage.upsertUser({
      id: userinfo.sub,
      email: userinfo.email,
      firstName: userinfo.given_name || userinfo.name?.split(' ')[0],
      lastName: userinfo.family_name || userinfo.name?.split(' ')[1],
      profileImageUrl: userinfo.picture,
    });
  } catch (error) {
    console.error('Error upserting user:', error);
  }
}

export async function setupAuth(app: Express) {
  console.log('Setting up authentication...');
  
  // Set up session middleware
  app.use(getSession());
  
  // Initialize authentication
  await initSimpleAuth();
  
  // Login route
  app.get('/api/login', async (req: any, res) => {
    try {
      if (!authConfig.clientId) {
        console.log('No client ID configured, using development mode');
        return res.redirect('/dashboard?sid=dev-session-login');
      }

      // Build proper Replit OIDC authorization URL
      const state = Math.random().toString(36).substr(2, 9);
      const authParams = new URLSearchParams({
        client_id: authConfig.clientId,
        redirect_uri: authConfig.redirectUri,
        response_type: 'code',
        scope: 'openid profile email',
        state: state,
        nonce: Math.random().toString(36).substr(2, 9)
      });
      
      const authUrl = `${authConfig.authUrl}?${authParams.toString()}`;
      console.log('Redirecting to Replit auth:', authUrl);
      res.redirect(authUrl);
    } catch (error) {
      console.error('Login error:', error);
      res.redirect('/dashboard?sid=dev-session-login-error');
    }
  });

  // Callback route  
  app.get('/api/callback', async (req: any, res) => {
    try {
      // For development, always redirect to dashboard
      if (process.env.NODE_ENV === 'development') {
        return res.redirect('/dashboard?sid=dev-session-callback');
      }
      
      const { code, state } = req.query;
      
      if (!code) {
        return res.status(400).send('Authorization code missing');
      }

      // Exchange code for token (simplified for now)
      // In production, this would make actual HTTP requests to token endpoint
      
      // Set session with mock user for now
      req.session.user = {
        id: 'authenticated-user',
        email: 'user@pwlogicon.com',
        name: 'PWLoGiCon User'
      };

      res.redirect('/dashboard?sid=authenticated-user');
    } catch (err) {
      console.error('Callback Error:', err);
      res.redirect('/dashboard?sid=dev-session-callback-error');
    }
  });
  
  // Logout route
  app.get('/api/logout', async (req: any, res) => {
    try {
      req.session = null; // Clear session
      res.redirect('/');
    } catch (error) {
      console.error('Logout error:', error);
      res.redirect('/');
    }
  });
}

export const isAuthenticated = (req: any, res: any, next: any) => {
  // In development mode, always bypass authentication
  if (process.env.NODE_ENV === 'development') {
    return next();
  }

  // Check if user is authenticated via session
  if (req.session?.user) {
    return next();
  }

  // Redirect to login if not authenticated
  res.redirect('/api/login');
};
