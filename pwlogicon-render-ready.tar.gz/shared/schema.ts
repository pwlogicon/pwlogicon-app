import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  decimal,
  integer,
  boolean,
  pgEnum,
  serial,
  real,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User roles enum
export const userRoleEnum = pgEnum("user_role", ["carrier", "3pl", "broker", "shipper"]);

// Service types enum
export const serviceTypeEnum = pgEnum("service_type", ["ftl", "ltl", "intermodal", "reefer", "drayage"]);

// Partnership status enum
export const partnershipStatusEnum = pgEnum("partnership_status", ["pending", "active", "completed", "cancelled"]);

// Transaction status enum
export const transactionStatusEnum = pgEnum("transaction_status", ["pending", "processing", "paid", "failed"]);

// Fee model enum
export const feeModelEnum = pgEnum("fee_model", ["flat", "percentage"]);

// Integration types enum
export const integrationTypeEnum = pgEnum("integration_type", ["tms", "wms", "edi", "api"]);

// Integration status enum
export const integrationStatusEnum = pgEnum("integration_status", ["active", "inactive", "error", "pending"]);

// Lane analytics period enum
export const analyticsPeriodEnum = pgEnum("analytics_period", ["daily", "weekly", "monthly", "quarterly"]);

// Message types enum
export const messageTypeEnum = pgEnum("message_type", ["text", "file", "system"]);

// Conversation status enum
export const conversationStatusEnum = pgEnum("conversation_status", ["active", "archived", "closed"]);

// Device types enum for mobile tracking
export const deviceTypeEnum = pgEnum("device_type", ["mobile", "tablet", "desktop"]);

// Field operation status enum
export const fieldOperationStatusEnum = pgEnum("field_operation_status", ["pending", "in_progress", "completed", "delayed"]);

// Location tracking status enum
export const locationStatusEnum = pgEnum("location_status", ["active", "inactive", "offline"]);

// Shipment status enum
export const shipmentStatusEnum = pgEnum("shipment_status", ["draft", "pending", "in_transit", "delivered", "cancelled"]);

// Carrier types enum
export const carrierTypeEnum = pgEnum("carrier_type", ["ups", "fedex", "dhl", "usps", "ltl_carrier", "ftl_carrier"]);

// Equipment types enum
export const equipmentTypeEnum = pgEnum("equipment_type", ["dry_van", "reefer", "flatbed", "step_deck", "lowboy", "tanker"]);

// Role context enum for dual-role functionality
export const roleContextEnum = pgEnum("role_context", ["provider", "requester"]);

// Verification status enum
export const verificationStatusEnum = pgEnum("verification_status", ["pending", "verified", "rejected", "expired"]);

// KYC document types enum
export const kycDocumentTypeEnum = pgEnum("kyc_document_type", ["business_license", "insurance_certificate", "w9_form", "dot_authority", "mc_authority", "safety_rating"]);

// Dispute status enum
export const disputeStatusEnum = pgEnum("dispute_status", ["open", "investigating", "resolved", "escalated", "closed"]);

// Insurance types enum
export const insuranceTypeEnum = pgEnum("insurance_type", ["general_liability", "cargo", "auto", "workers_comp", "cyber"]);

// Performance rating enum
export const performanceRatingEnum = pgEnum("performance_rating", ["excellent", "good", "fair", "poor", "unrated"]);

// Compliance status enum
export const complianceStatusEnum = pgEnum("compliance_status", ["Verified", "Pending", "Rejected", "Expired"]);

// Safety rating enum
export const safetyRatingEnum = pgEnum("safety_rating", ["Satisfactory", "Conditional", "Unsatisfactory", "Not Rated"]);

// User storage table.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("carrier"),
  companyName: varchar("company_name"),
  operatingRegions: text("operating_regions").array(),
  services: serviceTypeEnum("services").array(),
  verified: boolean("verified").default(false),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  // Compliance fields
  mcNumber: varchar("mc_number"),
  dotNumber: varchar("dot_number"),
  insuranceExpiry: timestamp("insurance_expiry"),
  safetyRating: safetyRatingEnum("safety_rating"),
  cargoCoverage: integer("cargo_coverage"),
  lastComplianceCheck: timestamp("last_compliance_check"),
  complianceStatus: complianceStatusEnum("compliance_status").default("Pending"),
  complianceScore: integer("compliance_score").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// TMS/WMS Integrations table
export const integrations = pgTable("integrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name").notNull(),
  type: integrationTypeEnum("type").notNull(),
  status: integrationStatusEnum("status").default("pending"),
  apiEndpoint: varchar("api_endpoint"),
  apiKey: varchar("api_key"), // encrypted
  webhookUrl: varchar("webhook_url"),
  syncInterval: integer("sync_interval").default(300), // seconds
  lastSyncAt: timestamp("last_sync_at"),
  config: jsonb("config"), // provider-specific configuration
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Capacity data from integrations
export const capacityData = pgTable("capacity_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  integrationId: varchar("integration_id").references(() => integrations.id).notNull(),
  externalId: varchar("external_id"), // ID from the external system
  serviceType: serviceTypeEnum("service_type").notNull(),
  origin: varchar("origin").notNull(),
  destination: varchar("destination"),
  availableCapacity: integer("available_capacity"),
  totalCapacity: integer("total_capacity"),
  equipmentType: varchar("equipment_type"),
  availableDate: timestamp("available_date"),
  expiryDate: timestamp("expiry_date"),
  pricing: decimal("pricing", { precision: 10, scale: 2 }),
  metadata: jsonb("metadata"),
  syncedAt: timestamp("synced_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Shipments table for enhanced shipment management
export const shipments = pgTable("shipments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  batchId: varchar("batch_id"), // For batch processing
  trackingNumber: varchar("tracking_number"),
  externalId: varchar("external_id"), // ID from carrier system
  
  // Shipment details
  origin: varchar("origin").notNull(),
  destination: varchar("destination").notNull(),
  serviceType: serviceTypeEnum("service_type").notNull(),
  equipmentType: equipmentTypeEnum("equipment_type"),
  status: shipmentStatusEnum("status").default("draft"),
  
  // Carrier information
  carrierId: varchar("carrier_id"),
  carrierType: carrierTypeEnum("carrier_type"),
  carrierName: varchar("carrier_name"),
  
  // Pricing and quotes
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 2 }),
  actualCost: decimal("actual_cost", { precision: 10, scale: 2 }),
  quotedRate: decimal("quoted_rate", { precision: 10, scale: 2 }),
  
  // Timing
  pickupDate: timestamp("pickup_date"),
  estimatedDeliveryDate: timestamp("estimated_delivery_date"),
  actualDeliveryDate: timestamp("actual_delivery_date"),
  
  // Performance metrics
  deliverySuccessRate: decimal("delivery_success_rate", { precision: 5, scale: 2 }),
  averageDeliveryTime: integer("average_delivery_time"), // in hours
  costPerMile: decimal("cost_per_mile", { precision: 8, scale: 4 }),
  
  // Additional data
  dimensions: jsonb("dimensions"), // weight, length, width, height
  specialRequirements: text("special_requirements").array(),
  documents: jsonb("documents"), // URLs to shipping labels, BOLs, etc
  metadata: jsonb("metadata"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Carrier rates table for multi-carrier comparison
export const carrierRates = pgTable("carrier_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shipmentId: varchar("shipment_id").references(() => shipments.id),
  carrierId: varchar("carrier_id").notNull(),
  carrierType: carrierTypeEnum("carrier_type").notNull(),
  carrierName: varchar("carrier_name").notNull(),
  
  // Rate details
  baseRate: decimal("base_rate", { precision: 10, scale: 2 }).notNull(),
  fuelSurcharge: decimal("fuel_surcharge", { precision: 10, scale: 2 }),
  accessorialCharges: decimal("accessorial_charges", { precision: 10, scale: 2 }),
  totalRate: decimal("total_rate", { precision: 10, scale: 2 }).notNull(),
  
  // Service details
  serviceLevel: varchar("service_level"), // Next Day, 2-Day, Ground, etc
  transitTime: integer("transit_time"), // in hours
  guaranteedDelivery: boolean("guaranteed_delivery").default(false),
  trackingIncluded: boolean("tracking_included").default(true),
  
  // Quote metadata
  quoteId: varchar("quote_id"), // external quote reference
  validUntil: timestamp("valid_until"),
  rateSource: varchar("rate_source"), // "api", "manual", "historical"
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Batch operations table
export const batchOperations = pgTable("batch_operations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  batchType: varchar("batch_type").notNull(), // "shipment_creation", "rate_quote", "label_generation"
  status: varchar("status").default("pending"), // "pending", "processing", "completed", "failed"
  
  // Progress tracking
  totalItems: integer("total_items").notNull(),
  processedItems: integer("processed_items").default(0),
  successfulItems: integer("successful_items").default(0),
  failedItems: integer("failed_items").default(0),
  
  // Processing details
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorLog: text("error_log").array(),
  results: jsonb("results"), // detailed results for each item
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Enhanced KPI tracking table
export const kpiMetrics = pgTable("kpi_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  metricType: varchar("metric_type").notNull(), // "delivery_success_rate", "avg_delivery_time", "cost_per_shipment"
  value: decimal("value", { precision: 15, scale: 4 }).notNull(),
  period: analyticsPeriodEnum("period").notNull(),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  
  // Dimensional data
  region: varchar("region"),
  serviceType: serviceTypeEnum("service_type"),
  carrierType: carrierTypeEnum("carrier_type"),
  
  // Metadata
  calculationMethod: varchar("calculation_method"), // "real_time", "batch", "estimated"
  dataSource: varchar("data_source"), // "shipments", "integrations", "manual"
  metadata: jsonb("metadata"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Integration sync logs
export const syncLogs = pgTable("sync_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  integrationId: varchar("integration_id").references(() => integrations.id).notNull(),
  operation: varchar("operation").notNull(), // "sync", "webhook", "manual"
  status: varchar("status").notNull(), // "success", "error", "partial"
  recordsProcessed: integer("records_processed").default(0),
  recordsCreated: integer("records_created").default(0),
  recordsUpdated: integer("records_updated").default(0),
  recordsDeleted: integer("records_deleted").default(0),
  errorCount: integer("error_count").default(0),
  details: jsonb("details"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Lane analytics table for demand and capacity tracking
export const laneAnalytics = pgTable("lane_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originCity: varchar("origin_city").notNull(),
  originState: varchar("origin_state").notNull(),
  destinationCity: varchar("destination_city").notNull(),
  destinationState: varchar("destination_state").notNull(),
  serviceType: serviceTypeEnum("service_type").notNull(),
  period: analyticsPeriodEnum("period").notNull(),
  periodDate: timestamp("period_date").notNull(), // Start of the period
  demandVolume: integer("demand_volume").default(0),
  capacityVolume: integer("capacity_volume").default(0),
  averageRate: decimal("average_rate", { precision: 10, scale: 2 }),
  peakRate: decimal("peak_rate", { precision: 10, scale: 2 }),
  lowRate: decimal("low_rate", { precision: 10, scale: 2 }),
  loadCount: integer("load_count").default(0),
  utilizationRate: decimal("utilization_rate", { precision: 5, scale: 2 }), // percentage
  competitionScore: decimal("competition_score", { precision: 5, scale: 2 }), // 0-100 scale
  seasonalFactor: decimal("seasonal_factor", { precision: 5, scale: 2 }), // multiplier
  trendDirection: varchar("trend_direction"), // "increasing", "decreasing", "stable"
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Regional heatmap data aggregation
export const regionalHeatmap = pgTable("regional_heatmap", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  state: varchar("state").notNull(),
  city: varchar("city"),
  region: varchar("region"), // "northeast", "southeast", "midwest", "southwest", "west"
  dataType: varchar("data_type").notNull(), // "demand", "capacity", "rate"
  serviceType: serviceTypeEnum("service_type"),
  period: analyticsPeriodEnum("period").notNull(),
  periodDate: timestamp("period_date").notNull(),
  value: decimal("value", { precision: 15, scale: 2 }).notNull(),
  intensity: decimal("intensity", { precision: 5, scale: 2 }), // 0-100 normalized intensity for heatmap
  rankOrder: integer("rank_order"), // ranking within the period/type
  percentileRank: decimal("percentile_rank", { precision: 5, scale: 2 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Market trends and forecasting
export const marketTrends = pgTable("market_trends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  metric: varchar("metric").notNull(), // "demand", "capacity", "rates", "volume"
  serviceType: serviceTypeEnum("service_type"),
  region: varchar("region"),
  period: analyticsPeriodEnum("period").notNull(),
  periodDate: timestamp("period_date").notNull(),
  currentValue: decimal("current_value", { precision: 15, scale: 2 }),
  previousValue: decimal("previous_value", { precision: 15, scale: 2 }),
  changePercent: decimal("change_percent", { precision: 7, scale: 4 }),
  volatilityScore: decimal("volatility_score", { precision: 5, scale: 2 }),
  confidence: decimal("confidence", { precision: 5, scale: 2 }), // 0-100 confidence in data
  forecast7d: decimal("forecast_7d", { precision: 15, scale: 2 }),
  forecast30d: decimal("forecast_30d", { precision: 15, scale: 2 }),
  forecast90d: decimal("forecast_90d", { precision: 15, scale: 2 }),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Opportunities table (matching provided schema)
export const opportunities = pgTable("opportunities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  serviceType: text("service_type").notNull(),
  volume: integer("volume"),
  urgency: text("urgency").notNull(),
  value: real("value"),
  postedAt: timestamp("posted_at").defaultNow(),
  status: text("status").default("active"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Matches table (auto-generated matching system)
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  opportunityId: integer("opportunity_id").notNull(),
  partnerId: integer("partner_id").notNull(),
  score: integer("score").notNull(),
  serviceMatch: boolean("service_match").notNull(),
  regionMatch: boolean("region_match").notNull(),
  capacityMatch: boolean("capacity_match").notNull(),
  urgencyMatch: boolean("urgency_match").notNull(),
  status: text("status").default("Pending"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Profiles table (company data)
export const profiles = pgTable("profiles", {
  userId: integer("user_id").primaryKey(),
  companyName: text("company_name"),
  services: text("services"),
  regionsServed: text("regions_served"),
  capacity: text("capacity"),
  contactEmail: text("contact_email"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Partnerships table (confirmed matches and agreements)
export const partnerships = pgTable("partnerships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  opportunityId: varchar("opportunity_id").references(() => opportunities.id).notNull(),
  partnerUserId: varchar("partner_user_id").references(() => users.id).notNull(),
  status: partnershipStatusEnum("status").default("pending"),
  contractValue: decimal("contract_value", { precision: 12, scale: 2 }),
  feeModel: feeModelEnum("fee_model").notNull(),
  feeAmount: decimal("fee_amount", { precision: 8, scale: 2 }),
  feePercentage: decimal("fee_percentage", { precision: 5, scale: 2 }),
  confirmed: boolean("confirmed").default(false),
  confirmedAt: timestamp("confirmed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  partnershipId: varchar("partnership_id").references(() => partnerships.id).notNull(),
  amount: decimal("amount", { precision: 8, scale: 2 }).notNull(),
  status: transactionStatusEnum("status").default("pending"),
  stripePaymentIntentId: varchar("stripe_payment_intent_id"),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  opportunities: many(opportunities),
  partnerships: many(partnerships),
}));

export const opportunitiesRelations = relations(opportunities, ({ one, many }) => ({
  user: one(users, {
    fields: [opportunities.userId],
    references: [users.id],
  }),
  matches: many(matches),
  partnerships: many(partnerships),
}));

export const matchesRelations = relations(matches, ({ one }) => ({
  opportunity: one(opportunities, {
    fields: [matches.opportunityId],
    references: [opportunities.id],
  }),
  partner: one(users, {
    fields: [matches.partnerId],
    references: [users.id],
  }),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const partnershipsRelations = relations(partnerships, ({ one, many }) => ({
  opportunity: one(opportunities, {
    fields: [partnerships.opportunityId],
    references: [opportunities.id],
  }),
  partnerUser: one(users, {
    fields: [partnerships.partnerUserId],
    references: [users.id],
  }),
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  partnership: one(partnerships, {
    fields: [transactions.partnershipId],
    references: [partnerships.id],
  }),
}));



export const integrationsRelations = relations(integrations, ({ one, many }) => ({
  user: one(users, {
    fields: [integrations.userId],
    references: [users.id],
  }),
  capacityData: many(capacityData),
  syncLogs: many(syncLogs),
}));

export const capacityDataRelations = relations(capacityData, ({ one }) => ({
  integration: one(integrations, {
    fields: [capacityData.integrationId],
    references: [integrations.id],
  }),
}));

export const syncLogsRelations = relations(syncLogs, ({ one }) => ({
  integration: one(integrations, {
    fields: [syncLogs.integrationId],
    references: [integrations.id],
  }),
}));

export const laneAnalyticsRelations = relations(laneAnalytics, ({ one }) => ({
  // No direct foreign key relationships, but could be linked to opportunities
}));

export const regionalHeatmapRelations = relations(regionalHeatmap, ({ one }) => ({
  // Regional data aggregations
}));

export const marketTrendsRelations = relations(marketTrends, ({ one }) => ({
  // Market trend data
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOpportunitySchema = createInsertSchema(opportunities).omit({
  id: true,
  postedAt: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPartnershipSchema = createInsertSchema(partnerships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertIntegrationSchema = createInsertSchema(integrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastSyncAt: true,
});

export const insertCapacityDataSchema = createInsertSchema(capacityData).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  syncedAt: true,
});

export const insertSyncLogSchema = createInsertSchema(syncLogs).omit({
  id: true,
  createdAt: true,
  startedAt: true,
});

export const insertLaneAnalyticsSchema = createInsertSchema(laneAnalytics).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRegionalHeatmapSchema = createInsertSchema(regionalHeatmap).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMarketTrendsSchema = createInsertSchema(marketTrends).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Shipment schemas
export const insertShipmentSchema = createInsertSchema(shipments);
export type InsertShipment = z.infer<typeof insertShipmentSchema>;
export type Shipment = typeof shipments.$inferSelect;

// Carrier rates schemas
export const insertCarrierRateSchema = createInsertSchema(carrierRates);
export type InsertCarrierRate = z.infer<typeof insertCarrierRateSchema>;
export type CarrierRate = typeof carrierRates.$inferSelect;

// Batch operations schemas
export const insertBatchOperationSchema = createInsertSchema(batchOperations);
export type InsertBatchOperation = z.infer<typeof insertBatchOperationSchema>;
export type BatchOperation = typeof batchOperations.$inferSelect;

// KPI metrics schemas
export const insertKpiMetricSchema = createInsertSchema(kpiMetrics);
export type InsertKpiMetric = z.infer<typeof insertKpiMetricSchema>;
export type KpiMetric = typeof kpiMetrics.$inferSelect;

// Types
// Conversations table for messaging
export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subject: varchar("subject").notNull(),
  status: conversationStatusEnum("status").default("active"),
  relatedOpportunityId: varchar("related_opportunity_id"),
  relatedPartnershipId: varchar("related_partnership_id"),
  relatedTransactionId: varchar("related_transaction_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastMessageAt: timestamp("last_message_at").defaultNow(),
});

// Conversation participants table (many-to-many relationship)
export const conversationParticipants = pgTable("conversation_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").references(() => conversations.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
  lastReadAt: timestamp("last_read_at").defaultNow(),
  isAdmin: boolean("is_admin").default(false),
});

// Messages table
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").references(() => conversations.id).notNull(),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  messageType: messageTypeEnum("message_type").default("text"),
  attachmentUrl: varchar("attachment_url"),
  attachmentName: varchar("attachment_name"),
  isEdited: boolean("is_edited").default(false),
  isDeleted: boolean("is_deleted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Messaging types
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;
export type ConversationParticipant = typeof conversationParticipants.$inferSelect;
export type InsertConversationParticipant = typeof conversationParticipants.$inferInsert;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Messaging insert schemas
export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastMessageAt: true,
});

export const insertConversationParticipantSchema = createInsertSchema(conversationParticipants).omit({
  id: true,
  joinedAt: true,
  lastReadAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  isEdited: true,
  isDeleted: true,
});



// Add messaging relations at the end to avoid initialization order issues
export const conversationsRelations = relations(conversations, ({ many }) => ({
  participants: many(conversationParticipants),
  messages: many(messages),
}));

export const conversationParticipantsRelations = relations(conversationParticipants, ({ one }) => ({
  conversation: one(conversations, {
    fields: [conversationParticipants.conversationId],
    references: [conversations.id],
  }),
  user: one(users, {
    fields: [conversationParticipants.userId],
    references: [users.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
  }),
}));







// Mobile app types (defined at the end to avoid initialization issues)
export type FieldOperation = typeof fieldOperations.$inferSelect;
export type InsertFieldOperation = typeof fieldOperations.$inferInsert;
export type LocationTracking = typeof locationTracking.$inferSelect;
export type InsertLocationTracking = typeof locationTracking.$inferInsert;
export type MobileSession = typeof mobileSessions.$inferSelect;
export type InsertMobileSession = typeof mobileSessions.$inferInsert;
export type OfflineQueue = typeof offlineQueue.$inferSelect;
export type InsertOfflineQueue = typeof offlineQueue.$inferInsert;
export type FieldOperationLog = typeof fieldOperationLogs.$inferSelect;
export type InsertFieldOperationLog = typeof fieldOperationLogs.$inferInsert;



// Type exports for updated schema
export type Opportunity = typeof opportunities.$inferSelect;
export type Match = typeof matches.$inferSelect;
export type Profile = typeof profiles.$inferSelect;

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProfileSchema = createInsertSchema(profiles).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type InsertProfile = z.infer<typeof insertProfileSchema>;

export type Partnership = typeof partnerships.$inferSelect;
export type InsertPartnership = z.infer<typeof insertPartnershipSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;

export type CapacityData = typeof capacityData.$inferSelect;
export type InsertCapacityData = z.infer<typeof insertCapacityDataSchema>;

export type SyncLog = typeof syncLogs.$inferSelect;
export type InsertSyncLog = z.infer<typeof insertSyncLogSchema>;

export type LaneAnalytics = typeof laneAnalytics.$inferSelect;
export type InsertLaneAnalytics = z.infer<typeof insertLaneAnalyticsSchema>;

export type RegionalHeatmap = typeof regionalHeatmap.$inferSelect;
export type InsertRegionalHeatmap = z.infer<typeof insertRegionalHeatmapSchema>;

export type MarketTrends = typeof marketTrends.$inferSelect;
export type InsertMarketTrends = z.infer<typeof insertMarketTrendsSchema>;

// Mobile app field operations tables - defined before the rest
export const fieldOperations = pgTable("field_operations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  opportunityId: varchar("opportunity_id").references(() => opportunities.id),
  partnershipId: varchar("partnership_id").references(() => partnerships.id),
  title: varchar("title").notNull(),
  description: text("description"),
  status: fieldOperationStatusEnum("status").default("pending"),
  priority: integer("priority").default(1), // 1-5 scale
  scheduledStartTime: timestamp("scheduled_start_time"),
  scheduledEndTime: timestamp("scheduled_end_time"),
  actualStartTime: timestamp("actual_start_time"),
  actualEndTime: timestamp("actual_end_time"),
  originAddress: text("origin_address"),
  destinationAddress: text("destination_address"),
  notes: text("notes"),
  attachments: text("attachments").array(), // URLs to uploaded files
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Location tracking for field operations
export const locationTracking = pgTable("location_tracking", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  fieldOperationId: varchar("field_operation_id").references(() => fieldOperations.id),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  accuracy: decimal("accuracy", { precision: 6, scale: 2 }), // in meters
  altitude: decimal("altitude", { precision: 8, scale: 2 }), // in meters
  speed: decimal("speed", { precision: 6, scale: 2 }), // in km/h
  heading: decimal("heading", { precision: 6, scale: 2 }), // in degrees
  status: locationStatusEnum("status").default("active"),
  timestamp: timestamp("timestamp").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Mobile device sessions for PWA support
export const mobileSessions = pgTable("mobile_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  deviceType: deviceTypeEnum("device_type").notNull(),
  deviceId: varchar("device_id"), // unique device identifier
  userAgent: text("user_agent"),
  isOnline: boolean("is_online").default(true),
  lastSync: timestamp("last_sync").defaultNow(),
  appVersion: varchar("app_version"),
  pushToken: varchar("push_token"), // for push notifications
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Offline data queue for sync when connection restored
export const offlineQueue = pgTable("offline_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  action: varchar("action").notNull(), // CREATE, UPDATE, DELETE
  resource: varchar("resource").notNull(), // table/endpoint name
  resourceId: varchar("resource_id"),
  data: jsonb("data").notNull(),
  synced: boolean("synced").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  syncedAt: timestamp("synced_at"),
});

// Field operation updates/logs
export const fieldOperationLogs = pgTable("field_operation_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fieldOperationId: varchar("field_operation_id").references(() => fieldOperations.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  action: varchar("action").notNull(), // started, paused, completed, updated
  description: text("description"),
  location: jsonb("location"), // lat, lng, address
  timestamp: timestamp("timestamp").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Role Context table for dual-role functionality
export const roleContexts = pgTable("role_contexts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  context: roleContextEnum("context").notNull(), // provider or requester
  isActive: boolean("is_active").default(true),
  lastSwitchedAt: timestamp("last_switched_at").defaultNow(),
  preferences: jsonb("preferences"), // role-specific preferences
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// KYC Documents table for identity verification
export const kycDocuments = pgTable("kyc_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  documentType: kycDocumentTypeEnum("document_type").notNull(),
  documentNumber: varchar("document_number"),
  documentUrl: varchar("document_url"), // URL to stored document
  verificationStatus: verificationStatusEnum("verification_status").default("pending"),
  verifiedBy: varchar("verified_by"), // Admin user ID
  verifiedAt: timestamp("verified_at"),
  expiryDate: timestamp("expiry_date"),
  rejectionReason: text("rejection_reason"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Performance Metrics table for tracking 3PL performance
export const performanceMetrics = pgTable("performance_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  roleContext: roleContextEnum("role_context").notNull(),
  
  // Performance KPIs
  onTimeDeliveryRate: decimal("on_time_delivery_rate", { precision: 5, scale: 2 }),
  averageDeliveryTime: decimal("average_delivery_time", { precision: 8, scale: 2 }), // hours
  customerSatisfactionScore: decimal("customer_satisfaction_score", { precision: 3, scale: 2 }),
  costEfficiencyRating: decimal("cost_efficiency_rating", { precision: 3, scale: 2 }),
  communicationRating: decimal("communication_rating", { precision: 3, scale: 2 }),
  overallRating: performanceRatingEnum("overall_rating").default("unrated"),
  
  // Aggregate data
  totalShipments: integer("total_shipments").default(0),
  totalRevenue: decimal("total_revenue", { precision: 12, scale: 2 }),
  averageOrderValue: decimal("average_order_value", { precision: 10, scale: 2 }),
  
  // Time period
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Disputes table for conflict resolution
export const disputes = pgTable("disputes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  partnershipId: varchar("partnership_id").references(() => partnerships.id),
  shipmentId: varchar("shipment_id").references(() => shipments.id),
  reportedBy: varchar("reported_by").references(() => users.id).notNull(),
  reportedAgainst: varchar("reported_against").references(() => users.id).notNull(),
  
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  category: varchar("category"), // e.g., "payment", "delivery", "damage", "service"
  status: disputeStatusEnum("status").default("open"),
  priority: varchar("priority").default("medium"), // low, medium, high, urgent
  
  // Resolution details
  assignedTo: varchar("assigned_to"), // Admin/mediator user ID
  resolutionNotes: text("resolution_notes"),
  resolutionAmount: decimal("resolution_amount", { precision: 10, scale: 2 }),
  resolvedAt: timestamp("resolved_at"),
  
  // Evidence and communication
  evidence: jsonb("evidence"), // URLs to documents, images, etc.
  internalNotes: text("internal_notes"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insurance Certificates table
export const insuranceCertificates = pgTable("insurance_certificates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  insuranceType: insuranceTypeEnum("insurance_type").notNull(),
  
  // Insurance details
  provider: varchar("provider").notNull(),
  policyNumber: varchar("policy_number").notNull(),
  coverageAmount: decimal("coverage_amount", { precision: 12, scale: 2 }),
  deductible: decimal("deductible", { precision: 10, scale: 2 }),
  
  // Validity
  effectiveDate: timestamp("effective_date").notNull(),
  expiryDate: timestamp("expiry_date").notNull(),
  verificationStatus: verificationStatusEnum("verification_status").default("pending"),
  
  // Documents
  certificateUrl: varchar("certificate_url"), // URL to certificate document
  verifiedBy: varchar("verified_by"),
  verifiedAt: timestamp("verified_at"),
  
  // Additional info
  additionalInsured: text("additional_insured"), // List of additionally insured parties
  specialConditions: text("special_conditions"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User Activity Log for role switching and security tracking
export const userActivityLog = pgTable("user_activity_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  action: varchar("action").notNull(), // e.g., "role_switch", "login", "document_upload"
  details: jsonb("details"), // Additional context about the action
  roleContext: roleContextEnum("role_context"),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Insert schemas for new tables
export const insertRoleContextSchema = createInsertSchema(roleContexts);
export const insertKycDocumentSchema = createInsertSchema(kycDocuments);
export const insertPerformanceMetricsSchema = createInsertSchema(performanceMetrics);
export const insertDisputeSchema = createInsertSchema(disputes);
export const insertInsuranceCertificateSchema = createInsertSchema(insuranceCertificates);
export const insertUserActivityLogSchema = createInsertSchema(userActivityLog);

// Types for new tables
export type RoleContext = typeof roleContexts.$inferSelect;
export type InsertRoleContext = z.infer<typeof insertRoleContextSchema>;
export type KycDocument = typeof kycDocuments.$inferSelect;
export type InsertKycDocument = z.infer<typeof insertKycDocumentSchema>;
export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = z.infer<typeof insertPerformanceMetricsSchema>;
export type Dispute = typeof disputes.$inferSelect;
export type InsertDispute = z.infer<typeof insertDisputeSchema>;
export type InsuranceCertificate = typeof insuranceCertificates.$inferSelect;
export type InsertInsuranceCertificate = z.infer<typeof insertInsuranceCertificateSchema>;
export type UserActivityLog = typeof userActivityLog.$inferSelect;
export type InsertUserActivityLog = z.infer<typeof insertUserActivityLogSchema>;


