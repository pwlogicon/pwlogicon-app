import { useToast } from "@/hooks/use-toast";
import UnifiedDashboard from "@/components/UnifiedDashboard";

export default function UnifiedDashboardPage() {
  const { toast } = useToast();

  const handleOrderAction = (orderId: string, action: string) => {
    toast({
      title: `Order ${action}`,
      description: `${action === 'view' ? 'Opening' : 'Processing'} order ${orderId}`,
    });
  };

  const handleShipmentAction = (shipmentId: string, action: string) => {
    toast({
      title: `Shipment ${action}`,
      description: `${action === 'track' ? 'Tracking' : 'Updating'} shipment ${shipmentId}`,
    });
  };

  const handleRefreshData = () => {
    toast({
      title: "Data synchronized",
      description: "All systems refreshed and synced successfully",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <UnifiedDashboard
        onOrderAction={handleOrderAction}
        onShipmentAction={handleShipmentAction}
        onRefreshData={handleRefreshData}
      />
    </div>
  );
}