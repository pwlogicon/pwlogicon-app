import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useOfflineSync } from '@/hooks/useOfflineSync';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useEffect } from 'react';
import { isUnauthorizedError } from '@/lib/authUtils';
import { 
  MapPin, 
  Clock, 
  Truck, 
  Plus, 
  Play, 
  Pause, 
  CheckCircle,
  AlertTriangle,
  Wifi,
  WifiOff,
  RotateCcw,
  Navigation,
  Phone,
  MessageSquare,
  Camera
} from 'lucide-react';

export default function Mobile() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedOperation, setSelectedOperation] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 1,
    originAddress: '',
    destinationAddress: '',
  });

  // Geolocation and offline sync hooks
  const { position, error: locationError, getCurrentPosition, isSupported: gpsSupported } = useGeolocation({
    enableHighAccuracy: true,
    watchPosition: false,
  });

  const { isOnline, pendingCount, addToQueue, syncNow, isSyncing } = useOfflineSync();

  // Fetch mobile dashboard data
  const { data: dashboardData, isLoading: dashboardLoading } = useQuery({
    queryKey: ['/api/mobile/dashboard'],
    enabled: isAuthenticated,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch field operations
  const { data: fieldOperations, isLoading: operationsLoading } = useQuery({
    queryKey: ['/api/mobile/field-operations'],
    enabled: isAuthenticated,
  });

  // Create field operation mutation
  const createOperationMutation = useMutation({
    mutationFn: async (data: any) => {
      if (isOnline) {
        return await apiRequest('POST', '/api/mobile/field-operations', data);
      } else {
        // Add to offline queue
        addToQueue({
          action: 'CREATE',
          resource: 'field_operations',
          data: { ...data, id: crypto.randomUUID() },
        });
        return { id: crypto.randomUUID(), ...data };
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/field-operations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/dashboard'] });
      setShowCreateDialog(false);
      setFormData({ title: '', description: '', priority: 1, originAddress: '', destinationAddress: '' });
      toast({
        title: 'Field Operation Created',
        description: isOnline ? 'Operation created successfully' : 'Operation saved offline and will sync when connection returns',
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: 'Error',
        description: 'Failed to create field operation',
        variant: 'destructive',
      });
    },
  });

  // Update operation status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const updateData = { 
        status,
        ...(status === 'in_progress' && { actualStartTime: new Date().toISOString() }),
        ...(status === 'completed' && { actualEndTime: new Date().toISOString() }),
      };

      if (isOnline) {
        return await apiRequest('PUT', `/api/mobile/field-operations/${id}`, updateData);
      } else {
        addToQueue({
          action: 'UPDATE',
          resource: 'field_operations',
          resourceId: id,
          data: updateData,
        });
        return { id, ...updateData };
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/field-operations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/dashboard'] });
      toast({
        title: 'Status Updated',
        description: isOnline ? 'Operation status updated' : 'Status saved offline and will sync when connection returns',
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: 'Error',
        description: 'Failed to update operation status',
        variant: 'destructive',
      });
    },
  });

  // Record location mutation
  const recordLocationMutation = useMutation({
    mutationFn: async (locationData: any) => {
      if (isOnline) {
        return await apiRequest('POST', '/api/mobile/location', locationData);
      } else {
        addToQueue({
          action: 'CREATE',
          resource: 'location_tracking',
          data: { ...locationData, id: crypto.randomUUID() },
        });
        return { id: crypto.randomUUID(), ...locationData };
      }
    },
    onSuccess: () => {
      toast({
        title: 'Location Recorded',
        description: isOnline ? 'Location recorded successfully' : 'Location saved offline and will sync when connection returns',
      });
    },
  });

  // Auto-record location when GPS position changes
  useEffect(() => {
    if (position && selectedOperation) {
      recordLocationMutation.mutate({
        fieldOperationId: selectedOperation.id,
        latitude: position.latitude.toString(),
        longitude: position.longitude.toString(),
        accuracy: position.accuracy.toString(),
        altitude: position.altitude?.toString(),
        speed: position.speed?.toString(),
        heading: position.heading?.toString(),
      });
    }
  }, [position, selectedOperation]);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Skeleton className="w-8 h-8 rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const handleCreateOperation = () => {
    createOperationMutation.mutate(formData);
  };

  const handleStatusUpdate = (operation: any, newStatus: string) => {
    updateStatusMutation.mutate({ id: operation.id, status: newStatus });
    if (newStatus === 'in_progress') {
      setSelectedOperation(operation);
      getCurrentPosition(); // Start GPS tracking
    } else if (newStatus === 'completed') {
      setSelectedOperation(null);
    }
  };

  const getStatusBadge = (status: string) => {
    const config: { [key: string]: { variant: any; label: string; icon: any } } = {
      pending: { variant: 'secondary', label: 'Pending', icon: Clock },
      in_progress: { variant: 'default', label: 'In Progress', icon: Play },
      completed: { variant: 'default', label: 'Completed', icon: CheckCircle },
      delayed: { variant: 'destructive', label: 'Delayed', icon: AlertTriangle },
    };
    
    const { variant, label, icon: Icon } = config[status] || { variant: 'secondary', label: status, icon: Clock };
    
    return (
      <Badge variant={variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {label}
      </Badge>
    );
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 4) return 'text-red-600';
    if (priority >= 3) return 'text-orange-600';
    return 'text-green-600';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Field Operations</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {user?.firstName} {user?.lastName} - {user?.role}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {/* Connection Status */}
              <div className="flex items-center gap-1">
                {isOnline ? (
                  <Wifi className="h-4 w-4 text-green-600" />
                ) : (
                  <WifiOff className="h-4 w-4 text-red-600" />
                )}
                {pendingCount > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {pendingCount}
                  </Badge>
                )}
              </div>
              
              {/* Sync Button */}
              <Button
                size="sm"
                variant="outline"
                onClick={syncNow}
                disabled={isSyncing || pendingCount === 0}
              >
                <RotateCcw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Dashboard Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active</p>
                  <p className="text-2xl font-bold">
                    {dashboardLoading ? (
                      <Skeleton className="h-8 w-8" />
                    ) : (
                      dashboardData?.activeOperationsCount || 0
                    )}
                  </p>
                </div>
                <Truck className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Today</p>
                  <p className="text-2xl font-bold">
                    {dashboardLoading ? (
                      <Skeleton className="h-8 w-8" />
                    ) : (
                      dashboardData?.todaysOperations?.length || 0
                    )}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* GPS Status */}
        {gpsSupported && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Navigation className="h-5 w-5" />
                  <span className="font-medium">GPS Status</span>
                </div>
                <div className="flex items-center gap-2">
                  {position ? (
                    <Badge variant="default" className="bg-green-600">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary">
                      {locationError ? 'Error' : 'Inactive'}
                    </Badge>
                  )}
                  <Button size="sm" variant="outline" onClick={getCurrentPosition}>
                    Update
                  </Button>
                </div>
              </div>
              {position && (
                <div className="mt-2 text-xs text-gray-600 dark:text-gray-400">
                  Lat: {position.latitude.toFixed(6)}, Lng: {position.longitude.toFixed(6)}
                  <br />
                  Accuracy: {position.accuracy.toFixed(0)}m
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Create Operation Button */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="w-full" size="lg">
              <Plus className="h-5 w-5 mr-2" />
              New Field Operation
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Field Operation</DialogTitle>
              <DialogDescription>
                Create a new field operation to track progress and location.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Operation title"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Operation description"
                />
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select 
                  value={formData.priority.toString()} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, priority: parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Low Priority</SelectItem>
                    <SelectItem value="2">Normal Priority</SelectItem>
                    <SelectItem value="3">High Priority</SelectItem>
                    <SelectItem value="4">Urgent</SelectItem>
                    <SelectItem value="5">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="originAddress">Origin Address</Label>
                <Input
                  id="originAddress"
                  value={formData.originAddress}
                  onChange={(e) => setFormData(prev => ({ ...prev, originAddress: e.target.value }))}
                  placeholder="Pickup location"
                />
              </div>
              <div>
                <Label htmlFor="destinationAddress">Destination Address</Label>
                <Input
                  id="destinationAddress"
                  value={formData.destinationAddress}
                  onChange={(e) => setFormData(prev => ({ ...prev, destinationAddress: e.target.value }))}
                  placeholder="Delivery location"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateOperation}
                disabled={createOperationMutation.isPending || !formData.title}
              >
                {createOperationMutation.isPending ? 'Creating...' : 'Create Operation'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Field Operations List */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Active Operations</h2>
          
          {operationsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <Skeleton className="h-20 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : fieldOperations?.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Truck className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 dark:text-gray-400">No field operations yet</p>
                <p className="text-sm text-gray-500 dark:text-gray-500">Create your first operation to get started</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {(fieldOperations || []).map((operation: any) => (
                <Card key={operation.id} className="relative">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{operation.title}</h3>
                        {operation.description && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {operation.description}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        {getStatusBadge(operation.status)}
                        <span className={`text-xs font-medium ${getPriorityColor(operation.priority)}`}>
                          Priority {operation.priority}
                        </span>
                      </div>
                    </div>

                    {operation.originAddress && (
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-2">
                        <MapPin className="h-4 w-4" />
                        <span>{operation.originAddress}</span>
                        {operation.destinationAddress && (
                          <>
                            <span>→</span>
                            <span>{operation.destinationAddress}</span>
                          </>
                        )}
                      </div>
                    )}

                    {operation.scheduledStartTime && (
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-3">
                        <Clock className="h-4 w-4" />
                        <span>
                          Scheduled: {new Date(operation.scheduledStartTime).toLocaleString()}
                        </span>
                      </div>
                    )}

                    <div className="flex gap-2 mt-3">
                      {operation.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusUpdate(operation, 'in_progress')}
                          disabled={updateStatusMutation.isPending}
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Start
                        </Button>
                      )}
                      
                      {operation.status === 'in_progress' && (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleStatusUpdate(operation, 'pending')}
                            disabled={updateStatusMutation.isPending}
                          >
                            <Pause className="h-4 w-4 mr-1" />
                            Pause
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleStatusUpdate(operation, 'completed')}
                            disabled={updateStatusMutation.isPending}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Complete
                          </Button>
                        </>
                      )}

                      {/* Quick action buttons */}
                      <div className="ml-auto flex gap-1">
                        <Button size="sm" variant="outline">
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Camera className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}