import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { useState } from "react";
import { 
  Plus, 
  Truck, 
  Search, 
  Clock, 
  DollarSign, 
  Building, 
  User, 
  CheckCircle,
  ArrowLeft,
  AlertCircle
} from "lucide-react";
import OpportunityCard from "@/components/OpportunityCard";
import CreateOpportunityModal from "@/components/CreateOpportunityModal";
import MatchingModal from "@/components/MatchingModal";
import PredictiveETA from "@/components/PredictiveETA";
import { Tooltip } from "@/components/ui/tooltip";
import { getContextualInsight, getRandomInsight } from "@/utils/logisticsInsights";

export default function Opportunities() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [matchingModalOpen, setMatchingModalOpen] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<any>(null);

  const { data: opportunities, isLoading: opportunitiesLoading, error } = useQuery({
    queryKey: ["/api/opportunities"],
    enabled: isAuthenticated,
  });

  const opportunitiesList = Array.isArray(opportunities) ? opportunities : [];

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Skeleton className="w-8 h-8 rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <p className="text-gray-600">Please log in to view opportunities</p>
            <Button className="mt-4" onClick={() => window.location.href = "/api/login"}>
              Log In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleViewMatches = (opportunityId: string) => {
    const opportunity = opportunitiesList.find(opp => opp.id === opportunityId);
    setSelectedOpportunity(opportunity);
    setMatchingModalOpen(true);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              💼 Active Opportunities
            </h1>
            <p className="text-gray-600 mt-1">
              Discover partnerships and capacity opportunities across the logistics network
            </p>
          </div>
        </div>
        
        <Button onClick={() => setCreateModalOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Create New Opportunity
        </Button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Opportunities</p>
                <p className="text-2xl font-bold">
                  {opportunitiesLoading ? "..." : opportunitiesList.length}
                </p>
              </div>
              <Plus className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Capacity Offers</p>
                <p className="text-2xl font-bold">
                  {opportunitiesLoading ? "..." : opportunitiesList.filter((opp: any) => opp.type === 'capacity_offer').length}
                </p>
              </div>
              <Truck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Lane Needs</p>
                <p className="text-2xl font-bold">
                  {opportunitiesLoading ? "..." : opportunitiesList.filter((opp: any) => opp.type === 'lane_need').length}
                </p>
              </div>
              <Search className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Matches</p>
                <p className="text-2xl font-bold">
                  {opportunitiesLoading ? "..." : opportunitiesList.filter((opp: any) => opp.status === 'matched').length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-emerald-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Opportunities List */}
      <div className="space-y-4">
        {opportunitiesLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <Skeleton className="h-6 w-48 mb-2" />
                      <Skeleton className="h-4 w-96 mb-2" />
                      <Skeleton className="h-4 w-72" />
                    </div>
                    <Skeleton className="h-10 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <Card>
            <CardContent className="p-6 text-center">
              <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Error Loading Opportunities</h3>
              <p className="text-gray-600">
                There was an issue loading opportunities. Please try again.
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => window.location.reload()}
              >
                Retry
              </Button>
            </CardContent>
          </Card>
        ) : opportunitiesList.length > 0 ? (
          <div className="space-y-4">
            {opportunitiesList.map((opportunity: any) => (
              <Card key={opportunity.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {opportunity.type === 'capacity_offer' ? '🚛 Offering' : '🔍 Needing'} {opportunity.serviceType || opportunity.service_type}
                        </h3>
                        <Badge variant={opportunity.urgency === 'Urgent' ? 'destructive' : 'secondary'}>
                          {opportunity.urgency === 'Urgent' ? '🔥 Hot' : '⏱️ Standard'}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 mb-2">
                        From <strong>{opportunity.origin}</strong> to <strong>{opportunity.destination}</strong>
                      </p>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-2">
                        <span>Volume: {opportunity.volume || '?'}</span>
                        {opportunity.value && (
                          <span className="text-green-600 font-medium">💰 Est. Value: ${opportunity.value}</span>
                        )}
                        {opportunity.pricingRange && (
                          <span className="text-green-600 font-medium">💰 Price: {opportunity.pricingRange}</span>
                        )}
                      </div>
                      
                      {opportunity.description && (
                        <p className="text-gray-600 text-sm mb-2">{opportunity.description}</p>
                      )}
                      
                      <p className="text-xs text-gray-400">
                        Posted by: <em>{opportunity.company_name || opportunity.userCompanyName || 'A partner'} ({opportunity.role || opportunity.userRole})</em>
                      </p>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewMatches(opportunity.id)}
                    >
                      View Matches
                    </Button>
                  </div>
                  
                  {/* Add PredictiveETA for urgent or high-value opportunities */}
                  {(opportunity.urgency === 'Urgent' || (opportunity.value && opportunity.value > 2000)) && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <PredictiveETA opportunityId={opportunity.id} />
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No Opportunities Yet
              </h3>
              <p className="text-gray-600 mb-6">
                Create your first opportunity to start connecting with logistics partners
              </p>
              <Button onClick={() => setCreateModalOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create First Opportunity
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Modals */}
      <CreateOpportunityModal 
        open={createModalOpen} 
        onOpenChange={setCreateModalOpen} 
      />
      
      {selectedOpportunity && (
        <MatchingModal
          open={matchingModalOpen}
          onOpenChange={setMatchingModalOpen}
          opportunityId={selectedOpportunity.id}
          opportunityTitle={`${selectedOpportunity.type === 'capacity_offer' ? 'Capacity' : 'Lane Need'} - ${selectedOpportunity.origin} to ${selectedOpportunity.destination}`}
        />
      )}
    </div>
  );
}