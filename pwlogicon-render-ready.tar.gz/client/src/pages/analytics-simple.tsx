import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

import { ResponsiveContainer, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, Bar } from "recharts";

export default function AnalyticsSimple() {
  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ["/api/analytics/simple"],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto mt-4 max-w-4xl">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-300 rounded w-1/3"></div>
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-24 bg-gray-300 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const { stats, laneData, monthlyMatches } = (analyticsData as any) || {};

  const chartData = monthlyMatches ? [
    { name: 'Jan', matches: monthlyMatches[0] || 0 },
    { name: 'Feb', matches: monthlyMatches[1] || 0 },
    { name: 'Mar', matches: monthlyMatches[2] || 0 },
    { name: 'Apr', matches: monthlyMatches[3] || 0 },
    { name: 'May', matches: monthlyMatches[4] || 0 },
    { name: 'Jun', matches: monthlyMatches[5] || 0 },
  ] : [];

  return (
    <div className="container mx-auto mt-4 max-w-4xl">
      <h1 className="display-6 mb-3">📊 PWLoGiCon Analytics</h1>
      <p className="text-muted mb-4">
        Insights from partner matches and opportunity trends.
      </p>

      {/* Stats Cards */}
      <div className="row mb-4">
        <div className="col-md-4">
          <Card className="p-3 border-0" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h5>Total Matches</h5>
            <div className="metric" style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
              {stats?.totalMatches || 0}
            </div>
          </Card>
        </div>
        <div className="col-md-4">
          <Card className="p-3 border-0" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h5>Success Rate</h5>
            <div className="metric" style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
              {stats?.successRate || 0}%
            </div>
          </Card>
        </div>
        <div className="col-md-4">
          <Card className="p-3 border-0" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h5>Avg. Savings</h5>
            <div className="metric" style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#007bff' }}>
              ${stats?.avgSavings?.toLocaleString() || 0}
            </div>
          </Card>
        </div>
      </div>

      {/* Monthly Chart */}
      <div className="mt-4 mb-4">
        <h3>📈 Monthly Matches</h3>
        <Card className="p-3">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="matches" fill="#007bff" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Top Lanes */}
      <div className="mt-4 mb-4">
        <h3>🚚 Top Lanes by Demand</h3>
        <ul className="list-group">
          {laneData?.map((lane: any, index: number) => (
            <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
              <strong>{lane.from} → {lane.to}</strong>
              <Badge className="bg-primary">{lane.count} matches</Badge>
            </li>
          ))}
        </ul>
      </div>

      {/* Lane Demand Heatmap */}
      <div className="mt-4 mb-4">
        <h3>🌐 Lane Demand Heatmap (Simulated)</h3>
        <div className="bg-light p-3 rounded">
          Chicago → Dallas: 🔥🔥🔥🔥🔥<br />
          LA → Phoenix: 🔥🔥🔥🔥<br />
          Atlanta → Charlotte: 🔥🔥🔥<br />
          Newark → Philly: 🔥🔥
        </div>
      </div>

      <hr className="my-4" />
      
      <Link href="/dashboard">
        <Button variant="secondary" className="btn btn-secondary">
          <ArrowLeft className="h-4 w-4 mr-2" />
          ← Back
        </Button>
      </Link>
    </div>
  );
}