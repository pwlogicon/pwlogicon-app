import { useToast } from "@/hooks/use-toast";
import PredictiveAnalytics from "@/components/PredictiveAnalytics";

export default function PredictiveAnalyticsPage() {
  const { toast } = useToast();

  const handleApplyOptimization = (optimizationId: string) => {
    const optimizationType = optimizationId.split('-')[0];
    const successMessages = {
      capacity: "Capacity optimization applied - carrier outreach initiated",
      pricing: "Pricing optimization applied - rates updated across platform",
      demand: "Demand forecast optimization applied - resource allocation updated"
    };

    toast({
      title: "AI Optimization Applied",
      description: successMessages[optimizationType as keyof typeof successMessages] || "Optimization strategy implemented successfully",
    });
  };

  const handleResolveException = (exceptionId: string, action: string) => {
    const actionMessages = {
      auto: "Exception resolved automatically using AI recommendations",
      manual: "Exception escalated to operations team for manual review"
    };

    toast({
      title: `Exception ${exceptionId}`,
      description: actionMessages[action as keyof typeof actionMessages],
    });
  };

  const handleSchedulePrediction = (lane: string, timeframe: string) => {
    toast({
      title: "Prediction Alert Scheduled",
      description: `AI will monitor ${lane} for capacity changes over ${timeframe}`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <PredictiveAnalytics
        onApplyOptimization={handleApplyOptimization}
        onResolveException={handleResolveException}
        onSchedulePrediction={handleSchedulePrediction}
      />
    </div>
  );
}