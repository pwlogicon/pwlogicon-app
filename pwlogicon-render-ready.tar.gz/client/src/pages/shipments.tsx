import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import SyncProgressIndicator from "@/components/SyncProgressIndicator";
import BatchProgressModal from "@/components/BatchProgressModal";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import {
  Package,
  Truck,
  Clock,
  DollarSign,
  CheckCircle,
  AlertCircle,
  Plus,
  Upload,
  RefreshCw,
  BarChart3
} from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function Shipments() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isBatchDialogOpen, setIsBatchDialogOpen] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<any>(null);
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [currentBatchOperation, setCurrentBatchOperation] = useState<any>(null);
  const [activeSyncs, setActiveSyncs] = useState<any[]>([]);

  // Fetch shipments
  const { data: shipments, isLoading: shipmentsLoading } = useQuery({
    queryKey: ["/api/shipments"],
    enabled: isAuthenticated,
  });

  // Fetch KPI metrics
  const { data: kpiMetrics, isLoading: kpiLoading } = useQuery({
    queryKey: ["/api/shipments/kpi"],
    enabled: isAuthenticated,
  });

  // Create shipment mutation
  const createShipmentMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/shipments", { method: "POST", body: data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shipments"] });
      setIsCreateDialogOpen(false);
      toast({ title: "Success", description: "Shipment created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create shipment", variant: "destructive" });
    },
  });

  // Get carrier rates mutation
  const getCarrierRatesMutation = useMutation({
    mutationFn: (shipmentId: string) => apiRequest(`/api/shipments/${shipmentId}/rates`, { method: "POST" }),
    onSuccess: (data) => {
      setSelectedShipment(data);
      toast({ title: "Success", description: "Carrier rates retrieved successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to get carrier rates", variant: "destructive" });
    },
  });

  // Batch processing mutation
  const batchProcessMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/shipments/batch", { method: "POST", body: data }),
    onSuccess: (data) => {
      // Start batch operation with progress tracking
      const batchOp = {
        id: data.id,
        name: "Batch Rate Quote Processing",
        type: "rate_quote",
        status: "processing",
        totalItems: data.totalItems,
        processedItems: 0,
        successfulItems: 0,
        failedItems: 0,
        startTime: new Date(),
        estimatedCompletion: data.estimatedCompletion,
        items: Array.from({ length: data.totalItems }, (_, i) => ({
          id: `item-${i + 1}`,
          name: `Shipment ${i + 1}`,
          status: 'pending',
          progress: 0
        }))
      };
      setCurrentBatchOperation(batchOp);
      setShowBatchModal(true);
      
      // Simulate progress updates
      simulateBatchProgress(batchOp);
      
      queryClient.invalidateQueries({ queryKey: ["/api/shipments"] });
      setIsBatchDialogOpen(false);
      toast({ title: "Success", description: "Batch processing started successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to start batch processing", variant: "destructive" });
    },
  });

  const simulateBatchProgress = (batchOp: any) => {
    let processed = 0;
    const interval = setInterval(() => {
      processed += Math.floor(Math.random() * 3) + 1;
      
      if (processed >= batchOp.totalItems) {
        setCurrentBatchOperation(prev => ({
          ...prev,
          status: 'completed',
          processedItems: batchOp.totalItems,
          successfulItems: batchOp.totalItems - 2,
          failedItems: 2
        }));
        clearInterval(interval);
      } else {
        setCurrentBatchOperation(prev => ({
          ...prev,
          processedItems: processed,
          items: prev.items.map((item: any, index: number) => 
            index < processed ? 
              { ...item, status: 'completed', progress: 100 } :
              index === processed ? 
                { ...item, status: 'processing', progress: Math.floor(Math.random() * 80) + 20 } :
                item
          )
        }));
      }
    }, 1500);
  };

  // Initialize active sync operations
  useEffect(() => {
    setActiveSyncs([
      {
        id: 'carrier-sync-1',
        name: 'UPS Rate API - Live Rate Updates',
        type: 'carrier',
        status: 'syncing',
        progress: 78,
        totalItems: 50,
        processedItems: 39,
        startTime: new Date(Date.now() - 8 * 60 * 1000),
        estimatedCompletion: new Date(Date.now() + 3 * 60 * 1000)
      },
      {
        id: 'carrier-sync-2',
        name: 'FedEx Service Validation',
        type: 'carrier',
        status: 'completed',
        progress: 100,
        totalItems: 25,
        processedItems: 25,
        startTime: new Date(Date.now() - 20 * 60 * 1000),
        lastSync: new Date(Date.now() - 1 * 60 * 1000)
      }
    ]);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "bg-green-100 text-green-800";
      case "in_transit": return "bg-blue-100 text-blue-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="container mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Shipment Management</h1>
          <p className="text-muted-foreground mt-1">
            Multi-carrier integration with rate comparison and batch processing
          </p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <Dialog open={isBatchDialogOpen} onOpenChange={setIsBatchDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Batch Process
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Batch Processing</DialogTitle>
                <DialogDescription>
                  Process multiple shipments simultaneously for rate quotes or label generation
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="batch-type">Batch Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select batch operation" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rate_quote">Rate Quote</SelectItem>
                      <SelectItem value="label_generation">Label Generation</SelectItem>
                      <SelectItem value="shipment_creation">Shipment Creation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="file-upload">Upload CSV File</Label>
                  <Input type="file" accept=".csv" />
                </div>
              </div>
              <DialogFooter>
                <Button 
                  onClick={() => batchProcessMutation.mutate({})}
                  disabled={batchProcessMutation.isPending}
                >
                  {batchProcessMutation.isPending && <RefreshCw className="h-4 w-4 mr-2 animate-spin" />}
                  Start Processing
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Shipment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Shipment</DialogTitle>
                <DialogDescription>
                  Enter shipment details to get multi-carrier rate quotes
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="origin">Origin</Label>
                  <Input placeholder="Chicago, IL" />
                </div>
                <div>
                  <Label htmlFor="destination">Destination</Label>
                  <Input placeholder="Los Angeles, CA" />
                </div>
                <div>
                  <Label htmlFor="service-type">Service Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ftl">Full Truckload (FTL)</SelectItem>
                      <SelectItem value="ltl">Less Than Truckload (LTL)</SelectItem>
                      <SelectItem value="intermodal">Intermodal</SelectItem>
                      <SelectItem value="reefer">Refrigerated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="equipment">Equipment Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select equipment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dry_van">Dry Van</SelectItem>
                      <SelectItem value="reefer">Reefer</SelectItem>
                      <SelectItem value="flatbed">Flatbed</SelectItem>
                      <SelectItem value="step_deck">Step Deck</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label htmlFor="requirements">Special Requirements</Label>
                  <Textarea placeholder="Enter any special handling requirements..." />
                </div>
              </div>
              <DialogFooter>
                <Button 
                  onClick={() => createShipmentMutation.mutate({})}
                  disabled={createShipmentMutation.isPending}
                >
                  {createShipmentMutation.isPending && <RefreshCw className="h-4 w-4 mr-2 animate-spin" />}
                  Create & Get Rates
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Active Synchronizations */}
      {activeSyncs.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Real-time Carrier Synchronizations</h2>
          <SyncProgressIndicator 
            syncOperations={activeSyncs}
            onRetry={(id) => {
              setActiveSyncs(prev => prev.map(sync => 
                sync.id === id ? { ...sync, status: 'syncing', progress: 0 } : sync
              ));
              toast({ title: "Sync Restarted", description: "Retrying synchronization process" });
            }}
            onPause={(id) => {
              setActiveSyncs(prev => prev.map(sync => 
                sync.id === id ? { ...sync, status: 'paused' } : sync
              ));
              toast({ title: "Sync Paused", description: "Synchronization paused successfully" });
            }}
            onCancel={(id) => {
              setActiveSyncs(prev => prev.filter(sync => sync.id !== id));
              toast({ title: "Sync Cancelled", description: "Synchronization cancelled" });
            }}
          />
        </div>
      )}

      {/* KPI Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Delivery Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            {kpiLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold text-green-600">
                  {((kpiMetrics as any)?.deliverySuccessRate || 94.5).toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  +2.1% from last month
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Delivery Time</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            {kpiLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold text-blue-600">
                  {((kpiMetrics as any)?.averageDeliveryTime || 72)} hrs
                </div>
                <p className="text-xs text-muted-foreground">
                  -8.4% improvement
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cost Per Shipment</CardTitle>
            <DollarSign className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            {kpiLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold text-orange-600">
                  {formatCurrency((kpiMetrics as any)?.costPerShipment || 1247)}
                </div>
                <p className="text-xs text-muted-foreground">
                  -5.2% cost reduction
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Shipments</CardTitle>
            <Truck className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            {shipmentsLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold text-purple-600">
                  {(shipments as any)?.filter((s: any) => s.status === 'in_transit').length || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Currently in transit
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Shipments List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Shipments</CardTitle>
              <CardDescription>
                Track and manage your shipments with multi-carrier rate comparison
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <BarChart3 className="h-4 w-4 mr-2" />
              View Analytics
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {shipmentsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                  <Skeleton className="h-12 w-12 rounded" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                  <Skeleton className="h-8 w-24" />
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {((shipments as any) || []).map((shipment: any) => (
                <div key={shipment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Package className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">{shipment.trackingNumber || 'TRK-' + shipment.id.slice(-6)}</h3>
                      <p className="text-sm text-muted-foreground">
                        {shipment.origin} → {shipment.destination}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={getStatusColor(shipment.status)}>
                          {shipment.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {shipment.carrierName || 'Multi-carrier'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(shipment.estimatedCost || 0)}</p>
                    <p className="text-sm text-muted-foreground">
                      Est. {shipment.estimatedDeliveryDate ? new Date(shipment.estimatedDeliveryDate).toLocaleDateString() : 'TBD'}
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2"
                      onClick={() => getCarrierRatesMutation.mutate(shipment.id)}
                      disabled={getCarrierRatesMutation.isPending}
                    >
                      {getCarrierRatesMutation.isPending ? (
                        <RefreshCw className="h-3 w-3 animate-spin" />
                      ) : (
                        "Compare Rates"
                      )}
                    </Button>
                  </div>
                </div>
              ))}
              
              {(!shipments || (shipments as any).length === 0) && (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No shipments yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first shipment to start comparing carrier rates and managing deliveries
                  </p>
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create First Shipment
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Carrier Rate Comparison Modal */}
      {selectedShipment && (
        <Dialog open={!!selectedShipment} onOpenChange={() => setSelectedShipment(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Carrier Rate Comparison</DialogTitle>
              <DialogDescription>
                Compare rates from multiple carriers for optimal shipping decisions
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {selectedShipment.rates?.map((rate: any) => (
                <div key={rate.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Truck className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">{rate.carrierName}</h3>
                        <p className="text-sm text-muted-foreground">{rate.serviceLevel}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">{formatCurrency(rate.totalRate)}</p>
                      <p className="text-sm text-muted-foreground">
                        Transit: {rate.transitTime}h {rate.guaranteedDelivery && '✓ Guaranteed'}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <div className="text-sm text-muted-foreground">
                      Base: {formatCurrency(rate.baseRate)} + 
                      Fuel: {formatCurrency(rate.fuelSurcharge || 0)} + 
                      Other: {formatCurrency(rate.accessorialCharges || 0)}
                    </div>
                    <Button size="sm">Select Carrier</Button>
                  </div>
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Batch Progress Modal */}
      <BatchProgressModal
        isOpen={showBatchModal}
        onClose={() => setShowBatchModal(false)}
        batchOperation={currentBatchOperation}
        onCancel={() => {
          setCurrentBatchOperation(prev => prev ? { ...prev, status: 'failed' } : null);
          toast({ title: "Batch Cancelled", description: "Batch processing was cancelled" });
        }}
        onRetry={() => {
          if (currentBatchOperation) {
            simulateBatchProgress(currentBatchOperation);
            toast({ title: "Batch Restarted", description: "Retrying failed items" });
          }
        }}
        onDownloadResults={() => {
          toast({ title: "Download Started", description: "Results are being prepared for download" });
        }}
      />
    </div>
  );
}