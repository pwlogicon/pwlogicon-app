import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { MetricCard, PulseNotification, useDashboardMicroInteractions } from "@/components/DashboardMicroInteractions";
import OnboardingWalkthrough from "@/components/OnboardingWalkthrough";
import UnifiedLogisticsDashboard from "@/components/UnifiedLogisticsDashboard";
import DualRoleManager from "@/components/DualRoleManager";
import TrustVerificationCenter from "@/components/TrustVerificationCenter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";
import { Tooltip } from "@/components/ui/tooltip";
import { getContextualInsight, getRandomInsight } from "@/utils/logisticsInsights";
import { 
  Users, 
  Target, 
  TrendingUp, 
  FileText,
  Bell,
  ArrowRight,
  Smartphone,
  DollarSign,
  Package,
  Clock,
  CheckCircle2,
  Truck,
  Play,
  BarChart3,
  Grid3x3,
  ArrowRightLeft,
  Shield,
  UserCheck
} from "lucide-react";

export default function Dashboard() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [viewMode, setViewMode] = useState<'classic' | 'unified'>('classic');
  const { notifications, showNotification, dismissNotification } = useDashboardMicroInteractions();

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/analytics/revenue"],
    enabled: isAuthenticated,
  });

  const { data: opportunities, isLoading: opportunitiesLoading } = useQuery({
    queryKey: ["/api/opportunities"],
    enabled: isAuthenticated,
  });

  const { data: partnerships, isLoading: partnershipsLoading } = useQuery({
    queryKey: ["/api/partnerships"],
    enabled: isAuthenticated,
  });

  const { data: recentOpportunities, isLoading: recentOppLoading } = useQuery({
    queryKey: ["/api/dashboard/recent-opportunities"],
    enabled: isAuthenticated,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Skeleton className="w-8 h-8 rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: { [key: string]: string } = {
      carrier: "Carrier",
      "3pl": "3PL Manager",
      broker: "Broker",
      shipper: "Shipper"
    };
    return roleMap[role] || role;
  };

  // Trigger onboarding for new users
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('pwlogicon_onboarding_completed');
    if (!hasSeenOnboarding && isAuthenticated) {
      setTimeout(() => {
        setShowOnboarding(true);
      }, 1000);
    }
  }, [isAuthenticated]);

  // Demo notification on first load
  useEffect(() => {
    if (isAuthenticated && analytics) {
      setTimeout(() => {
        showNotification('success', 'Dashboard metrics refreshed successfully!');
      }, 2000);
    }
  }, [analytics, isAuthenticated]);

  return (
    <div className="container mx-auto py-6 px-4">
      {/* Pulse Notifications */}
      {notifications.map((notification) => (
        <PulseNotification
          key={notification.id}
          type={notification.type}
          message={notification.message}
          show={notification.show}
          onDismiss={() => dismissNotification(notification.id)}
        />
      ))}

      {/* Onboarding Walkthrough */}
      <OnboardingWalkthrough
        isActive={showOnboarding}
        onComplete={() => {
          setShowOnboarding(false);
          localStorage.setItem('pwlogicon_onboarding_completed', 'true');
          showNotification('success', 'Welcome to PWLoGiCon! You\'re all set to start optimizing your logistics partnerships.');
        }}
        onDismiss={() => {
          setShowOnboarding(false);
          localStorage.setItem('pwlogicon_onboarding_completed', 'true');
        }}
        autoPlay={true}
      />

      {/* Dashboard Header with View Toggle */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            📊 {viewMode === 'unified' ? 'Unified Logistics Dashboard' : 'PWLoGiCon Dashboard'}
          </h1>
          <p className="mt-2 text-gray-600">
            {viewMode === 'unified' 
              ? 'Real-time view across WMS, TMS, and ERP systems' 
              : `Welcome back, ${(user as any)?.firstName || "User"}! Here's your logistics partnership overview`
            }
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 mr-4">
            <Button
              variant={viewMode === 'classic' ? 'default' : 'outline'}
              onClick={() => setViewMode('classic')}
              size="sm"
              className="gap-2"
            >
              <Grid3x3 className="h-4 w-4" />
              Classic
            </Button>
            <Button
              variant={viewMode === 'unified' ? 'default' : 'outline'}
              onClick={() => setViewMode('unified')}
              size="sm"
              className="gap-2"
            >
              <BarChart3 className="h-4 w-4" />
              Unified
            </Button>
          </div>
          <Button 
            variant="outline" 
            onClick={() => setShowOnboarding(true)}
            className="gap-2"
          >
            <Play className="h-4 w-4" />
            Take Tour
          </Button>
          <Link href="/profile">
            <Button variant="outline">Profile</Button>
          </Link>
        </div>
      </div>

      {/* Render dashboard based on view mode */}
      {viewMode === 'unified' ? (
        <UnifiedLogisticsDashboard />
      ) : (
        <>
          {/* KPI Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Matches"
          value={(analytics as any)?.totalMatches || 247}
          previousValue={203}
          change={21.7}
          changeLabel="+44 new matches"
          icon={Target}
          color="text-blue-600"
          format="number"
          animated={!analyticsLoading}
        />
        
        <MetricCard
          title="Success Rate"
          value={(analytics as any)?.successRate || 94.8}
          previousValue={92.1}
          change={2.9}
          changeLabel="+2.7% improvement"
          icon={CheckCircle2}
          color="text-green-600"
          format="percentage"
          animated={!analyticsLoading}
        />
        
        <MetricCard
          title="Avg Savings"
          value={(analytics as any)?.avgSavings || 12847}
          previousValue={10234}
          change={25.5}
          changeLabel="+$2,613 per match"
          icon={DollarSign}
          color="text-green-600"
          format="currency"
          animated={!analyticsLoading}
        />
        
        <MetricCard
          title="Active Partners"
          value={(analytics as any)?.activePartners || (Array.isArray(partnerships) ? partnerships.length : 8)}
          previousValue={6}
          change={33.3}
          changeLabel="+2 verified partners"
          icon={Users}
          color="text-blue-600"
          format="number"
          animated={!analyticsLoading && !partnershipsLoading}
        />
      </div>

      {/* Top Lanes by Demand */}
      <div className="mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              🚚 Top Lanes by Demand
            </CardTitle>
            <CardDescription>
              Most active shipping routes in your network
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {((analytics as any)?.laneData || [
                { from: "Chicago, IL", to: "Los Angeles, CA", count: 42, growth: "+12%" },
                { from: "Atlanta, GA", to: "Miami, FL", count: 38, growth: "+8%" },
                { from: "Dallas, TX", to: "Houston, TX", count: 35, growth: "+15%" },
                { from: "New York, NY", to: "Philadelphia, PA", count: 31, growth: "+5%" },
                { from: "Phoenix, AZ", to: "Las Vegas, NV", count: 28, growth: "+22%" }
              ]).map((lane: any, index: number) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{lane.from} → {lane.to}</div>
                    <div className="text-sm text-gray-500">{lane.growth} from last month</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default" className="bg-blue-100 text-blue-800">
                      {lane.count} matches
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Opportunities */}
      <div className="mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              📬 Recent Opportunities
            </CardTitle>
            <CardDescription>
              Latest opportunities posted in your network
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Type</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Route</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Service</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Urgency</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(Array.isArray(recentOpportunities) ? recentOpportunities : [
                    { type: "capacity", route: "Seattle, WA → Portland, OR", service: "FTL", urgency: "hot", id: "1" },
                    { type: "need", route: "Denver, CO → Salt Lake City, UT", service: "LTL", urgency: "standard", id: "2" },
                    { type: "capacity", route: "Phoenix, AZ → Tucson, AZ", service: "Reefer", urgency: "hot", id: "3" },
                    { type: "need", route: "San Diego, CA → Las Vegas, NV", service: "FTL", urgency: "standard", id: "4" }
                  ]).map((opp: any, index: number) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2">
                        <span className="flex items-center gap-1">
                          {opp.type === 'capacity' ? '🚛' : '🔍'} 
                          {opp.type === 'capacity' ? 'Capacity' : 'Need'}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-sm">{opp.route}</td>
                      <td className="py-3 px-2 text-sm">{opp.service}</td>
                      <td className="py-3 px-2">
                        <Badge variant={opp.urgency === 'hot' ? 'destructive' : 'secondary'}>
                          {opp.urgency === 'hot' ? '🔥 Hot' : '⏱️ Standard'}
                        </Badge>
                      </td>
                      <td className="py-3 px-2">
                        <Link href={`/opportunities/${opp.id}`}>
                          <Button variant="outline" size="sm">
                            View Matches
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  ➕ Post New Opportunity
                </h3>
                <p className="text-gray-600 mb-4">
                  Share capacity or find partners for your shipments
                </p>
                <Link href="/opportunities">
                  <Button className="bg-green-600 hover:bg-green-700 text-white">
                    <FileText className="mr-2 h-4 w-4" />
                    Create Opportunity
                  </Button>
                </Link>
              </div>
              <div className="text-4xl">
                📋
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Browse Partnerships
                </h3>
                <p className="text-sm text-gray-600">
                  Discover verified carriers, 3PLs, brokers, and shippers for collaboration
                </p>
              </div>
              <Button asChild>
                <Link href="/partnerships">
                  View Partners
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  TMS/WMS Integrations
                </h3>
                <p className="text-sm text-gray-600">
                  Connect your systems for automated capacity and lane data synchronization
                </p>
              </div>
              <Button asChild>
                <Link href="/integrations">
                  Setup Integration
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Analytics Dashboard
                </h3>
                <p className="text-sm text-gray-600">
                  Track lane demand, capacity heatmaps, and market trend insights
                </p>
              </div>
              <Button asChild>
                <Link href="/analytics">
                  View Analytics
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-teal-50 to-blue-50 border-teal-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Mobile Field Operations
                </h3>
                <p className="text-sm text-gray-600">
                  GPS tracking, offline sync, and field management for mobile operations
                </p>
              </div>
              <Button asChild>
                <Link href="/mobile">
                  Open Mobile App
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Transaction Fee Management
                </h3>
                <p className="text-sm text-gray-600">
                  Track commission earnings, confirm partnerships, and manage payment processing
                </p>
              </div>
              <Button asChild>
                <Link href="/transactions">
                  Manage Transactions
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Dual-Role Management for 3PL Users */}
        {user && (user as any)?.role === "3pl" && (
          <Card className="bg-gradient-to-r from-indigo-50 to-blue-50 border-indigo-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <ArrowRightLeft className="h-5 w-5" />
                    Dual-Role Management
                  </h3>
                  <p className="text-sm text-gray-600">
                    Switch between service provider and requester roles seamlessly
                  </p>
                </div>
                <Button variant="outline">
                  Switch Roles
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Trust & Verification Center */}
        <Card className="bg-gradient-to-r from-green-50 to-teal-50 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Trust & Verification Center
                </h3>
                <p className="text-sm text-gray-600">
                  Manage identity verification, insurance, and dispute resolution
                </p>
              </div>
              <Button variant="outline">
                <UserCheck className="mr-2 h-4 w-4" />
                Manage Verification
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dual-Role Management Component for 3PL Users */}
      {user && (user as any)?.role === "3pl" && (
        <div className="mb-8">
          <DualRoleManager />
        </div>
      )}

      {/* Trust Verification Center Component */}
      <div className="mb-8">
        <TrustVerificationCenter />
      </div>
        </>
      )}
    </div>
  );
}