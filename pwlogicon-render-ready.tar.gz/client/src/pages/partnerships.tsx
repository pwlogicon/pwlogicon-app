import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import AIPartnerMatchTooltip from "@/components/AIPartnerMatchTooltip";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Tooltip } from "@/components/ui/tooltip";
import { getContextualInsight, getRandomInsight } from "@/utils/logisticsInsights";
import { Link } from "wouter";
import { 
  CheckCircle,
  Star,
  Globe,
  Truck,
  MapPin,
  TrendingUp,
  ArrowRight,
  Shield,
  Award,
  Brain,
  Zap
} from "lucide-react";

export default function Partnerships() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: partnerships, isLoading } = useQuery({
    queryKey: ["/api/partnerships"],
    enabled: isAuthenticated,
  });

  // Contact partner mutation
  const contactPartnerMutation = useMutation({
    mutationFn: async (partnerId: string) => {
      return await apiRequest("POST", "/api/conversations", {
        subject: `Partnership Inquiry - ${partnerId === 'pa-logistics-default' ? 'PA Logistics Solutions' : 'Partner'}`,
        description: "New partnership inquiry",
        relatedType: "partnership",
        relatedId: partnerId
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Message Started",
        description: "Conversation with partner has been initiated. You can continue in the Messages section.",
      });
      // Redirect to messages page
      window.location.href = '/messages';
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start conversation with partner. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleContactPartner = (partner: any) => {
    const isPALogistics = partner.id === 'pa-logistics-default';
    
    if (isPALogistics) {
      // Show PA Logistics contact information
      toast({
        title: "PA Logistics Contact Information",
        description: "Contact details shown below. Website will open in new tab.",
      });
      
      // Open PA Logistics website in new tab
      window.open('https://palogisticsolutions.com/', '_blank');
      
      // Also create a conversation for tracking
      contactPartnerMutation.mutate(partner.id);
    } else {
      // For other partners, create a conversation
      contactPartnerMutation.mutate(partner.id);
    }
  };

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Skeleton className="w-8 h-8 rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: { [key: string]: string } = {
      carrier: "Carrier",
      "3pl": "3PL Manager",
      broker: "Broker",
      shipper: "Shipper"
    };
    return roleMap[role] || role;
  };

  const renderPartnerCard = (partner: any) => {
    const isVerified = partner.verified || partner.id === 'pa-logistics-default';
    const isPALogistics = partner.id === 'pa-logistics-default';
    
    return (
      <Card key={partner.partnerUserId || partner.id} className={`${isPALogistics ? 'border-green-200 bg-green-50' : ''} relative`}>
        {isPALogistics && (
          <div className="absolute top-2 right-2">
            <Badge variant="default" className="bg-green-600">
              <Shield className="h-3 w-3 mr-1" />
              Verified Partner
            </Badge>
          </div>
        )}
        
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="flex items-center gap-2">
                {isPALogistics ? (
                  <>
                    PA Logistics Solutions
                    <Award className="h-5 w-5 text-yellow-500" />
                  </>
                ) : (
                  partner.partnerName || `Partner ${partner.id.slice(0, 8)}`
                )}
                {isVerified && (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                )}
                {/* AI Match Analysis Tooltip */}
                <AIPartnerMatchTooltip
                  partnerMatch={{
                    id: partner.id,
                    companyName: isPALogistics ? "PA Logistics Solutions" : partner.partnerName || `Partner ${partner.id.slice(0, 8)}`,
                    matchScore: isPALogistics ? 98 : Math.floor(Math.random() * 30) + 70,
                    confidence: isPALogistics ? 96 : Math.floor(Math.random() * 20) + 75,
                    reasoning: isPALogistics 
                      ? "Exceptional match with premium service reliability, nationwide coverage, and specialized equipment capabilities. Consistent performance history with 99.2% on-time delivery."
                      : "Strong compatibility based on regional coverage and service offerings. Good capacity availability for your shipping lanes.",
                    serviceCompatibility: isPALogistics ? 98 : Math.floor(Math.random() * 25) + 75,
                    regionalCoverage: isPALogistics ? 95 : Math.floor(Math.random() * 20) + 80,
                    capacityMatch: isPALogistics ? 92 : Math.floor(Math.random() * 30) + 70,
                    urgencyAlignment: isPALogistics ? 96 : Math.floor(Math.random() * 25) + 75
                  }}
                  trigger={
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-6 w-6 p-0 ml-2 hover:bg-blue-100"
                    >
                      <Brain className="h-4 w-4 text-blue-600" />
                    </Button>
                  }
                />
              </CardTitle>
              
              <div className="flex items-center gap-4 mt-2">
                {isPALogistics && (
                  <>
                    <Tooltip content={getRandomInsight('partnership')}>
                      <div className="flex items-center gap-1 cursor-help">
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-sm font-medium">4.9</span>
                      </div>
                    </Tooltip>
                    <Tooltip content={getRandomInsight('ai')}>
                      <Badge variant="secondary" className="cursor-help">Score: 98</Badge>
                    </Tooltip>
                    <Tooltip content={getContextualInsight(undefined, undefined, undefined, 'partnership')}>
                      <Badge variant="outline" className="cursor-help">3PL Provider</Badge>
                    </Tooltip>
                  </>
                )}
              </div>
            </div>
          </div>
          
          {isPALogistics && (
            <CardDescription className="mt-2">
              Premier 3PL provider with nationwide coverage and exceptional service quality. 
              Verified partner with proven track record in freight management and logistics solutions.
            </CardDescription>
          )}
        </CardHeader>
        
        <CardContent>
          <div className="space-y-4">
            {/* Services */}
            {isPALogistics && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center">
                  <Truck className="h-4 w-4 mr-2" />
                  Services
                </h4>
                <div className="flex flex-wrap gap-1">
                  <Tooltip content={getRandomInsight('ftl')}>
                    <Badge variant="outline" className="cursor-help">Full Truckload (FTL)</Badge>
                  </Tooltip>
                  <Tooltip content={getRandomInsight('ltl')}>
                    <Badge variant="outline" className="cursor-help">Less Than Truckload (LTL)</Badge>
                  </Tooltip>
                  <Tooltip content={getRandomInsight('reefer')}>
                    <Badge variant="outline" className="cursor-help">Refrigerated</Badge>
                  </Tooltip>
                </div>
              </div>
            )}
            
            {/* Coverage Areas */}
            {isPALogistics && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  Coverage Areas
                </h4>
                <div className="flex flex-wrap gap-1">
                  <Tooltip content={getRandomInsight('analytics')}>
                    <Badge variant="outline" className="cursor-help">North America</Badge>
                  </Tooltip>
                  <Tooltip content={getRandomInsight('eastCoast')}>
                    <Badge variant="outline" className="cursor-help">US-East</Badge>
                  </Tooltip>
                  <Tooltip content={getRandomInsight('midwest')}>
                    <Badge variant="outline" className="cursor-help">US-Central</Badge>
                  </Tooltip>
                </div>
              </div>
            )}
            
            {/* Partnership Details */}
            <div className="pt-2 border-t">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  Status: <span className="font-medium text-green-600">Active</span>
                </div>
                {isPALogistics && (
                  <div className="text-sm text-gray-600">
                    Commission: <span className="font-medium">2.5%</span>
                  </div>
                )}
              </div>
              
              {isPALogistics && (
                <>
                  {/* Contact Information */}
                  <div className="mt-3 p-3 bg-green-50 rounded-lg border border-green-200">
                    <h4 className="text-sm font-medium mb-2 text-green-800">Contact Information</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Akash Kapoor</strong> - Logistics Specialist
                        <br />
                        <span className="text-gray-600">Phone: (925) 998-8619</span>
                        <br />
                        <span className="text-gray-600">Email: akash@palogisticsgroup.com</span>
                      </div>
                      <div className="border-t border-green-200 pt-2">
                        <strong>Ian James</strong> - Logistics Advisor
                        <br />
                        <span className="text-gray-600">Phone: (470) 429-1437</span>
                        <br />
                        <span className="text-gray-600">Email: Ian@palogisticsgroup.com</span>
                        <br />
                        <span className="text-xs text-gray-500">MC 956423 | DOT 3339378</span>
                        <br />
                        <span className="text-xs text-gray-500">672 W 11th St, Suite 348 Tracy, CA 95376</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mt-3">
                    <Button variant="outline" size="sm" asChild>
                      <a href="https://palogisticsolutions.com/" target="_blank" rel="noopener noreferrer">
                        <Globe className="h-4 w-4 mr-2" />
                        Visit Website
                      </a>
                    </Button>
                    <Button size="sm" onClick={() => handleContactPartner(partner)}>
                      Start Conversation
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="text-2xl font-bold text-primary">PWLoGiCon</Link>
              <nav className="hidden md:ml-8 md:flex md:space-x-1">
                <Link href="/" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Dashboard
                </Link>
                <Link href="/opportunities" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Opportunities
                </Link>
                <Link href="/partnerships" className="text-primary px-3 py-2 text-sm font-medium border-b-2 border-primary">
                  Partnerships
                </Link>
                <Link href="/transactions" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Transactions
                </Link>
                <Link href="/integrations" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Integrations
                </Link>
                <Link href="/analytics" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Analytics
                </Link>
                <Link href="/messages" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Messages
                </Link>
                <Link href="/mobile" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Mobile
                </Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">
                    {(user as any)?.firstName} {(user as any)?.lastName}
                  </p>
                  <p className="text-xs text-gray-500">
                    {getRoleDisplay((user as any)?.role || "")}
                  </p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Partnerships</h1>
          <p className="mt-2 text-gray-600">
            Manage your logistics partnerships and connect with verified providers
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Partnerships</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <Skeleton className="h-8 w-16" /> : (partnerships as any)?.length || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Including verified partners
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Verified Partners</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1</div>
              <p className="text-xs text-muted-foreground">
                High-quality verified providers
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Partnership Score</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">98</div>
              <p className="text-xs text-muted-foreground">
                Average partner quality score
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Partnerships List */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Your Partnerships</h2>
            <Button asChild>
              <Link href="/opportunities">
                Find New Partners <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {(partnerships as any)?.map((partner: any) => renderPartnerCard(partner)) || []}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}