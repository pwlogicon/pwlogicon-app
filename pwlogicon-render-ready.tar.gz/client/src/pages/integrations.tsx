import { useState, useEffect } from "react";
import SyncProgressIndicator from "@/components/SyncProgressIndicator";
import IntegrationRoadmap from "@/components/IntegrationRoadmap";
import LogisticsConnectorFramework from "@/components/LogisticsConnectorFramework";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Plus, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import AddIntegrationModal from "@/components/AddIntegrationModal";
import IntegrationsList from "@/components/IntegrationsList";
import { useToast } from "@/hooks/use-toast";

export default function IntegrationsPage() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ["/api/integrations"],
  });

  const hasIntegrations = Array.isArray(integrations) && integrations.length > 0;

  return (
    <div className="container mx-auto mt-4 max-w-4xl">
      <h1 className="display-6 mb-3">🔌 TMS/WMS Integrations</h1>
      <p className="text-muted mb-4">
        Connect your transportation and warehouse management systems to automatically sync capacity and service data.
      </p>

      {/* Logistics Connector Framework */}
      <div className="mb-8">
        <LogisticsConnectorFramework 
          onRegisterConnector={(type, config) => {
            toast({
              title: "Register Connector",
              description: `Registering new ${type} connector. Configuration wizard will open.`,
            });
          }}
          onSynchronizeData={() => {
            toast({
              title: "Data Synchronization",
              description: "Starting synchronization across all connected systems.",
            });
          }}
          onConnectorAction={(connectorId, action) => {
            toast({
              title: "Connector Action",
              description: `Performing ${action} on connector ${connectorId}.`,
            });
          }}
        />
      </div>

      {/* Integration Roadmap */}
      <div className="mb-8">
        <IntegrationRoadmap 
          onStartPhase={(phaseIndex) => {
            toast({
              title: "Phase Planning",
              description: `Starting planning for Phase ${phaseIndex + 1}. Team will be notified.`,
            });
          }}
          onViewDetails={(phaseIndex) => {
            toast({
              title: "Phase Details", 
              description: `Viewing detailed requirements for Phase ${phaseIndex + 1}.`,
            });
          }}
        />
      </div>

      {!hasIntegrations ? (
        <Alert className="mb-4 bg-light border-light">
          <AlertDescription>
            <div>
              <strong>No Integrations Yet</strong>
              <p className="mb-3 mt-2">Connect your TMS or WMS systems to automatically sync capacity and service data.</p>
              <Button 
                onClick={() => setIsAddModalOpen(true)}
                className="btn btn-primary"
              >
                <Plus className="h-4 w-4 mr-2" />
                ➕ Add Integration
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      ) : (
        <div className="mb-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h3>Connected Systems</h3>
            <Button 
              onClick={() => setIsAddModalOpen(true)}
              variant="outline"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Integration
            </Button>
          </div>
          <IntegrationsList integrations={integrations} onSelectIntegration={() => {}} />
          
          {/* Sync Progress Section */}
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-3">Active Synchronizations</h3>
            <SyncProgressIndicator 
              syncOperations={[
                {
                  id: 'sync-oracle-tms',
                  name: 'Oracle TMS - Weekly Capacity Sync',
                  type: 'tms',
                  status: 'syncing',
                  progress: 67,
                  totalItems: 350,
                  processedItems: 234,
                  startTime: new Date(Date.now() - 15 * 60 * 1000),
                  estimatedCompletion: new Date(Date.now() + 8 * 60 * 1000)
                },
                {
                  id: 'sync-manhattan-wms',
                  name: 'Manhattan SCALE - Real-time Inventory',
                  type: 'wms',
                  status: 'completed',
                  progress: 100,
                  totalItems: 120,
                  processedItems: 120,
                  startTime: new Date(Date.now() - 45 * 60 * 1000),
                  lastSync: new Date(Date.now() - 2 * 60 * 1000)
                }
              ]}
              onRetry={(id) => console.log('Retry sync:', id)}
              onPause={(id) => console.log('Pause sync:', id)}
              onCancel={(id) => console.log('Cancel sync:', id)}
            />
          </div>
        </div>
      )}

      <hr className="my-4" />
      
      <Link href="/dashboard">
        <Button variant="secondary" className="btn btn-secondary">
          <ArrowLeft className="h-4 w-4 mr-2" />
          ← Back
        </Button>
      </Link>

      <AddIntegrationModal 
        open={isAddModalOpen} 
        onOpenChange={setIsAddModalOpen} 
      />
    </div>
  );
}