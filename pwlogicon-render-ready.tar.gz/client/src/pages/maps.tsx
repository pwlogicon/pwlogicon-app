import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import LogisticsMapVisualization from "@/components/LogisticsMapVisualization";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Map } from "lucide-react";
import { Link } from "wouter";

export default function MapsPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (!isAuthenticated && !isLoading) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="flex items-center gap-4">
          <Link href="/analytics">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Analytics
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Map className="h-8 w-8" />
              Logistics Map
            </h1>
            <p className="text-muted-foreground mt-1">
              Interactive visualization of shipping lanes and market opportunities
            </p>
          </div>
        </div>
      </div>

      {/* Map Overview Card */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Map className="h-5 w-5" />
            Real-Time Lane Intelligence
          </CardTitle>
          <CardDescription>
            Explore active shipping lanes across the United States with real-time density analysis, 
            match tracking, and market rate intelligence. Click on any route for detailed information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-red-600 rounded"></div>
              <span className="text-sm"><strong>High Density:</strong> 8+ matches/month</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-orange-600 rounded"></div>
              <span className="text-sm"><strong>Medium Density:</strong> 3-7 matches/month</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-blue-600 rounded"></div>
              <span className="text-sm"><strong>Low Density:</strong> 1-2 matches/month</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Interactive Map */}
      <LogisticsMapVisualization />

      {/* Additional Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">How to Use the Map</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-sm font-medium">1</div>
              <div>
                <p className="font-medium">Explore Routes</p>
                <p className="text-sm text-gray-600">Click on any colored line to see detailed route information</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-sm font-medium">2</div>
              <div>
                <p className="font-medium">Filter Data</p>
                <p className="text-sm text-gray-600">Use density and service type filters to focus on specific opportunities</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-sm font-medium">3</div>
              <div>
                <p className="font-medium">Analyze Performance</p>
                <p className="text-sm text-gray-600">Review match counts, average rates, and market activity</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Map Features</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Real-time lane density analysis</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Interactive route popups with business intelligence</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Service type filtering (FTL, LTL, Reefer, Express)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Market rate and activity tracking</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm">Origin and destination city markers</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}