import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, BarChart3, TrendingUp, MapPin, Activity, RefreshCw, Map, Target, FileText, Shield, Building2, Monitor, AlertTriangle } from "lucide-react";
import LogisticsMapVisualization from "@/components/LogisticsMapVisualization";
import PredictiveETA from "@/components/PredictiveETA";
import LiveTruckTracking from "@/components/LiveTruckTracking";
import UnifiedTrackingDashboard from "@/components/UnifiedTrackingDashboard";
import CarrierCompliance from "@/components/CarrierCompliance";
import ReportBuilder from "@/components/ReportBuilder";
import CustomReportBuilder from "@/components/CustomReportBuilder";
import GeofenceMonitor from "@/components/GeofenceMonitor";
import LiveGPSTracker from "@/components/LiveGPSTracker";
import KPIDashboard from "@/components/KPIDashboard";
import KPIMasterDashboard from "@/components/KPIMasterDashboard";
import BootstrapKPIMasterDashboard from "@/components/BootstrapKPIMasterDashboard";
import MacroPointIntegration from "@/components/MacroPointIntegration";
import OTMControlTower from "@/components/OTMControlTower";
import PowerBIDashboard from "@/components/PowerBIDashboard";
import FullDashboardMockup from "@/components/FullDashboardMockup";
import { CarrierComplianceHeatmap } from "@/components/CarrierComplianceHeatmap";
import { 
  ComposedChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  Cell,
  PieChart,
  Pie
} from "recharts";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const Analytics = () => {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("weekly");
  const [selectedServiceType, setSelectedServiceType] = useState("all");
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [selectedDataType, setSelectedDataType] = useState("demand");

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch lane analytics
  const { data: laneAnalytics, isLoading: isLoadingLanes } = useQuery({
    queryKey: ["/api/analytics/lanes", selectedPeriod, selectedServiceType],
    enabled: !!isAuthenticated,
    retry: false,
  });

  // Fetch regional heatmap data
  const { data: heatmapData, isLoading: isLoadingHeatmap } = useQuery({
    queryKey: ["/api/analytics/heatmap", selectedDataType, selectedPeriod, selectedRegion],
    enabled: !!isAuthenticated,
    retry: false,
  });

  // Fetch market trends
  const { data: marketTrends, isLoading: isLoadingTrends } = useQuery({
    queryKey: ["/api/analytics/trends", selectedPeriod],
    enabled: !!isAuthenticated,
    retry: false,
  });

  // Generate analytics data mutation
  const generateAnalyticsMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/analytics/generate", {
        period: selectedPeriod,
        periodDate: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: "Analytics Generated",
        description: "Analytics data has been generated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/lanes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/heatmap"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/trends"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate analytics data",
        variant: "destructive",
      });
    },
  });

  // Prepare lane demand data for charts
  const laneChartData = (laneAnalytics as any[] || []).map((lane: any) => ({
    route: `${lane.originCity}, ${lane.originState} → ${lane.destinationCity}, ${lane.destinationState}`,
    demand: lane.demandVolume || 0,
    capacity: lane.capacityVolume || 0,
    utilization: parseFloat(lane.utilizationRate || "0"),
    avgRate: parseFloat(lane.averageRate || "0"),
    serviceType: lane.serviceType,
  })) || [];

  // Prepare heatmap intensity data
  const heatmapIntensityData = (heatmapData as any[] || []).map((item: any) => ({
    state: item.state,
    region: item.region,
    value: parseFloat(item.value || "0"),
    intensity: parseFloat(item.intensity || "0"),
    dataType: item.dataType,
  })) || [];

  // Prepare market trends chart data
  const trendsChartData = (marketTrends as any[] || []).map((trend: any) => ({
    metric: trend.metric,
    region: trend.region,
    current: parseFloat(trend.currentValue || "0"),
    previous: parseFloat(trend.previousValue || "0"),
    change: parseFloat(trend.changePercent || "0"),
    forecast7d: parseFloat(trend.forecast7d || "0"),
    forecast30d: parseFloat(trend.forecast30d || "0"),
  })) || [];

  // Group data by region for regional analysis
  const regionalData = heatmapIntensityData.reduce((acc: any, item: any) => {
    if (!acc[item.region]) {
      acc[item.region] = [];
    }
    acc[item.region].push(item);
    return acc;
  }, {} as Record<string, typeof heatmapIntensityData>);

  if (!isAuthenticated && !isLoading) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advanced Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Lane demand and capacity heatmaps with market intelligence
          </p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedServiceType} onValueChange={setSelectedServiceType}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Service Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Services</SelectItem>
              <SelectItem value="ltl">LTL</SelectItem>
              <SelectItem value="ftl">FTL</SelectItem>
              <SelectItem value="express">Express</SelectItem>
              <SelectItem value="warehousing">Warehousing</SelectItem>
            </SelectContent>
          </Select>

          <Button 
            onClick={() => generateAnalyticsMutation.mutate()}
            disabled={generateAnalyticsMutation.isPending}
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            {generateAnalyticsMutation.isPending ? "Generating..." : "Generate Data"}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="map" className="space-y-6">
        <TabsList className="grid w-full grid-cols-12">
          <TabsTrigger value="kpis" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            KPIs
          </TabsTrigger>
          <TabsTrigger value="map" className="flex items-center gap-2">
            <Map className="h-4 w-4" />
            Interactive Map
          </TabsTrigger>
          <TabsTrigger value="lanes" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Lane Analytics
          </TabsTrigger>
          <TabsTrigger value="heatmap" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Regional Heatmap
          </TabsTrigger>
          <TabsTrigger value="trends" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Market Trends
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Insights
          </TabsTrigger>
          <TabsTrigger value="tracking" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Live Tracking
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="compliance" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            MacroPoint
          </TabsTrigger>
          <TabsTrigger value="otm" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            OTM Control Tower
          </TabsTrigger>
          <TabsTrigger value="powerbi" className="flex items-center gap-2">
            <Monitor className="h-4 w-4" />
            Power BI Analytics
          </TabsTrigger>
          <TabsTrigger value="mockup" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Full Dashboard
          </TabsTrigger>
          <TabsTrigger value="carrier-heatmap" className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Carrier Compliance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="kpis" className="space-y-6">
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="col-md-6">
                <BootstrapKPIMasterDashboard sid="analytics-demo" />
              </div>
              <div className="col-md-6">
                <KPIMasterDashboard />
              </div>
            </div>
            <KPIDashboard />
          </div>
        </TabsContent>

        <TabsContent value="map" className="space-y-6">
          <LogisticsMapVisualization />
        </TabsContent>

        <TabsContent value="lanes" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lane Demand vs Capacity Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Demand vs Capacity by Lane
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingLanes ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <ComposedChart data={laneChartData.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="route" 
                        angle={-45}
                        textAnchor="end"
                        height={80}
                        fontSize={10}
                      />
                      <YAxis />
                      <Tooltip 
                        labelStyle={{ color: '#000', fontSize: '12px' }}
                        contentStyle={{ backgroundColor: '#fff', border: '1px solid #ccc' }}
                      />
                      <Legend />
                      <Bar dataKey="demand" fill="#8884d8" name="Demand Volume" />
                      <Bar dataKey="capacity" fill="#82ca9d" name="Capacity Volume" />
                      <Line type="monotone" dataKey="utilization" stroke="#ff7300" name="Utilization %" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Average Rates by Lane */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Average Rates by Lane
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingLanes ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <ComposedChart data={laneChartData.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="route" 
                        angle={-45}
                        textAnchor="end"
                        height={80}
                        fontSize={10}
                      />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="avgRate" fill="#ffc658" name="Average Rate ($)" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Lane Performance Table */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performing Lanes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Route</th>
                      <th className="text-left p-2">Service Type</th>
                      <th className="text-right p-2">Demand</th>
                      <th className="text-right p-2">Capacity</th>
                      <th className="text-right p-2">Utilization</th>
                      <th className="text-right p-2">Avg Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {laneChartData.slice(0, 8).map((lane: any, index: number) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium text-sm">{lane.route}</td>
                        <td className="p-2">
                          <Badge variant="outline" className="text-xs capitalize">
                            {lane.serviceType}
                          </Badge>
                        </td>
                        <td className="text-right p-2">{lane.demand.toLocaleString()}</td>
                        <td className="text-right p-2">{lane.capacity.toLocaleString()}</td>
                        <td className="text-right p-2">{lane.utilization.toFixed(1)}%</td>
                        <td className="text-right p-2 font-medium">${lane.avgRate.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="heatmap" className="space-y-6">
          <div className="flex flex-wrap gap-3 mb-4">
            <Select value={selectedDataType} onValueChange={setSelectedDataType}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Data Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="demand">Demand</SelectItem>
                <SelectItem value="capacity">Capacity</SelectItem>
                <SelectItem value="rate">Rates</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedRegion} onValueChange={setSelectedRegion}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Regions</SelectItem>
                <SelectItem value="northeast">Northeast</SelectItem>
                <SelectItem value="southeast">Southeast</SelectItem>
                <SelectItem value="midwest">Midwest</SelectItem>
                <SelectItem value="southwest">Southwest</SelectItem>
                <SelectItem value="west">West</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Regional Intensity Scatter Plot */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  {selectedDataType.charAt(0).toUpperCase() + selectedDataType.slice(1)} Intensity by State
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingHeatmap ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <ScatterChart data={heatmapIntensityData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="state" />
                      <YAxis dataKey="intensity" />
                      <Tooltip 
                        cursor={{ strokeDasharray: '3 3' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-white p-3 border rounded shadow">
                                <p className="font-medium">{data.state}</p>
                                <p className="text-sm">Region: {data.region}</p>
                                <p className="text-sm">Value: {data.value.toLocaleString()}</p>
                                <p className="text-sm">Intensity: {data.intensity.toFixed(1)}%</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Scatter 
                        dataKey="intensity" 
                        fill="#8884d8"
                        name="Intensity"
                      />
                    </ScatterChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Regional Distribution Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Regional Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingHeatmap ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={Object.entries(regionalData).map(([region, data]) => ({
                          name: region,
                          value: (data as any[]).reduce((sum: number, item: any) => sum + item.value, 0),
                          count: (data as any[]).length,
                        }))}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                      >
                        {Object.keys(regionalData).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Regional Heatmap Data Table */}
          <Card>
            <CardHeader>
              <CardTitle>Regional Heatmap Data</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">State</th>
                      <th className="text-left p-2">Region</th>
                      <th className="text-left p-2">Data Type</th>
                      <th className="text-right p-2">Value</th>
                      <th className="text-right p-2">Intensity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {heatmapIntensityData
                      .sort((a: any, b: any) => b.intensity - a.intensity)
                      .slice(0, 15)
                      .map((item: any, index: number) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="p-2 font-medium">{item.state}</td>
                          <td className="p-2 capitalize">{item.region}</td>
                          <td className="p-2">
                            <Badge variant="outline" className="text-xs capitalize">
                              {item.dataType}
                            </Badge>
                          </td>
                          <td className="text-right p-2">{item.value.toLocaleString()}</td>
                          <td className="text-right p-2">
                            <div className="flex items-center justify-end gap-2">
                              <div 
                                className="w-12 h-2 bg-gradient-to-r from-blue-200 to-blue-600 rounded"
                                style={{
                                  background: `linear-gradient(to right, #e3f2fd ${100 - item.intensity}%, #1976d2 ${item.intensity}%)`
                                }}
                              />
                              <span className="text-sm font-medium">{item.intensity.toFixed(1)}%</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Market Trends Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Market Trends by Region
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingTrends ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <ComposedChart data={trendsChartData.slice(0, 15)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="metric" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="current" fill="#8884d8" name="Current Value" />
                      <Line type="monotone" dataKey="change" stroke="#ff7300" name="Change %" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Forecast Chart */}
            <Card>
              <CardHeader>
                <CardTitle>7-Day vs 30-Day Forecasts</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingTrends ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <ComposedChart data={trendsChartData.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="region" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="forecast7d" fill="#82ca9d" name="7-Day Forecast" />
                      <Bar dataKey="forecast30d" fill="#ffc658" name="30-Day Forecast" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Key Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Total Lanes Tracked</span>
                  <span className="font-bold">{(laneAnalytics as any)?.length || 0}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Avg Utilization Rate</span>
                  <span className="font-bold">
                    {(laneAnalytics as any)?.length 
                      ? ((laneAnalytics as any).reduce((sum: number, lane: any) => sum + parseFloat(lane.utilizationRate || "0"), 0) / (laneAnalytics as any).length).toFixed(1)
                      : 0}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Regional Coverage</span>
                  <span className="font-bold">{Object.keys(regionalData).length} Regions</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Market Intelligence</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-blue-50 rounded">
                  <h4 className="font-medium text-blue-900">High Demand Corridors</h4>
                  <p className="text-sm text-blue-700 mt-1">
                    {laneChartData
                      .filter((lane: any) => lane.demand > 5)
                      .length} lanes showing strong demand patterns
                  </p>
                </div>
                <div className="p-3 bg-green-50 rounded">
                  <h4 className="font-medium text-green-900">Capacity Opportunities</h4>
                  <p className="text-sm text-green-700 mt-1">
                    {laneChartData
                      .filter((lane: any) => lane.utilization < 70)
                      .length} lanes with available capacity
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Trending Patterns</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {trendsChartData
                    .filter((trend: any) => Math.abs(trend.change) > 10)
                    .slice(0, 4)
                    .map((trend: any, index: number) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-sm capitalize">{trend.metric} - {trend.region}</span>
                        <Badge 
                          variant={trend.change > 0 ? "default" : "destructive"}
                          className="text-xs"
                        >
                          {trend.change > 0 ? "+" : ""}{trend.change.toFixed(1)}%
                        </Badge>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Actionable Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Capacity Optimization</h4>
                  <p className="text-sm text-gray-600">
                    Focus on lanes with utilization below 60% to improve efficiency. 
                    {laneChartData.filter((lane: any) => lane.utilization < 60).length} lanes 
                    identified for optimization.
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Market Expansion</h4>
                  <p className="text-sm text-gray-600">
                    Regional analysis shows growth opportunities in {
                      Object.entries(regionalData)
                        .sort(([,a]: any, [,b]: any) => b.length - a.length)[0]?.[0] || "key markets"
                    }. Consider expanding services in high-demand areas.
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Rate Strategy</h4>
                  <p className="text-sm text-gray-600">
                    Average rates vary significantly across lanes. 
                    Implement dynamic pricing on high-demand routes to maximize revenue.
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Partnership Opportunities</h4>
                  <p className="text-sm text-gray-600">
                    Identify strategic partners in regions with capacity gaps. 
                    {trendsChartData.filter((trend: any) => trend.change > 15).length} markets 
                    showing rapid growth.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tracking" className="space-y-6">
          <div className="space-y-6">
            <LiveGPSTracker />
            <UnifiedTrackingDashboard />
            <LiveTruckTracking />
          </div>
        </TabsContent>

        <TabsContent value="geofencing" className="space-y-6">
          <GeofenceMonitor />
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ReportBuilder />
            <CustomReportBuilder />
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-6">
          <MacroPointIntegration brokerId="broker-123" />
        </TabsContent>

        <TabsContent value="otm" className="space-y-6">
          <OTMControlTower enterpriseId="enterprise-456" />
        </TabsContent>

        <TabsContent value="powerbi" className="space-y-6">
          <PowerBIDashboard role="ops" clientId="client-789" />
        </TabsContent>

        <TabsContent value="mockup" className="space-y-6">
          <FullDashboardMockup />
        </TabsContent>

        <TabsContent value="carrier-heatmap" className="space-y-6">
          <CarrierComplianceHeatmap />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Analytics;