import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/useWebSocket";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  MessageCircle, 
  Plus, 
  Search, 
  Send, 
  Users, 
  Archive,
  Clock,
  Building,
  Link as LinkIcon,
} from "lucide-react";
import { format } from "date-fns";
import { Link } from "wouter";

interface Conversation {
  id: string;
  subject: string;
  status: string;
  lastMessage?: {
    content: string;
    createdAt: string;
    senderName: string;
  };
  unreadCount: number;
  relatedOpportunityId?: string;
  relatedPartnershipId?: string;
  relatedTransactionId?: string;
  createdAt: string;
  updatedAt: string;
}

interface Message {
  message: {
    id: string;
    content: string;
    messageType: string;
    attachmentUrl?: string;
    attachmentName?: string;
    createdAt: string;
    isEdited: boolean;
  };
  sender: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
    companyName?: string;
    role: string;
  };
}

interface Participant {
  participant: {
    isAdmin: boolean;
    joinedAt: string;
  };
  user: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
    companyName?: string;
    role: string;
    email: string;
  };
}

export default function Messages() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [newConversationOpen, setNewConversationOpen] = useState(false);
  const [newConversationSubject, setNewConversationSubject] = useState("");
  const [newConversationParticipants, setNewConversationParticipants] = useState("");
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // WebSocket for real-time messaging
  const { isConnected } = useWebSocket({
    onMessage: (message) => {
      if (message.type === 'new_message' && message.conversationId) {
        // Refresh conversations and messages when new message arrives
        queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
        if (message.conversationId === selectedConversation) {
          queryClient.invalidateQueries({ 
            queryKey: ['/api/conversations', selectedConversation, 'messages'] 
          });
        }
      }
    },
    onConnect: () => {
      console.log('Connected to real-time messaging');
    },
    onDisconnect: () => {
      console.log('Disconnected from real-time messaging');
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch conversations
  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/conversations'],
    enabled: isAuthenticated,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch messages for selected conversation
  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/conversations', selectedConversation, 'messages'],
    enabled: !!selectedConversation,
    refetchInterval: 5000, // Refresh every 5 seconds for real-time feel
  });

  // Fetch participants for selected conversation
  const { data: participants } = useQuery({
    queryKey: ['/api/conversations', selectedConversation, 'participants'],
    enabled: !!selectedConversation,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string }) => {
      return await apiRequest("POST", `/api/conversations/${selectedConversation}/messages`, data);
    },
    onSuccess: () => {
      setMessageContent("");
      // Note: WebSocket will handle real-time updates, but keep local refresh as fallback
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations', selectedConversation, 'messages'] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Create conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: async (data: { subject: string; participantIds: string[] }) => {
      return await apiRequest("POST", "/api/conversations", data);
    },
    onSuccess: (conversation: any) => {
      setNewConversationOpen(false);
      setNewConversationSubject("");
      setNewConversationParticipants("");
      setSelectedConversation(conversation.id);
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      toast({
        title: "Success",
        description: "Conversation created successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create conversation",
        variant: "destructive",
      });
    },
  });

  // Mark as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (conversationId: string) => {
      return await apiRequest("PUT", `/api/conversations/${conversationId}/read`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Mark conversation as read when selected
  useEffect(() => {
    if (selectedConversation) {
      markAsReadMutation.mutate(selectedConversation);
    }
  }, [selectedConversation]);

  const handleSendMessage = () => {
    if (!messageContent.trim() || !selectedConversation) return;
    sendMessageMutation.mutate({ content: messageContent.trim() });
  };

  const handleCreateConversation = () => {
    if (!newConversationSubject.trim()) return;
    
    // Parse participant emails/IDs (simple implementation)
    const participantIds = newConversationParticipants
      .split(',')
      .map(p => p.trim())
      .filter(p => p);
    
    createConversationMutation.mutate({
      subject: newConversationSubject.trim(),
      participantIds,
    });
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: { [key: string]: string } = {
      carrier: "Carrier",
      "3pl": "3PL Manager",
      broker: "Broker",
      shipper: "Shipper"
    };
    return roleMap[role] || role;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const selectedConversationData = (conversations as Conversation[] || []).find((c: Conversation) => c.id === selectedConversation);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">PWLoGiCon</h1>
              <p className="text-xs text-gray-500 ml-2">Logistics Partnership Platform</p>
              <nav className="hidden md:ml-8 md:flex md:space-x-8">
                <Link href="/" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Dashboard
                </Link>
                <Link href="/transactions" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Transactions
                </Link>
                <Link href="/integrations" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Integrations
                </Link>
                <Link href="/analytics" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Analytics
                </Link>
                <Link href="/messages" className="text-primary border-b-2 border-primary px-3 py-2 text-sm font-medium">
                  Messages
                </Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">
                    {(user as any)?.firstName} {(user as any)?.lastName}
                  </p>
                  <p className="text-xs text-gray-500">
                    {getRoleDisplay((user as any)?.role || "")}
                  </p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
          {/* Conversations List */}
          <div className="lg:col-span-1">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Messages
                  </CardTitle>
                  <Dialog open={newConversationOpen} onOpenChange={setNewConversationOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Start New Conversation</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Subject</label>
                          <Input
                            value={newConversationSubject}
                            onChange={(e) => setNewConversationSubject(e.target.value)}
                            placeholder="Enter conversation subject"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Participants (User IDs, comma-separated)</label>
                          <Input
                            value={newConversationParticipants}
                            onChange={(e) => setNewConversationParticipants(e.target.value)}
                            placeholder="user1@example.com, user2@example.com"
                          />
                        </div>
                        <Button 
                          onClick={handleCreateConversation}
                          disabled={createConversationMutation.isPending}
                          className="w-full"
                        >
                          {createConversationMutation.isPending ? "Creating..." : "Start Conversation"}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search conversations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent className="flex-1 p-0">
                <ScrollArea className="h-full">
                  {conversationsLoading ? (
                    <div className="p-4 text-center text-gray-500">Loading conversations...</div>
                  ) : !(conversations as Conversation[] || []).length ? (
                    <div className="p-4 text-center text-gray-500">No conversations yet</div>
                  ) : (
                    <div className="divide-y">
                      {(conversations as Conversation[] || [])
                        .filter((conv: Conversation) => 
                          !searchQuery || 
                          conv.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          conv.lastMessage?.content.toLowerCase().includes(searchQuery.toLowerCase())
                        )
                        .map((conversation: Conversation) => (
                          <div
                            key={conversation.id}
                            className={`p-4 cursor-pointer hover:bg-gray-50 ${
                              selectedConversation === conversation.id ? 'bg-blue-50 border-r-2 border-blue-500' : ''
                            }`}
                            onClick={() => setSelectedConversation(conversation.id)}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <h4 className="text-sm font-medium text-gray-900 truncate">
                                    {conversation.subject}
                                  </h4>
                                  {conversation.unreadCount > 0 && (
                                    <Badge variant="destructive" className="text-xs px-1 py-0">
                                      {conversation.unreadCount}
                                    </Badge>
                                  )}
                                </div>
                                {conversation.lastMessage && (
                                  <p className="text-xs text-gray-500 truncate mt-1">
                                    {conversation.lastMessage.senderName}: {conversation.lastMessage.content}
                                  </p>
                                )}
                                <div className="flex items-center gap-2 mt-2">
                                  <Clock className="h-3 w-3 text-gray-400" />
                                  <span className="text-xs text-gray-400">
                                    {conversation.lastMessage 
                                      ? format(new Date(conversation.lastMessage.createdAt), 'MMM d, h:mm a')
                                      : format(new Date(conversation.createdAt), 'MMM d, h:mm a')
                                    }
                                  </span>
                                  {(conversation.relatedOpportunityId || conversation.relatedPartnershipId || conversation.relatedTransactionId) && (
                                    <LinkIcon className="h-3 w-3 text-blue-500" />
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Messages Area */}
          <div className="lg:col-span-2">
            {selectedConversation ? (
              <Card className="h-full flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{selectedConversationData?.subject}</CardTitle>
                      <p className="text-sm text-gray-500 mt-1">
                        {(participants as Participant[] || []).length} participant{(participants as Participant[] || []).length !== 1 ? 's' : ''}
                        {isConnected && (
                          <span className="ml-2 inline-block w-2 h-2 bg-green-500 rounded-full" title="Real-time messaging active"></span>
                        )}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm">
                        <Users className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Archive className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <Separator />
                <CardContent className="flex-1 p-4 overflow-hidden flex flex-col">
                  <ScrollArea className="flex-1 pr-4">
                    {messagesLoading ? (
                      <div className="text-center text-gray-500 py-8">Loading messages...</div>
                    ) : !(messages as Message[] || []).length ? (
                      <div className="text-center text-gray-500 py-8">No messages yet. Start the conversation!</div>
                    ) : (
                      <div className="space-y-4">
                        {(messages as Message[] || []).map((msg: Message) => (
                          <div
                            key={msg.message.id}
                            className={`flex ${msg.sender.id === (user as any)?.id ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className={`flex items-start gap-3 max-w-xs lg:max-w-md ${
                              msg.sender.id === (user as any)?.id ? 'flex-row-reverse' : 'flex-row'
                            }`}>
                              <Avatar className="h-8 w-8 flex-shrink-0">
                                <AvatarImage src={msg.sender.profileImageUrl} />
                                <AvatarFallback>
                                  {getInitials(msg.sender.firstName, msg.sender.lastName)}
                                </AvatarFallback>
                              </Avatar>
                              <div className={`flex flex-col ${
                                msg.sender.id === (user as any)?.id ? 'items-end' : 'items-start'
                              }`}>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-xs font-medium text-gray-900">
                                    {msg.sender.firstName} {msg.sender.lastName}
                                  </span>
                                  <span className="text-xs text-gray-500">
                                    {format(new Date(msg.message.createdAt), 'h:mm a')}
                                  </span>
                                </div>
                                <div className={`rounded-lg px-3 py-2 ${
                                  msg.sender.id === (user as any)?.id 
                                    ? 'bg-blue-500 text-white' 
                                    : 'bg-gray-100 text-gray-900'
                                }`}>
                                  <p className="text-sm">{msg.message.content}</p>
                                  {msg.message.isEdited && (
                                    <span className="text-xs opacity-75 italic">edited</span>
                                  )}
                                </div>
                                {msg.sender.companyName && (
                                  <div className="flex items-center gap-1 mt-1">
                                    <Building className="h-3 w-3 text-gray-400" />
                                    <span className="text-xs text-gray-500">{msg.sender.companyName}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </div>
                    )}
                  </ScrollArea>
                  <div className="flex-shrink-0 pt-4">
                    <div className="flex gap-2">
                      <Textarea
                        value={messageContent}
                        onChange={(e) => setMessageContent(e.target.value)}
                        placeholder="Type your message..."
                        className="flex-1 min-h-[80px] resize-none"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button 
                        onClick={handleSendMessage}
                        disabled={!messageContent.trim() || sendMessageMutation.isPending}
                        size="sm"
                        className="self-end"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Press Enter to send, Shift+Enter for new line
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MessageCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium mb-2">Select a conversation</h3>
                  <p className="text-sm">Choose a conversation from the list to start messaging</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}