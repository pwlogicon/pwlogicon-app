import { useToast } from "@/hooks/use-toast";
import GeospatialHeatMap from "@/components/GeospatialHeatMap";

export default function GeospatialHeatMapPage() {
  const { toast } = useToast();

  const handleRegionSelect = (region: string) => {
    toast({
      title: "Region Selected",
      description: `Analyzing logistics network for ${region}`,
    });
  };

  const handleRouteAnalyze = (routeId: string) => {
    toast({
      title: "Route Analysis",
      description: `Opening detailed analysis for route ${routeId}`,
    });
  };

  const handleNodeInspect = (nodeId: string) => {
    toast({
      title: "Node Inspection",
      description: `Inspecting network node ${nodeId} performance and connections`,
    });
  };

  const handleExportData = (format: string) => {
    toast({
      title: `Export ${format.toUpperCase()}`,
      description: `Generating geospatial data export in ${format} format`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <GeospatialHeatMap
        onRegionSelect={handleRegionSelect}
        onRouteAnalyze={handleRouteAnalyze}
        onNodeInspect={handleNodeInspect}
        onExportData={handleExportData}
      />
    </div>
  );
}