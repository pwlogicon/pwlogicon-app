import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { AgreementConfirmationModal } from "@/components/AgreementConfirmationModal";
import { 
  DollarSign,
  Percent,
  Clock,
  CheckCircle,
  TrendingUp,
  Bell,
  Eye,
  Check,
  Download,
  Settings,
  ArrowUp
} from "lucide-react";

export default function Transactions() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPartnership, setSelectedPartnership] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/analytics/revenue"],
    enabled: isAuthenticated,
  });

  const { data: pendingPartnerships, isLoading: pendingLoading } = useQuery({
    queryKey: ["/api/partnerships/pending"],
    enabled: isAuthenticated,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
    enabled: isAuthenticated,
  });

  const confirmPartnershipMutation = useMutation({
    mutationFn: async (partnershipId: string) => {
      return apiRequest("POST", `/api/partnerships/${partnershipId}/confirm`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/partnerships/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/revenue"] });
      setShowModal(false);
      setSelectedPartnership(null);
      toast({
        title: "Partnership Confirmed",
        description: "Commission payment has been processed successfully.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to confirm partnership. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Skeleton className="w-8 h-8 rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const getRoleDisplay = (role: string) => {
    const roleMap: { [key: string]: string } = {
      carrier: "Carrier",
      "3pl": "3PL Manager", 
      broker: "Broker",
      shipper: "Shipper"
    };
    return roleMap[role] || role;
  };

  const handleConfirmAgreement = (partnership: any) => {
    setSelectedPartnership(partnership);
    setShowModal(true);
  };

  const handleConfirmPartnership = () => {
    if (selectedPartnership) {
      confirmPartnershipMutation.mutate(selectedPartnership.id);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: { [key: string]: { variant: any; label: string } } = {
      pending: { variant: "secondary", label: "Pending Confirmation" },
      processing: { variant: "outline", label: "Processing" },
      paid: { variant: "default", label: "Paid" },
      failed: { variant: "destructive", label: "Failed" }
    };
    
    const config = statusConfig[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getServiceTypeBadge = (serviceType: string) => {
    const typeConfig: { [key: string]: { variant: any; label: string } } = {
      ftl: { variant: "default", label: "FTL" },
      ltl: { variant: "secondary", label: "LTL" },
      intermodal: { variant: "outline", label: "Intermodal" },
      reefer: { variant: "destructive", label: "Reefer" },
      drayage: { variant: "secondary", label: "Drayage" }
    };
    
    const config = typeConfig[serviceType] || { variant: "outline", label: serviceType };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">PWLoGiCon</h1>
              <p className="text-xs text-gray-500 ml-2">Logistics Partnership Platform</p>
              <nav className="hidden md:ml-8 md:flex md:space-x-8">
                <Link href="/" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Dashboard
                </Link>
                <Link href="/opportunities" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Opportunities
                </Link>
                <Link href="/partnerships" className="text-gray-500 hover:text-primary px-3 py-2 text-sm font-medium">
                  Partnerships
                </Link>
                <Link href="/transactions" className="text-primary border-b-2 border-primary px-3 py-2 text-sm font-medium">
                  Transactions
                </Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">
                    {(user as any)?.firstName} {(user as any)?.lastName}
                  </p>
                  <p className="text-xs text-gray-500">
                    {getRoleDisplay((user as any)?.role || "")}
                  </p>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Transaction Fee Management
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Manage commission structure and track earnings from successful partnerships
              </p>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export Report
              </Button>
              <Button>
                <Settings className="mr-2 h-4 w-4" />
                Configure Fees
              </Button>
            </div>
          </div>
        </div>

        {/* Fee Model Configuration Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-secondary rounded-md flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <CardTitle>Flat Fee Model</CardTitle>
                  <CardDescription>Fixed commission per successful match</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">$50</div>
                  <div className="text-sm text-gray-500">per successful partnership</div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Active Partnerships</span>
                  <span className="text-sm font-medium text-gray-900">
                    {(pendingPartnerships as any)?.filter((p: any) => p.feeModel === "flat").length || 0}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Monthly Revenue</span>
                  <span className="text-sm font-medium text-secondary">
                    ${((analytics as any)?.monthlyRevenue || 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Success Rate</span>
                  <span className="text-sm font-medium text-gray-900">
                    {(analytics as any)?.successRate || 0}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                  <Percent className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <CardTitle>Percent Fee Model</CardTitle>
                  <CardDescription>Commission based on contract value</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">1-5%</div>
                  <div className="text-sm text-gray-500">of total contract value</div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Contract Volume</span>
                  <span className="text-sm font-medium text-gray-900">
                    ${(((analytics as any)?.monthlyRevenue || 0) * 20).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Average Rate</span>
                  <span className="text-sm font-medium text-gray-900">2.8%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Monthly Revenue</span>
                  <span className="text-sm font-medium text-secondary">
                    ${((analytics as any)?.monthlyRevenue || 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Agreements */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Pending Agreement Confirmations</CardTitle>
            <CardDescription>
              Partnerships awaiting confirmation to trigger commission payments
            </CardDescription>
          </CardHeader>
          <CardContent>
            {pendingLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                    <Skeleton className="h-8 w-24" />
                  </div>
                ))}
              </div>
            ) : (pendingPartnerships as any) && (pendingPartnerships as any).length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Partnership
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Service Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contract Value
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fee Model
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Potential Fee
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {(pendingPartnerships as any).map((partnership: any) => (
                      <tr key={partnership.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                <TrendingUp className="h-5 w-5 text-gray-600" />
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                Partnership #{partnership.id.slice(0, 8)}
                              </div>
                              <div className="text-sm text-gray-500">
                                Active Partnership
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getServiceTypeBadge("ftl")}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {partnership.contractValue ? `$${parseFloat(partnership.contractValue).toLocaleString()}` : "N/A"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {partnership.feeModel === "flat" ? "Flat Fee" : `Percent (${partnership.feePercentage || 3}%)`}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-secondary">
                          ${parseFloat(partnership.feeAmount || "50").toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge("pending")}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleConfirmAgreement(partnership)}
                            className="text-primary hover:text-blue-900 mr-3"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No pending agreements</h3>
                <p className="mt-1 text-sm text-gray-500">
                  All partnerships have been confirmed.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-secondary rounded-md flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <CardTitle>Monthly Revenue</CardTitle>
                  <CardDescription>Total commission earned</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <>
                  <div className="text-3xl font-bold text-gray-900">
                    ${((analytics as any)?.monthlyRevenue || 0).toLocaleString()}
                  </div>
                  <div className="flex items-center mt-2">
                    <ArrowUp className="h-4 w-4 text-secondary" />
                    <span className="text-sm text-secondary ml-1">+12.5%</span>
                    <span className="text-sm text-gray-500 ml-2">vs last month</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-yellow-500 rounded-md flex items-center justify-center">
                  <Clock className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <CardTitle>Pending Payments</CardTitle>
                  <CardDescription>Awaiting confirmation</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <>
                  <div className="text-3xl font-bold text-gray-900">
                    ${((analytics as any)?.pendingPayments || 0).toLocaleString()}
                  </div>
                  <div className="flex items-center mt-2">
                    <span className="text-sm text-gray-500">
                      {(pendingPartnerships as any)?.length || 0} agreements pending
                    </span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <CardTitle>Success Rate</CardTitle>
                  <CardDescription>Confirmed partnerships</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <>
                  <div className="text-3xl font-bold text-gray-900">
                    {(analytics as any)?.successRate || 0}%
                  </div>
                  <div className="flex items-center mt-2">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${(analytics as any)?.successRate || 0}%` }}
                      />
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Commission history and payment status</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {transactionsLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                ))}
              </div>
            ) : (transactions as any) && (transactions as any).length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Partnership
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fee Model
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Commission
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Payment Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Payment Method
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {(transactions as any).map((transaction: any) => (
                      <tr key={transaction.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(transaction.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            Partnership #{transaction.partnershipId?.slice(0, 8)}
                          </div>
                          <div className="text-sm text-gray-500">Commission Transaction</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          Commission Fee
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          ${parseFloat(transaction.amount).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(transaction.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            Platform Fee
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No transactions yet</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Transactions will appear here once partnerships are confirmed.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <AgreementConfirmationModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setSelectedPartnership(null);
        }}
        partnership={selectedPartnership}
        onConfirm={handleConfirmPartnership}
        isLoading={confirmPartnershipMutation.isPending}
      />
    </div>
  );
}
