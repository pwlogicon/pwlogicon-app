import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface OfflineQueueItem {
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  resource: string;
  resourceId?: string;
  data: any;
}

interface UseOfflineSyncReturn {
  isOnline: boolean;
  pendingCount: number;
  addToQueue: (item: OfflineQueueItem) => void;
  syncNow: () => void;
  isSyncing: boolean;
}

export function useOfflineSync(): UseOfflineSyncReturn {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingQueue, setPendingQueue] = useState<OfflineQueueItem[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Sync mutation
  const syncMutation = useMutation({
    mutationFn: async () => {
      // Add pending items to server queue
      for (const item of pendingQueue) {
        await apiRequest('POST', '/api/mobile/offline-queue', item);
      }
      
      // Trigger server sync
      return await apiRequest('POST', '/api/mobile/sync', {});
    },
    onSuccess: (result) => {
      setPendingQueue([]);
      localStorage.removeItem('offlineQueue');
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/field-operations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mobile/location/history'] });
      
      toast({
        title: 'Sync Complete',
        description: `Synced ${result.success} items successfully`,
      });
    },
    onError: (error) => {
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync offline data. Will retry when connection improves.',
        variant: 'destructive',
      });
    },
  });

  // Load queue from localStorage on mount
  useEffect(() => {
    const savedQueue = localStorage.getItem('offlineQueue');
    if (savedQueue) {
      setPendingQueue(JSON.parse(savedQueue));
    }
  }, []);

  // Save queue to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('offlineQueue', JSON.stringify(pendingQueue));
  }, [pendingQueue]);

  // Listen for online/offline events
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Auto-sync when coming back online
      if (pendingQueue.length > 0) {
        syncMutation.mutate();
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast({
        title: 'Connection Lost',
        description: 'Working offline. Changes will sync when connection returns.',
        variant: 'default',
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [pendingQueue.length, syncMutation, toast]);

  const addToQueue = (item: OfflineQueueItem) => {
    setPendingQueue(prev => [...prev, item]);
    
    if (!isOnline) {
      toast({
        title: 'Saved Offline',
        description: 'Changes saved locally and will sync when connection returns.',
      });
    }
  };

  const syncNow = () => {
    if (pendingQueue.length > 0) {
      syncMutation.mutate();
    }
  };

  return {
    isOnline,
    pendingCount: pendingQueue.length,
    addToQueue,
    syncNow,
    isSyncing: syncMutation.isPending,
  };
}