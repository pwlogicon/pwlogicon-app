import { useState, useEffect } from 'react';

interface LocationPosition {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude?: number;
  speed?: number;
  heading?: number;
  timestamp: number;
}

interface UseGeolocationOptions {
  enableHighAccuracy?: boolean;
  timeout?: number;
  maximumAge?: number;
  watchPosition?: boolean;
}

interface UseGeolocationReturn {
  position: LocationPosition | null;
  error: string | null;
  loading: boolean;
  isSupported: boolean;
  getCurrentPosition: () => void;
}

export function useGeolocation(options: UseGeolocationOptions = {}): UseGeolocationReturn {
  const [position, setPosition] = useState<LocationPosition | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isSupported = 'geolocation' in navigator;

  const geolocationOptions: PositionOptions = {
    enableHighAccuracy: options.enableHighAccuracy ?? true,
    timeout: options.timeout ?? 10000,
    maximumAge: options.maximumAge ?? 60000,
  };

  const handleSuccess = (pos: GeolocationPosition) => {
    setPosition({
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude,
      accuracy: pos.coords.accuracy,
      altitude: pos.coords.altitude || undefined,
      speed: pos.coords.speed || undefined,
      heading: pos.coords.heading || undefined,
      timestamp: pos.timestamp,
    });
    setError(null);
    setLoading(false);
  };

  const handleError = (err: GeolocationPositionError) => {
    let errorMessage = 'Unknown location error';
    
    switch (err.code) {
      case err.PERMISSION_DENIED:
        errorMessage = 'Location access denied by user';
        break;
      case err.POSITION_UNAVAILABLE:
        errorMessage = 'Location information unavailable';
        break;
      case err.TIMEOUT:
        errorMessage = 'Location request timeout';
        break;
    }
    
    setError(errorMessage);
    setLoading(false);
  };

  const getCurrentPosition = () => {
    if (!isSupported) {
      setError('Geolocation is not supported by this browser');
      return;
    }

    setLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      handleSuccess,
      handleError,
      geolocationOptions
    );
  };

  useEffect(() => {
    if (!isSupported || !options.watchPosition) return;

    setLoading(true);
    
    const watchId = navigator.geolocation.watchPosition(
      handleSuccess,
      handleError,
      geolocationOptions
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [isSupported, options.watchPosition, geolocationOptions]);

  return {
    position,
    error,
    loading,
    isSupported,
    getCurrentPosition,
  };
}