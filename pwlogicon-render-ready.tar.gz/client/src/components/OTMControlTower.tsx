import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ComposedChart,
  Area,
  AreaChart
} from 'recharts';
import { 
  Building2, 
  DollarSign, 
  TrendingUp, 
  Shield, 
  Clock, 
  MapPin, 
  AlertTriangle,
  CheckCircle,
  Activity,
  FileText,
  Settings,
  BarChart3,
  Target,
  Truck,
  Package
} from 'lucide-react';

interface OTMControlTowerProps {
  enterpriseId?: string;
}

const COLORS = ['#8B5CF6', '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#6B7280'];

const OTMControlTower: React.FC<OTMControlTowerProps> = ({ enterpriseId }) => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [costAnalytics, setCostAnalytics] = useState<any>(null);
  const [complianceData, setComplianceData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedTimeframe, setSelectedTimeframe] = useState('month');

  useEffect(() => {
    fetchOTMData();
    const interval = setInterval(fetchOTMData, 45000);
    return () => clearInterval(interval);
  }, [enterpriseId, selectedTimeframe]);

  const fetchOTMData = async () => {
    try {
      setLoading(true);
      const [dashboardRes, costRes, complianceRes] = await Promise.all([
        fetch(`/api/otm/dashboard?timeframe=${selectedTimeframe}${enterpriseId ? `&enterpriseId=${enterpriseId}` : ''}`),
        fetch(`/api/otm/cost-analytics?timeframe=${selectedTimeframe}${enterpriseId ? `&enterpriseId=${enterpriseId}` : ''}`),
        fetch(`/api/otm/compliance?timeframe=${selectedTimeframe}${enterpriseId ? `&enterpriseId=${enterpriseId}` : ''}`)
      ]);

      const [dashboard, cost, compliance] = await Promise.all([
        dashboardRes.json(),
        costRes.json(),
        complianceRes.json()
      ]);

      setDashboardData(dashboard);
      setCostAnalytics(cost);
      setComplianceData(compliance);
    } catch (error) {
      console.error('Failed to fetch OTM data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const getComplianceColor = (score: number) => {
    if (score >= 95) return 'text-green-600 bg-green-50';
    if (score >= 90) return 'text-blue-600 bg-blue-50';
    if (score >= 85) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center space-y-4">
            <Activity className="h-8 w-8 animate-spin text-purple-500" />
            <p className="text-sm text-gray-600">Loading OTM Control Tower...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-6 w-6 text-purple-600" />
            Oracle Transportation Management (OTM) Control Tower
            <Badge variant="outline" className="ml-auto">
              Enterprise Dashboard
            </Badge>
          </CardTitle>
          <div className="flex gap-2">
            {['week', 'month', 'quarter', 'year'].map((timeframe) => (
              <Button
                key={timeframe}
                variant={selectedTimeframe === timeframe ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedTimeframe(timeframe)}
              >
                {timeframe.charAt(0).toUpperCase() + timeframe.slice(1)}
              </Button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="text-2xl font-bold text-purple-600">
                {formatCurrency(dashboardData?.totalSpend || 0)}
              </h3>
              <p className="text-sm text-gray-600">Total Transportation Spend</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="text-2xl font-bold text-blue-600">
                {dashboardData?.activeCarriers || 0}
              </h3>
              <p className="text-sm text-gray-600">Active Carriers</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="text-2xl font-bold text-green-600">
                {dashboardData?.serviceLevel || 0}%
              </h3>
              <p className="text-sm text-gray-600">Service Level Compliance</p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <h3 className="text-2xl font-bold text-yellow-600">
                {dashboardData?.costSavings || 0}%
              </h3>
              <p className="text-sm text-gray-600">Cost Optimization</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <h3 className="text-2xl font-bold text-orange-600">
                {dashboardData?.shipmentVolume || 0}
              </h3>
              <p className="text-sm text-gray-600">Monthly Shipments</p>
            </div>
          </div>

          <Tabs defaultValue="cost-analytics" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="cost-analytics">Cost-to-Serve Analytics</TabsTrigger>
              <TabsTrigger value="consolidation">Consolidation Insights</TabsTrigger>
              <TabsTrigger value="compliance">Service Level Compliance</TabsTrigger>
              <TabsTrigger value="financial">Financial Planning</TabsTrigger>
            </TabsList>

            <TabsContent value="cost-analytics" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Cost-to-Serve Analytics by Lane, Mode & Customer</h3>
                <Button onClick={fetchOTMData} variant="outline" size="sm">
                  <Activity className="h-4 w-4 mr-2" />
                  Refresh Data
                </Button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <BarChart3 className="h-4 w-4" />
                      Cost per Mile by Lane
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={costAnalytics?.laneAnalysis || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="lane" angle={-45} textAnchor="end" height={80} fontSize={10} />
                        <YAxis />
                        <Tooltip 
                          formatter={(value) => [formatCurrency(value as number), 'Cost per Mile']}
                          labelStyle={{ color: '#000' }}
                        />
                        <Bar dataKey="costPerMile" fill="#8B5CF6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Truck className="h-4 w-4" />
                      Transportation Mode Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={costAnalytics?.modeAnalysis || []}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          dataKey="cost"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                        >
                          {(costAnalytics?.modeAnalysis || []).map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="col-span-full">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Customer Cost Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(costAnalytics?.customerAnalysis || []).map((customer: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                          <div className="flex items-center space-x-4">
                            <div className="w-2 h-8 rounded" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                            <div>
                              <h4 className="font-medium">{customer.customerName}</h4>
                              <p className="text-sm text-gray-600">{customer.shipmentCount} shipments</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">{formatCurrency(customer.totalCost)}</p>
                            <p className="text-sm text-gray-600">{formatCurrency(customer.costPerShipment)}/shipment</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="consolidation" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      Consolidation Opportunities
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(costAnalytics?.consolidationOpportunities || []).map((opp: any, index: number) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium">{opp.route}</h4>
                            <Badge variant="outline" className="text-green-600 bg-green-50">
                              {formatCurrency(opp.potentialSavings)} savings
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{opp.description}</p>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Current Shipments:</span>
                              <span className="ml-2 font-medium">{opp.currentShipments}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Optimized:</span>
                              <span className="ml-2 font-medium">{opp.optimizedShipments}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Mode Shifting Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <ComposedChart data={costAnalytics?.modeShiftingAnalysis || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="mode" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="currentCost" fill="#EF4444" name="Current Cost" />
                        <Bar dataKey="optimizedCost" fill="#10B981" name="Optimized Cost" />
                        <Line type="monotone" dataKey="savingsPercent" stroke="#8B5CF6" name="Savings %" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="compliance" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <CheckCircle className="h-4 w-4" />
                      On-Time Delivery
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold mb-2">{complianceData?.onTimeDelivery || 0}%</div>
                    <Progress value={complianceData?.onTimeDelivery || 0} className="mb-2" />
                    <p className="text-xs text-gray-600">Target: 95%</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      Carrier Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold mb-2">{complianceData?.carrierPerformance || 0}%</div>
                    <Progress value={complianceData?.carrierPerformance || 0} className="mb-2" />
                    <p className="text-xs text-gray-600">Target: 90%</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      SLA Compliance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold mb-2">{complianceData?.slaCompliance || 0}%</div>
                    <Progress value={complianceData?.slaCompliance || 0} className="mb-2" />
                    <p className="text-xs text-gray-600">Target: 98%</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Service Level Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={complianceData?.serviceLevelTrends || []}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="onTime" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
                      <Area type="monotone" dataKey="delayed" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="financial" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Monthly Spend Forecast
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={costAnalytics?.spendForecast || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                        <Legend />
                        <Line type="monotone" dataKey="actual" stroke="#3B82F6" strokeWidth={2} name="Actual Spend" />
                        <Line type="monotone" dataKey="forecast" stroke="#8B5CF6" strokeDasharray="5 5" strokeWidth={2} name="Forecast" />
                        <Line type="monotone" dataKey="budget" stroke="#10B981" strokeWidth={2} name="Budget" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Budget vs. Actual Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(costAnalytics?.budgetAnalysis || []).map((item: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{item.category}</h4>
                            <p className="text-sm text-gray-600">Budget: {formatCurrency(item.budget)}</p>
                          </div>
                          <div className="text-right">
                            <p className={`font-semibold ${item.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(item.actual)}
                            </p>
                            <p className={`text-sm ${item.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {item.variance >= 0 ? '+' : ''}{item.variance}%
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Financial KPIs & Planning Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="text-lg font-bold text-blue-600">{costAnalytics?.financialKPIs?.costPerShipment || 0}</h4>
                      <p className="text-sm text-gray-600">Avg Cost per Shipment</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="text-lg font-bold text-green-600">{costAnalytics?.financialKPIs?.savingsYTD || 0}%</h4>
                      <p className="text-sm text-gray-600">Savings YTD</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="text-lg font-bold text-purple-600">{costAnalytics?.financialKPIs?.budgetUtilization || 0}%</h4>
                      <p className="text-sm text-gray-600">Budget Utilization</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="text-lg font-bold text-orange-600">{costAnalytics?.financialKPIs?.costPerMile || 0}</h4>
                      <p className="text-sm text-gray-600">Avg Cost per Mile</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default OTMControlTower;