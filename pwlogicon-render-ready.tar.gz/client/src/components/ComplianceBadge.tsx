import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, Clock } from 'lucide-react';

interface ComplianceData {
  status: 'Verified' | 'Pending' | 'Rejected' | 'Expired';
  score: number;
  mcNumber: string;
  insuranceOnFile: string;
  dotCompliant: string;
  lastVerified: string;
}

interface ComplianceBadgeProps {
  userId: string;
  sid?: string;
  compact?: boolean;
  showDetails?: boolean;
}

const ComplianceBadge: React.FC<ComplianceBadgeProps> = ({ 
  userId, 
  sid, 
  compact = false, 
  showDetails = true 
}) => {
  const [compliance, setCompliance] = useState<ComplianceData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCompliance = async () => {
      try {
        const url = sid ? `/api/compliance/${userId}?sid=${sid}` : `/api/compliance/${userId}`;
        const response = await fetch(url);
        const data = await response.json();
        setCompliance(data);
      } catch (error) {
        console.error('Failed to fetch compliance data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchCompliance();
    }
  }, [userId, sid]);

  if (loading) {
    return (
      <Badge variant="outline" className="flex items-center gap-1">
        <Clock className="h-3 w-3 animate-spin" />
        Verifying...
      </Badge>
    );
  }

  if (!compliance) {
    return (
      <Badge variant="destructive" className="flex items-center gap-1">
        <AlertTriangle className="h-3 w-3" />
        No Data
      </Badge>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Verified':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Rejected':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'Expired':
        return 'bg-gray-100 text-gray-800 border-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Verified':
        return <Shield className="h-3 w-3" />;
      case 'Pending':
        return <Clock className="h-3 w-3" />;
      case 'Rejected':
      case 'Expired':
        return <AlertTriangle className="h-3 w-3" />;
      default:
        return <Clock className="h-3 w-3" />;
    }
  };

  if (compact) {
    return (
      <Badge className={getStatusColor(compliance.status)}>
        {getStatusIcon(compliance.status)}
        <span className="ml-1">{compliance.status}</span>
      </Badge>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Badge className={`${getStatusColor(compliance.status)} flex items-center gap-1`}>
        {getStatusIcon(compliance.status)}
        <span>{compliance.status}</span>
        <span className="font-mono">• {compliance.score}%</span>
      </Badge>
      
      {showDetails && (
        <div className="flex items-center gap-1 text-xs text-gray-600">
          <span className={compliance.mcNumber === '✅' ? 'text-green-600' : 'text-red-600'}>
            MC
          </span>
          <span className={compliance.insuranceOnFile === '✅' ? 'text-green-600' : 'text-red-600'}>
            INS
          </span>
          <span className={compliance.dotCompliant === '✅' ? 'text-green-600' : 'text-red-600'}>
            DOT
          </span>
        </div>
      )}
    </div>
  );
};

export default ComplianceBadge;