import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { 
  MapIcon, 
  LayersIcon,
  TargetIcon,
  TrendingUpIcon,
  ZoomInIcon,
  ZoomOutIcon,
  RefreshCwIcon,
  SettingsIcon,
  FilterIcon,
  DownloadIcon,
  MaximizeIcon,
  ActivityIcon,
  TruckIcon,
  BarChart3Icon
} from "lucide-react";

interface HeatMapData {
  networkNodes: Array<{
    id: string;
    lat: number;
    lng: number;
    type: 'warehouse' | 'distribution_center' | 'terminal' | 'port';
    name: string;
    volume: number;
    utilization: number;
    connections: number;
    performance: number;
  }>;
  routes: Array<{
    id: string;
    origin: { lat: number; lng: number; name: string };
    destination: { lat: number; lng: number; name: string };
    volume: number;
    frequency: number;
    avgTransitTime: number;
    costPerMile: number;
    reliability: number;
    density: 'high' | 'medium' | 'low';
  }>;
  heatMapLayers: {
    volume: Array<{ lat: number; lng: number; intensity: number }>;
    density: Array<{ lat: number; lng: number; intensity: number }>;
    performance: Array<{ lat: number; lng: number; intensity: number }>;
    cost: Array<{ lat: number; lng: number; intensity: number }>;
  };
  regions: Array<{
    name: string;
    bounds: { north: number; south: number; east: number; west: number };
    metrics: {
      totalVolume: number;
      avgPerformance: number;
      nodeCount: number;
      avgCost: number;
    };
  }>;
}

interface GeospatialHeatMapProps {
  onRegionSelect?: (region: string) => void;
  onRouteAnalyze?: (routeId: string) => void;
  onNodeInspect?: (nodeId: string) => void;
  onExportData?: (format: string) => void;
}

export default function GeospatialHeatMap({
  onRegionSelect,
  onRouteAnalyze,
  onNodeInspect,
  onExportData
}: GeospatialHeatMapProps) {
  const [mapLayer, setMapLayer] = useState("volume");
  const [timeRange, setTimeRange] = useState("7d");
  const [zoomLevel, setZoomLevel] = useState([6]);
  const [showRoutes, setShowRoutes] = useState(true);
  const [showNodes, setShowNodes] = useState(true);
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [intensityThreshold, setIntensityThreshold] = useState([0.5]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch heat map data
  const { data: heatMapData, isLoading, error } = useQuery<HeatMapData>({
    queryKey: ['/api/geospatial-heatmap', timeRange, mapLayer, selectedRegion],
    refetchInterval: 60000, // Refresh every minute for real-time updates
  });

  // Generate heat map mutation
  const generateHeatMapMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/geospatial-heatmap/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          timeRange, 
          layer: mapLayer, 
          region: selectedRegion,
          threshold: intensityThreshold[0]
        })
      });
      if (!response.ok) throw new Error('Failed to generate heat map');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/geospatial-heatmap'] });
      toast({ title: "Heat map updated with latest network data" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Heat map generation failed", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    if (!isFullscreen) {
      mapRef.current?.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  };

  const getLayerColor = (layer: string) => {
    switch (layer) {
      case 'volume': return 'bg-blue-500';
      case 'density': return 'bg-green-500';
      case 'performance': return 'bg-orange-500';
      case 'cost': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getNodeTypeIcon = (type: string) => {
    switch (type) {
      case 'warehouse': return '🏭';
      case 'distribution_center': return '🏢';
      case 'terminal': return '🚛';
      case 'port': return '⚓';
      default: return '📍';
    }
  };

  const getDensityColor = (density: string) => {
    switch (density) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-orange-600 bg-orange-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  useEffect(() => {
    // Initialize map when component mounts
    if (heatMapData && mapRef.current) {
      console.log('Geospatial heat map initialized with:', heatMapData.networkNodes.length, 'nodes');
    }
  }, [heatMapData]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-96 bg-gray-200 rounded-lg animate-pulse flex items-center justify-center">
          <div className="text-gray-500">Loading geospatial heat map...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-red-600">
            <MapIcon className="h-5 w-5" />
            <span>Failed to load geospatial heat map</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-white p-4' : ''}`}>
      {/* Heat Map Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MapIcon className="h-6 w-6 text-blue-600" />
            Interactive Geospatial Heat Map
          </h2>
          <p className="text-gray-600">Real-time logistics network visualization and density analysis</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">24 Hours</SelectItem>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
              <SelectItem value="90d">90 Days</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="northeast">Northeast</SelectItem>
              <SelectItem value="southeast">Southeast</SelectItem>
              <SelectItem value="midwest">Midwest</SelectItem>
              <SelectItem value="west">West Coast</SelectItem>
              <SelectItem value="southwest">Southwest</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            onClick={() => generateHeatMapMutation.mutate()}
            disabled={generateHeatMapMutation.isPending}
            variant="outline"
            size="sm"
          >
            <RefreshCwIcon className={`h-4 w-4 mr-2 ${generateHeatMapMutation.isPending ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          <Button
            onClick={toggleFullscreen}
            variant="outline"
            size="sm"
          >
            <MaximizeIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Controls Panel */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Heat Map Controls</CardTitle>
            <Badge variant="outline" className="flex items-center gap-1">
              <ActivityIcon className="h-3 w-3" />
              Live Data
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={mapLayer} onValueChange={setMapLayer} className="space-y-4">
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="volume" className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getLayerColor('volume')}`}></div>
                Volume
              </TabsTrigger>
              <TabsTrigger value="density" className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getLayerColor('density')}`}></div>
                Density
              </TabsTrigger>
              <TabsTrigger value="performance" className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getLayerColor('performance')}`}></div>
                Performance
              </TabsTrigger>
              <TabsTrigger value="cost" className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getLayerColor('cost')}`}></div>
                Cost
              </TabsTrigger>
            </TabsList>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-3">
                <label className="text-sm font-medium">Zoom Level</label>
                <Slider
                  value={zoomLevel}
                  onValueChange={setZoomLevel}
                  max={12}
                  min={3}
                  step={1}
                  className="w-full"
                />
                <div className="text-xs text-gray-500">Level: {zoomLevel[0]}</div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Intensity Threshold</label>
                <Slider
                  value={intensityThreshold}
                  onValueChange={setIntensityThreshold}
                  max={1}
                  min={0}
                  step={0.1}
                  className="w-full"
                />
                <div className="text-xs text-gray-500">{(intensityThreshold[0] * 100).toFixed(0)}%</div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Show Routes</label>
                  <Switch checked={showRoutes} onCheckedChange={setShowRoutes} />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Show Nodes</label>
                  <Switch checked={showNodes} onCheckedChange={setShowNodes} />
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  onClick={() => onExportData?.('png')}
                  variant="outline"
                  size="sm"
                  className="w-full"
                >
                  <DownloadIcon className="h-4 w-4 mr-2" />
                  Export PNG
                </Button>
                <Button
                  onClick={() => onExportData?.('geojson')}
                  variant="outline"
                  size="sm"
                  className="w-full"
                >
                  <DownloadIcon className="h-4 w-4 mr-2" />
                  Export GeoJSON
                </Button>
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      {/* Main Heat Map Display */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Interactive Map */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <LayersIcon className="h-5 w-5" />
                {mapLayer.charAt(0).toUpperCase() + mapLayer.slice(1)} Heat Map
              </CardTitle>
              <CardDescription>
                Interactive visualization showing {mapLayer} patterns across the logistics network
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div 
                ref={mapRef}
                className="relative h-96 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border overflow-hidden"
                style={{ height: isFullscreen ? 'calc(100vh - 200px)' : '600px' }}
              >
                {/* Simulated Map Background */}
                <div className="absolute inset-0 bg-gray-100">
                  <svg width="100%" height="100%" className="opacity-20">
                    <defs>
                      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                  </svg>
                </div>

                {/* Heat Map Visualization */}
                <div className="absolute inset-4 space-y-4">
                  {/* Network Nodes */}
                  {showNodes && heatMapData?.networkNodes.map((node, index) => (
                    <div
                      key={node.id}
                      className="absolute w-4 h-4 rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-125 transition-transform"
                      style={{
                        left: `${15 + (index % 8) * 10}%`,
                        top: `${20 + Math.floor(index / 8) * 15}%`,
                        backgroundColor: node.utilization > 80 ? '#ef4444' : node.utilization > 60 ? '#f59e0b' : '#10b981'
                      }}
                      onClick={() => onNodeInspect?.(node.id)}
                      title={`${node.name}: ${node.utilization}% utilization`}
                    >
                      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs bg-white px-1 rounded shadow opacity-0 hover:opacity-100 transition-opacity">
                        {getNodeTypeIcon(node.type)} {node.name}
                      </div>
                    </div>
                  ))}

                  {/* Route Lines */}
                  {showRoutes && heatMapData?.routes.slice(0, 6).map((route, index) => (
                    <svg
                      key={route.id}
                      className="absolute inset-0 pointer-events-none"
                      style={{ zIndex: 1 }}
                    >
                      <line
                        x1={`${20 + (index % 4) * 15}%`}
                        y1={`${25 + Math.floor(index / 4) * 20}%`}
                        x2={`${40 + (index % 4) * 15}%`}
                        y2={`${45 + Math.floor(index / 4) * 20}%`}
                        stroke={route.density === 'high' ? '#ef4444' : route.density === 'medium' ? '#f59e0b' : '#10b981'}
                        strokeWidth={route.density === 'high' ? 4 : route.density === 'medium' ? 3 : 2}
                        strokeOpacity="0.8"
                        className="animate-pulse"
                      />
                    </svg>
                  ))}

                  {/* Heat Map Overlay */}
                  <div className="absolute inset-0 pointer-events-none">
                    {heatMapData?.heatMapLayers[mapLayer as keyof typeof heatMapData.heatMapLayers]?.slice(0, 12).map((point, index) => (
                      <div
                        key={index}
                        className="absolute rounded-full"
                        style={{
                          left: `${10 + (index % 6) * 15}%`,
                          top: `${15 + Math.floor(index / 6) * 25}%`,
                          width: `${point.intensity * 60 + 20}px`,
                          height: `${point.intensity * 60 + 20}px`,
                          background: `radial-gradient(circle, ${
                            mapLayer === 'volume' ? 'rgba(59, 130, 246, 0.4)' :
                            mapLayer === 'density' ? 'rgba(34, 197, 94, 0.4)' :
                            mapLayer === 'performance' ? 'rgba(249, 115, 22, 0.4)' :
                            'rgba(239, 68, 68, 0.4)'
                          } 0%, transparent 70%)`,
                          transform: 'translate(-50%, -50%)'
                        }}
                      />
                    ))}
                  </div>
                </div>

                {/* Map Controls */}
                <div className="absolute top-4 right-4 flex flex-col gap-2">
                  <Button size="sm" variant="outline" className="bg-white">
                    <ZoomInIcon className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="bg-white">
                    <ZoomOutIcon className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="bg-white">
                    <LayersIcon className="h-4 w-4" />
                  </Button>
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg">
                  <div className="text-sm font-medium mb-2">{mapLayer.charAt(0).toUpperCase() + mapLayer.slice(1)} Intensity</div>
                  <div className="flex items-center gap-2">
                    <div className="flex">
                      {[0.2, 0.4, 0.6, 0.8, 1.0].map((intensity, index) => (
                        <div
                          key={index}
                          className="w-4 h-4"
                          style={{
                            background: mapLayer === 'volume' ? `rgba(59, 130, 246, ${intensity})` :
                                      mapLayer === 'density' ? `rgba(34, 197, 94, ${intensity})` :
                                      mapLayer === 'performance' ? `rgba(249, 115, 22, ${intensity})` :
                                      `rgba(239, 68, 68, ${intensity})`
                          }}
                        />
                      ))}
                    </div>
                    <div className="text-xs text-gray-600">Low → High</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          {/* Regional Metrics */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Regional Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {heatMapData?.regions.slice(0, 3).map((region) => (
                <div
                  key={region.name}
                  className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => onRegionSelect?.(region.name)}
                >
                  <div className="font-medium text-sm mb-2">{region.name}</div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <div className="text-gray-600">Volume</div>
                      <div className="font-medium">{region.metrics.totalVolume.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Performance</div>
                      <div className="font-medium">{region.metrics.avgPerformance}%</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Nodes</div>
                      <div className="font-medium">{region.metrics.nodeCount}</div>
                    </div>
                    <div>
                      <div className="text-gray-600">Avg Cost</div>
                      <div className="font-medium">${region.metrics.avgCost}</div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Top Routes */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">High-Density Routes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {heatMapData?.routes.slice(0, 4).map((route) => (
                <div
                  key={route.id}
                  className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => onRouteAnalyze?.(route.id)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="text-sm font-medium">
                      {route.origin.name} → {route.destination.name}
                    </div>
                    <Badge variant="outline" className={getDensityColor(route.density)}>
                      {route.density}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                    <div>Volume: {route.volume}</div>
                    <div>Transit: {route.avgTransitTime}d</div>
                    <div>Frequency: {route.frequency}x/week</div>
                    <div>Reliability: {route.reliability}%</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <TargetIcon className="h-4 w-4 mr-2" />
                Optimize Network
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <TrendingUpIcon className="h-4 w-4 mr-2" />
                Analyze Trends
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <BarChart3Icon className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <SettingsIcon className="h-4 w-4 mr-2" />
                Configure Alerts
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}