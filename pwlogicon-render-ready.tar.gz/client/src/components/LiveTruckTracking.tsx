import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, Activity, RefreshCw, Clock } from 'lucide-react';

interface TruckLocation {
  truckId: string;
  lat: number;
  lng: number;
  heading: number;
  speed: number;
  timestamp: string;
  carrierId: string;
}

interface LiveTrackingData {
  trucks: TruckLocation[];
  lastUpdated: string;
  totalActive: number;
}

const LiveTruckTracking: React.FC = () => {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [selectedTruck, setSelectedTruck] = useState<string | null>(null);

  // Fetch live truck locations
  const { data: trackingData, isLoading, refetch } = useQuery<LiveTrackingData>({
    queryKey: ['/api/tracking/live'],
    refetchInterval: autoRefresh ? 30000 : false, // Refresh every 30 seconds when enabled
  });

  // Simulate truck updates for development
  const simulateTruckUpdate = async () => {
    const mockTrucks = [
      { id: 'TRUCK-001', basePos: [41.8781, -87.6298] }, // Chicago
      { id: 'TRUCK-002', basePos: [32.7767, -96.7970] }, // Dallas
      { id: 'TRUCK-003', basePos: [34.0522, -118.2437] }, // Los Angeles
    ];

    for (const truck of mockTrucks) {
      const [baseLat, baseLng] = truck.basePos;
      await fetch('/api/tracking/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          truckId: truck.id,
          lat: baseLat + (Math.random() - 0.5) * 0.1, // Small random offset
          lng: baseLng + (Math.random() - 0.5) * 0.1,
          heading: Math.random() * 360,
          speed: Math.random() * 70 + 20, // 20-90 mph
          carrierId: 'PA-LOGISTICS-001'
        })
      });
    }
    
    refetch();
  };

  // Simulate FourKites webhook events
  const simulateFourKitesEvents = async () => {
    try {
      const response = await fetch('/api/webhook/fourkites/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('FourKites simulation result:', result);
        refetch(); // Refresh tracking data
      }
    } catch (error) {
      console.error('Failed to simulate FourKites events:', error);
    }
  };

  // Simulate Project44 data
  const simulateProject44Data = async () => {
    try {
      const response = await fetch('/api/shipment/project44/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('Project44 simulation result:', result);
        refetch(); // Refresh tracking data
      }
    } catch (error) {
      console.error('Failed to simulate Project44 data:', error);
    }
  };

  const getSpeedColor = (speed: number) => {
    if (speed === 0) return 'text-red-600';
    if (speed < 30) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getTimeSinceUpdate = (timestamp: string) => {
    const now = new Date();
    const updateTime = new Date(timestamp);
    const diffMinutes = Math.floor((now.getTime() - updateTime.getTime()) / (1000 * 60));
    
    if (diffMinutes < 1) return 'Just now';
    if (diffMinutes === 1) return '1 minute ago';
    return `${diffMinutes} minutes ago`;
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6 text-blue-600" />
              <CardTitle>Live Fleet Tracking</CardTitle>
              <Badge variant="outline" className="ml-2">
                {trackingData?.totalActive || 0} Active
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? "bg-green-50 border-green-200" : ""}
              >
                <Activity className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-pulse' : ''}`} />
                Auto Refresh
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              
              <Button
                size="sm"
                onClick={simulateTruckUpdate}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <MapPin className="h-4 w-4 mr-2" />
                Simulate GPS
              </Button>
              
              <Button
                size="sm"
                onClick={simulateFourKitesEvents}
                className="bg-green-600 hover:bg-green-700"
              >
                <Activity className="h-4 w-4 mr-2" />
                FourKites Events
              </Button>
              
              <Button
                size="sm"
                onClick={simulateProject44Data}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Truck className="h-4 w-4 mr-2" />
                Project44 Data
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Truck List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          <div className="col-span-full text-center py-8">
            <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">Loading truck locations...</p>
          </div>
        ) : trackingData?.trucks.length === 0 ? (
          <div className="col-span-full text-center py-8">
            <Truck className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Active Trucks</h3>
            <p className="text-gray-600 mb-4">No trucks have reported their location in the last 30 minutes</p>
            <Button onClick={simulateTruckUpdate}>
              <MapPin className="h-4 w-4 mr-2" />
              Add Sample Trucks
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Truck Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {trackingData?.trucks.map((truck) => (
                <Card 
                  key={truck.truckId} 
                  className={`cursor-pointer transition-all ${
                    selectedTruck === truck.truckId 
                      ? 'ring-2 ring-blue-500 shadow-md' 
                      : 'hover:shadow-md'
                  }`}
                  onClick={() => setSelectedTruck(
                    selectedTruck === truck.truckId ? null : truck.truckId
                  )}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Truck className="h-5 w-5 text-blue-600" />
                        <span className="font-semibold">{truck.truckId}</span>
                      </div>
                      <Badge 
                        variant={truck.speed > 0 ? "default" : "secondary"}
                        className={getSpeedColor(truck.speed)}
                      >
                        {truck.speed > 0 ? 'Moving' : 'Stopped'}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Location:</span>
                        <span className="font-mono text-xs">
                          {truck.lat.toFixed(4)}, {truck.lng.toFixed(4)}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Speed:</span>
                        <span className={`font-medium ${getSpeedColor(truck.speed)}`}>
                          {truck.speed.toFixed(1)} mph
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Heading:</span>
                        <span className="font-medium">{truck.heading.toFixed(0)}°</span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Carrier:</span>
                        <span className="text-xs">{truck.carrierId}</span>
                      </div>
                      
                      {truck.source && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Source:</span>
                          <Badge variant="outline" className="text-xs">
                            {truck.source}
                          </Badge>
                        </div>
                      )}
                      
                      {truck.status && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Status:</span>
                          <span className="text-xs font-medium">{truck.status}</span>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between pt-2 border-t">
                        <Clock className="h-3 w-3 text-gray-400" />
                        <span className="text-xs text-gray-500">
                          {getTimeSinceUpdate(truck.timestamp)}
                        </span>
                      </div>
                    </div>
                    
                    {selectedTruck === truck.truckId && (
                      <div className="mt-3 pt-3 border-t">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="w-full"
                          onClick={(e) => {
                            e.stopPropagation();
                            window.open(
                              `https://maps.google.com/?q=${truck.lat},${truck.lng}`,
                              '_blank'
                            );
                          }}
                        >
                          <MapPin className="h-4 w-4 mr-2" />
                          View on Map
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Compact Table View */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Live Carrier Tracking Table
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-medium">Truck</th>
                        <th className="text-left p-3 font-medium">Location</th>
                        <th className="text-left p-3 font-medium">Speed</th>
                        <th className="text-left p-3 font-medium">Last Ping</th>
                        <th className="text-left p-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {trackingData?.trucks.map((truck) => (
                        <tr key={`table-${truck.truckId}`} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div>
                              <strong className="text-sm">{truck.truckId}</strong>
                              <br />
                              <span className="text-xs text-gray-500">({truck.carrierId})</span>
                            </div>
                          </td>
                          <td className="p-3">
                            <span className="font-mono text-xs">
                              {truck.lat.toFixed(4)}, {truck.lng.toFixed(4)}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className={`font-medium ${getSpeedColor(truck.speed)}`}>
                              {truck.speed} mph
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="text-sm">
                              {new Date(truck.timestamp).toLocaleTimeString()}
                            </span>
                          </td>
                          <td className="p-3">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(
                                `https://maps.google.com/?q=${truck.lat},${truck.lng}`,
                                '_blank'
                              )}
                            >
                              <MapPin className="h-3 w-3 mr-1" />
                              Map
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="mt-4 text-center">
                  <small className="text-gray-500">
                    Real-time tracking from multiple sources • GPS Simulation, FourKites, Project44 • Last update: {new Date().toLocaleTimeString()}
                  </small>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Summary Footer */}
      {trackingData && trackingData.trucks.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span>
                  <strong>{trackingData.totalActive}</strong> trucks active
                </span>
                <span>
                  <strong>{trackingData.trucks.filter(t => t.speed > 0).length}</strong> moving
                </span>
                <span>
                  <strong>{trackingData.trucks.filter(t => t.speed === 0).length}</strong> stopped
                </span>
              </div>
              
              <div className="text-gray-500">
                Last updated: {new Date(trackingData.lastUpdated).toLocaleTimeString()}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default LiveTruckTracking;