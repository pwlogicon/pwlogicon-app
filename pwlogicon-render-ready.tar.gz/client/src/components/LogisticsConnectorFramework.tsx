import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Database, 
  Truck, 
  Package, 
  Settings, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw,
  Plus,
  Zap,
  Activity,
  Clock
} from "lucide-react";

interface Connector {
  id: string;
  type: 'WMS' | 'TMS' | 'ERP';
  name: string;
  status: 'connected' | 'disconnected' | 'error' | 'syncing';
  lastSync: string;
  dataCount: number;
  errorMessage?: string;
  config: {
    endpoint: string;
    apiKey: string;
    version: string;
  };
}

interface ConnectorFrameworkProps {
  onRegisterConnector?: (type: string, config: any) => void;
  onSynchronizeData?: () => void;
  onConnectorAction?: (connectorId: string, action: string) => void;
}

export default function LogisticsConnectorFramework({ 
  onRegisterConnector, 
  onSynchronizeData, 
  onConnectorAction 
}: ConnectorFrameworkProps) {
  const [connectors, setConnectors] = useState<Connector[]>([
    {
      id: 'wms-001',
      type: 'WMS',
      name: 'Manhattan SCALE WMS',
      status: 'connected',
      lastSync: '2024-08-02T00:15:00Z',
      dataCount: 1247,
      config: {
        endpoint: 'https://api.manhattan.com/wms/v2',
        apiKey: '***KEY***',
        version: 'v2.1'
      }
    },
    {
      id: 'tms-001',
      type: 'TMS',
      name: 'Oracle TMS Cloud',
      status: 'syncing',
      lastSync: '2024-08-02T00:12:00Z',
      dataCount: 892,
      config: {
        endpoint: 'https://api.oracle.com/tms/v3',
        apiKey: '***KEY***',
        version: 'v3.0'
      }
    },
    {
      id: 'erp-001',
      type: 'ERP',
      name: 'SAP S/4HANA',
      status: 'error',
      lastSync: '2024-08-01T23:45:00Z',
      dataCount: 0,
      errorMessage: 'Authentication failed: Invalid credentials',
      config: {
        endpoint: 'https://api.sap.com/s4hana/v1',
        apiKey: '***KEY***',
        version: 'v1.2'
      }
    }
  ]);

  const [isSyncing, setIsSyncing] = useState(false);

  const getConnectorIcon = (type: string) => {
    switch (type) {
      case 'WMS': return <Package className="h-5 w-5 text-green-600" />;
      case 'TMS': return <Truck className="h-5 w-5 text-blue-600" />;
      case 'ERP': return <Database className="h-5 w-5 text-purple-600" />;
      default: return <Settings className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge variant="default" className="bg-green-100 text-green-800">Connected</Badge>;
      case 'syncing':
        return <Badge variant="default" className="bg-blue-100 text-blue-800">Syncing</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      case 'disconnected':
        return <Badge variant="secondary">Disconnected</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const formatLastSync = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  const handleSynchronizeAll = async () => {
    setIsSyncing(true);
    try {
      if (onSynchronizeData) {
        await onSynchronizeData();
      }
      // Simulate sync process
      setTimeout(() => {
        setIsSyncing(false);
        // Update last sync times
        setConnectors(prev => prev.map(conn => ({
          ...conn,
          lastSync: new Date().toISOString(),
          status: conn.status === 'error' ? 'error' : 'connected'
        })));
      }, 3000);
    } catch (error) {
      setIsSyncing(false);
    }
  };

  const connectedCount = connectors.filter(c => c.status === 'connected').length;
  const totalCount = connectors.length;
  const healthPercentage = Math.round((connectedCount / totalCount) * 100);

  return (
    <div className="space-y-6">
      {/* Framework Overview */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Logistics Connector Framework
          </CardTitle>
          <CardDescription>
            Unified integration platform for WMS, TMS, and ERP systems
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{totalCount}</div>
              <div className="text-sm text-gray-600">Total Connectors</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{connectedCount}</div>
              <div className="text-sm text-gray-600">Connected</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{healthPercentage}%</div>
              <div className="text-sm text-gray-600">System Health</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {connectors.reduce((sum, c) => sum + c.dataCount, 0)}
              </div>
              <div className="text-sm text-gray-600">Records Synced</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Health */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                System Health
              </CardTitle>
              <CardDescription>Overall connector framework status</CardDescription>
            </div>
            <Button 
              onClick={handleSynchronizeAll}
              disabled={isSyncing}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
              Sync All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>System Health</span>
                <span>{healthPercentage}%</span>
              </div>
              <Progress value={healthPercentage} className="h-2" />
            </div>
            
            {connectors.filter(c => c.status === 'error').length > 0 && (
              <Alert className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {connectors.filter(c => c.status === 'error').length} connector(s) require attention
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Connector Management */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="wms">WMS</TabsTrigger>
          <TabsTrigger value="tms">TMS</TabsTrigger>
          <TabsTrigger value="erp">ERP</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4">
            {connectors.map((connector) => (
              <Card key={connector.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getConnectorIcon(connector.type)}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{connector.name}</span>
                          {getStatusBadge(connector.status)}
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Last sync: {formatLastSync(connector.lastSync)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <div className="text-sm font-medium">{connector.dataCount.toLocaleString()}</div>
                        <div className="text-xs text-gray-500">records</div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onConnectorAction?.(connector.id, 'configure')}
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {connector.errorMessage && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-sm text-red-600">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" />
                        <span className="font-medium">Error:</span>
                      </div>
                      <p className="mt-1">{connector.errorMessage}</p>
                    </div>
                  )}
                  
                  {connector.status === 'syncing' && (
                    <div className="mt-3">
                      <div className="flex justify-between text-sm mb-2">
                        <span>Syncing data...</span>
                        <span>75%</span>
                      </div>
                      <Progress value={75} className="h-1" />
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {['wms', 'tms', 'erp'].map((type) => (
          <TabsContent key={type} value={type} className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">{type.toUpperCase()} Connectors</h3>
                <p className="text-gray-600">
                  Manage {type.toUpperCase()} system integrations and data synchronization
                </p>
              </div>
              <Button 
                onClick={() => onRegisterConnector?.(type.toUpperCase(), {})}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                Add {type.toUpperCase()} Connector
              </Button>
            </div>
            
            <div className="grid gap-4">
              {connectors
                .filter(c => c.type.toLowerCase() === type)
                .map((connector) => (
                  <Card key={connector.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          {getConnectorIcon(connector.type)}
                          <div>
                            <h4 className="font-medium">{connector.name}</h4>
                            <p className="text-sm text-gray-500">{connector.config.endpoint}</p>
                          </div>
                        </div>
                        {getStatusBadge(connector.status)}
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Version</span>
                          <div className="font-medium">{connector.config.version}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Records</span>
                          <div className="font-medium">{connector.dataCount.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Last Sync</span>
                          <div className="font-medium">{formatLastSync(connector.lastSync)}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Actions</span>
                          <div className="flex gap-1 mt-1">
                            <Button variant="outline" size="sm">Sync</Button>
                            <Button variant="outline" size="sm">Test</Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}