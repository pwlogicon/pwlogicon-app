import React, { useEffect, useState, useRef } from 'react';

interface BootstrapKPIMasterDashboardProps {
  sid?: string;
}

const BootstrapKPIMasterDashboard: React.FC<BootstrapKPIMasterDashboardProps> = ({ sid }) => {
  const [kpis, setKpis] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<any>(null);

  const fetchKPIs = async () => {
    try {
      setLoading(true);
      const url = sid ? `/api/kpis?sid=${sid}` : '/api/kpis';
      const response = await fetch(url);
      const data = await response.json();
      setKpis(data.kpis || []);
      setLastUpdated(new Date().toLocaleString());
    } catch (error) {
      console.error('Failed to fetch KPIs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKPIs();
  }, [sid]);

  useEffect(() => {
    if (kpis.length > 0 && chartRef.current) {
      // Dynamically import Chart.js
      import('chart.js/auto').then((ChartModule) => {
        const Chart = ChartModule.default;
        
        // Destroy existing chart
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy();
        }

        const ctx = chartRef.current?.getContext('2d');
        if (!ctx) return;

        chartInstanceRef.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: kpis.map(k => k.name.replace(' %', '').replace(' ($)', '')),
            datasets: [
              {
                label: 'Current',
                data: kpis.map(k => k.current),
                backgroundColor: 'rgba(255, 159, 64, 0.7)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 2
              },
              {
                label: 'Target',
                data: kpis.map(k => k.target),
                backgroundColor: 'rgba(255, 192, 0, 0.7)',
                borderColor: 'rgba(255, 192, 0, 1)',
                borderWidth: 2
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: true,
                text: 'PWLoGiCon Master Dashboard – Current vs. Target KPIs',
                font: {
                  size: 14,
                  weight: 'bold'
                }
              },
              legend: {
                position: 'top',
                labels: {
                  usePointStyle: true,
                  padding: 15
                }
              },
              tooltip: {
                callbacks: {
                  label: (context: any) => {
                    const kpi = kpis[context.dataIndex];
                    const value = context.parsed.y;
                    const suffix = kpi.name.includes('%') ? '%' : 
                                 kpi.name.includes('$') ? '' : 
                                 kpi.name.includes('Hours') ? 'h' : '';
                    return `${context.dataset.label}: ${value.toFixed(1)}${suffix}`;
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(0, 0, 0, 0.1)'
                },
                ticks: {
                  callback: function(value: any) {
                    return value.toFixed(1);
                  }
                }
              },
              x: {
                grid: {
                  display: false
                },
                ticks: {
                  maxRotation: 45,
                  minRotation: 0,
                  font: {
                    size: 10
                  }
                }
              }
            }
          }
        });
      }).catch(error => {
        console.error('Failed to load Chart.js:', error);
      });
    }

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [kpis]);

  const getOverallPerformance = () => {
    if (kpis.length === 0) return { score: 0, status: 'No Data', color: 'secondary' };
    
    const achievedTargets = kpis.filter(kpi => kpi.current >= kpi.target).length;
    const score = Math.round((achievedTargets / kpis.length) * 100);
    
    let status = 'Needs Improvement';
    let color = 'danger';
    if (score >= 80) { status = 'Excellent'; color = 'success'; }
    else if (score >= 60) { status = 'Good'; color = 'info'; }
    else if (score >= 40) { status = 'Fair'; color = 'warning'; }
    
    return { score, status, color };
  };

  const performance = getOverallPerformance();

  if (loading) {
    return (
      <div className="card h-100">
        <div className="card-body d-flex align-items-center justify-content-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card h-100">
      <div className="card-header bg-primary text-white">
        <div className="d-flex justify-content-between align-items-center">
          <h5 className="card-title mb-0">
            <i className="bi bi-graph-up me-2"></i>
            PWLoGiCon Master Dashboard
          </h5>
          <span className={`badge bg-${performance.color}`}>
            {performance.score}% - {performance.status}
          </span>
        </div>
      </div>
      
      <div className="card-body p-3">
        {/* Performance Overview */}
        <div className="row g-2 mb-3">
          <div className="col-6">
            <div className="card bg-light border-0">
              <div className="card-body p-2 text-center">
                <h6 className="card-title mb-1" style={{ fontSize: '0.875rem' }}>Total KPIs</h6>
                <h4 className="text-primary mb-0">{kpis.length}</h4>
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="card bg-light border-0">
              <div className="card-body p-2 text-center">
                <h6 className="card-title mb-1" style={{ fontSize: '0.875rem' }}>On Target</h6>
                <h4 className="text-success mb-0">
                  {kpis.filter(kpi => kpi.current >= kpi.target).length}
                </h4>
              </div>
            </div>
          </div>
        </div>

        {/* Chart Container */}
        <div className="position-relative mb-3" style={{ height: '250px' }}>
          <canvas ref={chartRef} className="w-100 h-100"></canvas>
        </div>

        {/* KPI Summary */}
        <div className="row g-1">
          {kpis.slice(0, 4).map((kpi, index) => (
            <div key={index} className="col-6">
              <div className="card border-0 bg-light">
                <div className="card-body p-2">
                  <h6 className="card-title mb-1" style={{ fontSize: '0.75rem' }}>
                    {kpi.name}
                  </h6>
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span className="fw-bold" style={{ fontSize: '0.875rem' }}>
                      {kpi.name.includes('$') ? '$' : ''}{kpi.current.toFixed(1)}{kpi.name.includes('%') ? '%' : ''}
                    </span>
                    <span className="text-muted" style={{ fontSize: '0.75rem' }}>
                      Target: {kpi.target.toFixed(1)}{kpi.name.includes('%') ? '%' : ''}
                    </span>
                  </div>
                  <div className="progress" style={{ height: '4px' }}>
                    <div 
                      className={`progress-bar ${kpi.current >= kpi.target ? 'bg-success' : 'bg-danger'}`}
                      style={{ width: `${Math.min((kpi.current / kpi.target) * 100, 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-3">
          <small className="text-muted">
            Metrics: <span style={{ color: '#FF9F40', fontWeight: 'bold' }}>Current</span> and{' '}
            <span style={{ color: '#FFC000', fontWeight: 'bold' }}>Target</span>
          </small>
          <br />
          <small className="text-muted">Last updated: {lastUpdated}</small>
        </div>
      </div>
    </div>
  );
};

export default BootstrapKPIMasterDashboard;