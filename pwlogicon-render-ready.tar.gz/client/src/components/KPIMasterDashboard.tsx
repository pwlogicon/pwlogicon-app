import React, { useEffect, useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, TrendingUp, Target, RefreshCw, Download } from 'lucide-react';
// Chart.js will be loaded dynamically to avoid SSR issues

interface KPIMasterDashboardProps {
  sid?: string;
}

const KPIMasterDashboard: React.FC<KPIMasterDashboardProps> = ({ sid }) => {
  const [kpis, setKpis] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartType, setChartType] = useState<'bar' | 'line' | 'radar'>('bar');
  const [period, setPeriod] = useState('current');
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<any>(null);

  const fetchKPIs = async () => {
    try {
      setLoading(true);
      const url = sid ? `/api/kpis?sid=${sid}` : '/api/kpis';
      const response = await fetch(url);
      const data = await response.json();
      setKpis(data.kpis || []);
    } catch (error) {
      console.error('Failed to fetch KPIs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKPIs();
  }, [sid]);

  useEffect(() => {
    if (kpis.length > 0 && chartRef.current) {
      // Destroy existing chart
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }

      // Dynamically import Chart.js to avoid SSR issues
      import('chart.js/auto').then((ChartModule) => {
        const Chart = ChartModule.default;
        
        const ctx = chartRef.current?.getContext('2d');
        if (!ctx) return;

        const chartConfig = {
          type: chartType,
          data: {
            labels: kpis.map(k => k.name.replace(' %', '').replace(' ($)', '')),
            datasets: [
              {
                label: 'Current',
                data: kpis.map(k => k.current),
                backgroundColor: 'rgba(255, 159, 64, 0.7)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 2,
                tension: 0.4
              },
              {
                label: 'Target',
                data: kpis.map(k => k.target),
                backgroundColor: 'rgba(255, 192, 0, 0.7)',
                borderColor: 'rgba(255, 192, 0, 1)',
                borderWidth: 2,
                tension: 0.4
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: true,
                text: 'PWLoGiCon Master Dashboard – Current vs. Target KPIs',
                font: {
                  size: 16,
                  weight: 'bold'
                }
              },
              legend: {
                position: 'top' as const,
                labels: {
                  usePointStyle: true,
                  padding: 20
                }
              },
              tooltip: {
                callbacks: {
                  label: (context: any) => {
                    const kpi = kpis[context.dataIndex];
                    const value = context.parsed.y;
                    const suffix = kpi.name.includes('%') ? '%' : 
                                 kpi.name.includes('$') ? '' : 
                                 kpi.name.includes('Hours') ? 'h' : '';
                    return `${context.dataset.label}: ${value.toFixed(1)}${suffix}`;
                  }
                }
              }
            },
            scales: chartType !== 'radar' ? {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(0, 0, 0, 0.1)'
                },
                ticks: {
                  callback: function(value: any) {
                    return value.toFixed(1);
                  }
                }
              },
              x: {
                grid: {
                  display: false
                },
                ticks: {
                  maxRotation: 45,
                  minRotation: 0
                }
              }
            } : {
              r: {
                beginAtZero: true,
                pointLabels: {
                  font: {
                    size: 12
                  }
                }
              }
            }
          }
        };

        chartInstanceRef.current = new Chart(ctx, chartConfig as any);
      }).catch(error => {
        console.error('Failed to load Chart.js:', error);
      });
    }

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [kpis, chartType]);

  const getOverallPerformance = () => {
    if (kpis.length === 0) return { score: 0, status: 'No Data' };
    
    const achievedTargets = kpis.filter(kpi => kpi.current >= kpi.target).length;
    const score = Math.round((achievedTargets / kpis.length) * 100);
    
    let status = 'Needs Improvement';
    if (score >= 80) status = 'Excellent';
    else if (score >= 60) status = 'Good';
    else if (score >= 40) status = 'Fair';
    
    return { score, status };
  };

  const downloadChart = () => {
    if (chartInstanceRef.current) {
      const url = chartInstanceRef.current.toBase64Image();
      const link = document.createElement('a');
      link.download = `kpi-dashboard-${new Date().toISOString().split('T')[0]}.png`;
      link.href = url;
      link.click();
    }
  };

  const performance = getOverallPerformance();

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="flex items-center justify-center h-64">
          <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="w-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-6 w-6" />
              PWLoGiCon Master Dashboard
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant={performance.score >= 80 ? "default" : performance.score >= 60 ? "secondary" : "destructive"}>
                {performance.score}% - {performance.status}
              </Badge>
              <Button onClick={fetchKPIs} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Select value={chartType} onValueChange={(value: 'bar' | 'line' | 'radar') => setChartType(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bar">Bar Chart</SelectItem>
                  <SelectItem value="line">Line Chart</SelectItem>
                  <SelectItem value="radar">Radar Chart</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Current</SelectItem>
                  <SelectItem value="7d">7 Days</SelectItem>
                  <SelectItem value="30d">30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button onClick={downloadChart} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Chart
            </Button>
          </div>

          <div className="relative h-80 w-full">
            <canvas 
              ref={chartRef}
              id="kpi-master-chart"
              className="w-full h-full"
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{kpis.length}</div>
              <div className="text-sm text-gray-600">Total KPIs</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {kpis.filter(kpi => kpi.current >= kpi.target).length}
              </div>
              <div className="text-sm text-gray-600">On Target</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                {kpis.filter(kpi => kpi.current < kpi.target).length}
              </div>
              <div className="text-sm text-gray-600">Below Target</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{performance.score}%</div>
              <div className="text-sm text-gray-600">Success Rate</div>
            </div>
          </div>

          <div className="text-center text-sm text-gray-600 mt-4">
            Metrics: <span style={{ color: '#FF9F40', fontWeight: 'bold' }}>Current Performance</span> vs{' '}
            <span style={{ color: '#FFC000', fontWeight: 'bold' }}>Target Goals</span>
          </div>
        </CardContent>
      </Card>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpis.map((kpi, index) => (
          <Card key={index} className="relative">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">{kpi.name}</CardTitle>
                <Badge variant={kpi.current >= kpi.target ? "default" : "destructive"}>
                  {kpi.trend === 'up' ? <TrendingUp className="h-3 w-3" /> : 
                   kpi.trend === 'down' ? <TrendingUp className="h-3 w-3 rotate-180" /> : 
                   <Target className="h-3 w-3" />}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">
                    {kpi.name.includes('$') ? '$' : ''}{kpi.current.toFixed(1)}{kpi.name.includes('%') ? '%' : ''}
                  </span>
                  <span className="text-sm text-gray-600">
                    Target: {kpi.target.toFixed(1)}{kpi.name.includes('%') ? '%' : ''}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${kpi.current >= kpi.target ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{ width: `${Math.min((kpi.current / kpi.target) * 100, 100)}%` }}
                  />
                </div>
                <p className="text-xs text-gray-600">{kpi.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default KPIMasterDashboard;