import React from 'react';
import { createRoot } from 'react-dom/client';
import PredictiveETA from './PredictiveETA';

// Mount PredictiveETA component to DOM element
export function mountPredictiveETA(elementId: string, opportunityId: string, sid?: string) {
  const container = document.getElementById(elementId);
  if (container) {
    const root = createRoot(container);
    root.render(<PredictiveETA opportunityId={opportunityId} sid={sid} />);
    return root;
  }
  return null;
}

// Global function for EJS templates
if (typeof window !== 'undefined') {
  (window as any).mountPredictiveETA = mountPredictiveETA;
}

export default PredictiveETA;