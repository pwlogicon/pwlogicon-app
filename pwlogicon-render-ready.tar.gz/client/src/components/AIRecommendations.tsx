import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Brain, TrendingUp, Target, AlertTriangle } from "lucide-react";

interface AIRecommendationsProps {
  opportunityId: string;
}

export default function AIRecommendations({ opportunityId }: AIRecommendationsProps) {
  const [showDetails, setShowDetails] = useState(false);

  const { data: recommendations, isLoading, error } = useQuery({
    queryKey: [`/api/ai/recommendations/${opportunityId}`],
    enabled: !!opportunityId
  });

  const { data: marketTrends } = useQuery({
    queryKey: ['/api/ai/market-trends']
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            AI Partnership Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span className="ml-2">Analyzing partnership opportunities...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !recommendations) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            AI Partnership Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            Unable to generate AI recommendations at this time.
          </div>
        </CardContent>
      </Card>
    );
  }

  const { context, recommendations: aiRecs } = recommendations;

  return (
    <div className="space-y-6">
      {/* Main AI Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            AI Partnership Recommendations
          </CardTitle>
          <p className="text-sm text-gray-600">
            Intelligent analysis of {context.matchCount} potential partners for your {context.opportunity.type} opportunity
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {aiRecs.recommendedPartners?.map((partner: any, index: number) => (
              <div key={partner.partnerId} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold">{partner.companyName}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={partner.confidenceScore > 80 ? "default" : "secondary"}>
                        {partner.confidenceScore}% Match
                      </Badge>
                      <Badge variant="outline">{partner.opportunityFit}</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">
                      #{index + 1}
                    </div>
                    <div className="text-xs text-gray-500">Recommended</div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                      <Target className="w-4 h-4" />
                      Strategic Value
                    </h4>
                    <p className="text-sm text-gray-600">{partner.strategicValue}</p>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                      <AlertTriangle className="w-4 h-4" />
                      Risk Factors
                    </h4>
                    <ul className="text-sm text-gray-600">
                      {partner.riskFactors?.map((risk: string, i: number) => (
                        <li key={i}>• {risk}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t">
                  <h4 className="font-medium text-sm mb-2">AI Analysis</h4>
                  <p className="text-sm text-gray-700">{partner.reasoning}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Market Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Market Intelligence
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <h4 className="font-medium mb-2">Lane Analysis</h4>
              <p className="text-sm text-gray-600">{aiRecs.marketInsights?.laneAnalysis}</p>
            </div>
            <div>
              <h4 className="font-medium mb-2">Timing Strategy</h4>
              <p className="text-sm text-gray-600">{aiRecs.marketInsights?.timingRecommendation}</p>
            </div>
            <div>
              <h4 className="font-medium mb-2">Pricing Strategy</h4>
              <p className="text-sm text-gray-600">{aiRecs.marketInsights?.pricingStrategy}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Negotiation Strategy */}
      <Card>
        <CardHeader>
          <CardTitle>Negotiation Strategy</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Success Probability:</span>
            <Badge variant={aiRecs.negotiationStrategy?.successProbability > 75 ? "default" : "secondary"}>
              {aiRecs.negotiationStrategy?.successProbability}%
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Key Negotiation Points</h4>
              <ul className="space-y-2">
                {aiRecs.negotiationStrategy?.keyPoints?.map((point: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                    <span className="text-sm">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Leverage Factors</h4>
              <ul className="space-y-2">
                {aiRecs.negotiationStrategy?.leverageFactors?.map((factor: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></span>
                    <span className="text-sm">{factor}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Market Trends */}
      {marketTrends?.trends && (
        <Card>
          <CardHeader>
            <CardTitle>Market Trends & Insights</CardTitle>
            <p className="text-sm text-gray-600">
              Based on {marketTrends.dataPoints} data points
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Market Insights</h4>
                <ul className="space-y-1">
                  {marketTrends.trends.insights?.map((insight: string, i: number) => (
                    <li key={i} className="text-sm text-gray-700">• {insight}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Strategic Recommendations</h4>
                <ul className="space-y-1">
                  {marketTrends.trends.recommendations?.map((rec: string, i: number) => (
                    <li key={i} className="text-sm text-gray-700">• {rec}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Market Trends</h4>
                <ul className="space-y-1">
                  {marketTrends.trends.marketTrends?.map((trend: string, i: number) => (
                    <li key={i} className="text-sm text-gray-700">• {trend}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="text-xs text-gray-500 text-center">
        Generated on {new Date(recommendations.generatedAt).toLocaleString()}
      </div>
    </div>
  );
}