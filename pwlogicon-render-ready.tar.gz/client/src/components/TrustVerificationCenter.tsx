import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Shield, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Upload, 
  AlertTriangle,
  Building,
  CreditCard,
  Users,
  Scale,
  Eye,
  Download,
  RefreshCw
} from "lucide-react";

interface KycDocument {
  id: string;
  userId: string;
  documentType: string;
  documentNumber?: string;
  documentUrl?: string;
  verificationStatus: "pending" | "verified" | "rejected" | "expired";
  verifiedBy?: string;
  verifiedAt?: string;
  expiryDate?: string;
  rejectionReason?: string;
  metadata?: any;
  createdAt: string;
  updatedAt: string;
}

interface InsuranceCertificate {
  id: string;
  userId: string;
  insuranceType: string;
  provider: string;
  policyNumber: string;
  coverageAmount?: number;
  deductible?: number;
  effectiveDate: string;
  expiryDate: string;
  verificationStatus: "pending" | "verified" | "rejected" | "expired";
  certificateUrl?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  additionalInsured?: string;
  specialConditions?: string;
  createdAt: string;
  updatedAt: string;
}

interface Dispute {
  id: string;
  partnershipId?: string;
  shipmentId?: string;
  reportedBy: string;
  reportedAgainst: string;
  title: string;
  description: string;
  category?: string;
  status: "open" | "investigating" | "resolved" | "escalated" | "closed";
  priority: string;
  assignedTo?: string;
  resolutionNotes?: string;
  resolutionAmount?: number;
  resolvedAt?: string;
  evidence?: any;
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

const documentTypes = [
  { value: "business_license", label: "Business License" },
  { value: "insurance_certificate", label: "Insurance Certificate" },
  { value: "w9_form", label: "W-9 Tax Form" },
  { value: "dot_authority", label: "DOT Authority" },
  { value: "mc_authority", label: "MC Authority" },
  { value: "safety_rating", label: "Safety Rating" }
];

const insuranceTypes = [
  { value: "general_liability", label: "General Liability" },
  { value: "cargo", label: "Cargo Insurance" },
  { value: "auto", label: "Auto Insurance" },
  { value: "workers_comp", label: "Workers' Compensation" },
  { value: "cyber", label: "Cyber Liability" }
];

export default function TrustVerificationCenter() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("documents");
  const [uploadingDocument, setUploadingDocument] = useState(false);

  // Fetch KYC documents
  const { data: kycDocuments, isLoading: documentsLoading } = useQuery({
    queryKey: ["/api/kyc-documents"],
    enabled: !!user,
  });

  // Fetch insurance certificates
  const { data: insuranceCertificates, isLoading: insuranceLoading } = useQuery({
    queryKey: ["/api/insurance-certificates"],
    enabled: !!user,
  });

  // Fetch disputes
  const { data: disputes, isLoading: disputesLoading } = useQuery({
    queryKey: ["/api/disputes"],
    enabled: !!user,
  });

  // Upload document mutation
  const uploadDocumentMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("/api/kyc-documents", {
        method: "POST",
        body: data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kyc-documents"] });
      toast({
        title: "Document Uploaded",
        description: "Your document has been submitted for verification",
      });
      setUploadingDocument(false);
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload document",
        variant: "destructive",
      });
      setUploadingDocument(false);
    },
  });

  // Add insurance certificate mutation
  const addInsuranceMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("/api/insurance-certificates", {
        method: "POST",
        body: data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/insurance-certificates"] });
      toast({
        title: "Insurance Added",
        description: "Insurance certificate has been submitted for verification",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Add Insurance",
        description: error.message || "Failed to add insurance certificate",
        variant: "destructive",
      });
    },
  });

  // File dispute mutation
  const fileDisputeMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("/api/disputes", {
        method: "POST",
        body: data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/disputes"] });
      toast({
        title: "Dispute Filed",
        description: "Your dispute has been submitted and will be reviewed",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to File Dispute",
        description: error.message || "Failed to file dispute",
        variant: "destructive",
      });
    },
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-600" />;
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case "expired":
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "expired":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const calculateVerificationProgress = () => {
    if (!Array.isArray(kycDocuments)) return 0;
    const totalRequired = 4; // business_license, insurance_certificate, w9_form, dot_authority
    const verified = kycDocuments.filter(
      (doc: KycDocument) => doc.verificationStatus === "verified"
    ).length;
    return Math.round((verified / totalRequired) * 100);
  };

  const formatCurrency = (amount?: number) => {
    if (!amount) return "$0";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD"
    }).format(amount);
  };

  if (documentsLoading || insuranceLoading || disputesLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Trust Score Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Trust & Verification Center
              </CardTitle>
              <CardDescription>
                Manage your identity verification, insurance, and dispute resolution
              </CardDescription>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">
                {calculateVerificationProgress()}%
              </div>
              <div className="text-sm text-gray-600">Verified</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Verification Progress</span>
                <span>{calculateVerificationProgress()}% Complete</span>
              </div>
              <Progress value={calculateVerificationProgress()} className="h-2" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-blue-500" />
                <span className="text-sm">
                  {Array.isArray(kycDocuments) ? kycDocuments.length : 0} Documents
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-green-500" />
                <span className="text-sm">
                  {Array.isArray(insuranceCertificates) ? insuranceCertificates.length : 0} Insurance
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-purple-500" />
                <span className="text-sm">
                  {Array.isArray(disputes) ? disputes.length : 0} Disputes
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span className="text-sm">Verified User</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="documents" className="gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="insurance" className="gap-2">
            <Shield className="h-4 w-4" />
            Insurance
          </TabsTrigger>
          <TabsTrigger value="disputes" className="gap-2">
            <Scale className="h-4 w-4" />
            Disputes
          </TabsTrigger>
          <TabsTrigger value="performance" className="gap-2">
            <Users className="h-4 w-4" />
            Performance
          </TabsTrigger>
        </TabsList>

        {/* KYC Documents Tab */}
        <TabsContent value="documents" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Document List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Identity Documents</CardTitle>
                <CardDescription>
                  Upload and manage your business verification documents
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Array.isArray(kycDocuments) && kycDocuments.length > 0 ? (
                    kycDocuments.map((doc: KycDocument) => (
                      <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(doc.verificationStatus)}
                          <div>
                            <div className="font-medium">
                              {documentTypes.find(t => t.value === doc.documentType)?.label || doc.documentType}
                            </div>
                            <div className="text-sm text-gray-600">
                              {doc.documentNumber && `#${doc.documentNumber}`}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(doc.verificationStatus)}>
                            {doc.verificationStatus}
                          </Badge>
                          {doc.documentUrl && (
                            <Button variant="outline" size="sm">
                              <Eye className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      No documents uploaded yet
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Upload Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Upload Document</CardTitle>
                <CardDescription>
                  Add a new verification document
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.target as HTMLFormElement);
                    const data = {
                      documentType: formData.get("documentType"),
                      documentNumber: formData.get("documentNumber"),
                      // In real implementation, handle file upload
                      documentUrl: "/placeholder-document.pdf",
                    };
                    uploadDocumentMutation.mutate(data);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <Label htmlFor="documentType">Document Type</Label>
                    <Select name="documentType" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select document type" />
                      </SelectTrigger>
                      <SelectContent>
                        {documentTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="documentNumber">Document Number (Optional)</Label>
                    <Input
                      name="documentNumber"
                      placeholder="e.g., License #123456"
                    />
                  </div>

                  <div>
                    <Label htmlFor="file">Upload File</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                      <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600">
                        Click to upload or drag and drop
                      </p>
                      <p className="text-xs text-gray-500">
                        PDF, JPG, PNG up to 10MB
                      </p>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={uploadDocumentMutation.isPending}
                    className="w-full"
                  >
                    {uploadDocumentMutation.isPending ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Document
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Insurance Tab */}
        <TabsContent value="insurance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Insurance List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Insurance Certificates</CardTitle>
                <CardDescription>
                  Your active insurance coverage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Array.isArray(insuranceCertificates) && insuranceCertificates.length > 0 ? (
                    insuranceCertificates.map((cert: InsuranceCertificate) => (
                      <div key={cert.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="font-medium">
                            {insuranceTypes.find(t => t.value === cert.insuranceType)?.label || cert.insuranceType}
                          </div>
                          <Badge className={getStatusColor(cert.verificationStatus)}>
                            {cert.verificationStatus}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                          <div>Provider: {cert.provider}</div>
                          <div>Policy: {cert.policyNumber}</div>
                          <div>Coverage: {formatCurrency(cert.coverageAmount)}</div>
                          <div>
                            Expires: {new Date(cert.expiryDate).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      No insurance certificates on file
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Add Insurance Form */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add Insurance</CardTitle>
                <CardDescription>
                  Add a new insurance certificate
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.target as HTMLFormElement);
                    const data = {
                      insuranceType: formData.get("insuranceType"),
                      provider: formData.get("provider"),
                      policyNumber: formData.get("policyNumber"),
                      coverageAmount: parseFloat(formData.get("coverageAmount") as string),
                      effectiveDate: formData.get("effectiveDate"),
                      expiryDate: formData.get("expiryDate"),
                    };
                    addInsuranceMutation.mutate(data);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <Label htmlFor="insuranceType">Insurance Type</Label>
                    <Select name="insuranceType" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select insurance type" />
                      </SelectTrigger>
                      <SelectContent>
                        {insuranceTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="provider">Provider</Label>
                      <Input
                        name="provider"
                        placeholder="Insurance company"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="policyNumber">Policy Number</Label>
                      <Input
                        name="policyNumber"
                        placeholder="Policy #"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="coverageAmount">Coverage Amount</Label>
                    <Input
                      name="coverageAmount"
                      type="number"
                      placeholder="1000000"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="effectiveDate">Effective Date</Label>
                      <Input
                        name="effectiveDate"
                        type="date"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="expiryDate">Expiry Date</Label>
                      <Input
                        name="expiryDate"
                        type="date"
                        required
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={addInsuranceMutation.isPending}
                    className="w-full"
                  >
                    {addInsuranceMutation.isPending ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Adding...
                      </>
                    ) : (
                      "Add Insurance Certificate"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Disputes Tab */}
        <TabsContent value="disputes" className="space-y-4">
          <div className="space-y-4">
            {Array.isArray(disputes) && disputes.length > 0 ? (
              disputes.map((dispute: Dispute) => (
                <Card key={dispute.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{dispute.title}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant={dispute.priority === "high" ? "destructive" : "secondary"}>
                          {dispute.priority}
                        </Badge>
                        <Badge className={getStatusColor(dispute.status)}>
                          {dispute.status}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>
                      Filed {new Date(dispute.createdAt).toLocaleDateString()}
                      {dispute.category && ` • ${dispute.category}`}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{dispute.description}</p>
                    {dispute.resolutionNotes && (
                      <Alert>
                        <CheckCircle2 className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Resolution:</strong> {dispute.resolutionNotes}
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Scale className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600">No disputes filed</p>
                  <p className="text-sm text-gray-500">
                    Any conflicts will appear here for resolution
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-4">
          <Alert>
            <Users className="h-4 w-4" />
            <AlertDescription>
              Performance metrics and KPIs are tracked automatically based on your partnerships and completed transactions. These ratings help build trust with potential partners.
            </AlertDescription>
          </Alert>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Trust Factors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Identity Verified</span>
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Insurance Current</span>
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Payment Method</span>
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Active Partnerships</span>
                    <Badge>8 Partners</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Reputation Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-600 mb-2">4.8</div>
                  <div className="text-sm text-gray-600 mb-4">out of 5.0</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Communication</span>
                      <span>4.9/5</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Reliability</span>
                      <span>4.8/5</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Quality</span>
                      <span>4.7/5</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}