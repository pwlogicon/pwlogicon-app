import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ArrowLeft,
  ArrowRight,
  X,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  Target,
  Users,
  BarChart3,
  Package,
  Zap,
  Heart,
  Star
} from "lucide-react";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  target: string; // CSS selector for the element to highlight
  position: 'top' | 'bottom' | 'left' | 'right';
  icon: React.ComponentType<any>;
  animation: 'bounce' | 'pulse' | 'shake' | 'spin' | 'float';
  actionText?: string;
  skipable?: boolean;
}

interface OnboardingWalkthroughProps {
  isActive: boolean;
  onComplete: () => void;
  onDismiss: () => void;
  autoPlay?: boolean;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to PWLoGiCon! 🎉',
    description: 'Your AI-powered logistics partnership platform. Let\'s take a quick tour to get you started with connecting partners and managing shipments.',
    target: '',
    position: 'bottom',
    icon: Sparkles,
    animation: 'bounce'
  },
  {
    id: 'opportunities',
    title: 'Discover Opportunities',
    description: 'Browse and post logistics opportunities. Our AI matches you with the perfect partners based on service compatibility and regional coverage.',
    target: '[href="/opportunities"]',
    position: 'bottom',
    icon: Target,
    animation: 'pulse',
    actionText: 'View Opportunities'
  },
  {
    id: 'partnerships',
    title: 'Smart Partner Matching',
    description: 'See AI-powered partner recommendations with confidence scores. Connect with verified carriers, 3PLs, and shippers in your network.',
    target: '[href="/partnerships"]',
    position: 'bottom',
    icon: Users,
    animation: 'float',
    actionText: 'Explore Partners'
  },
  {
    id: 'shipments',
    title: 'Manage Shipments',
    description: 'Track shipments with multi-carrier integration. Compare rates from UPS, FedEx, and specialized carriers in real-time.',
    target: '[href="/shipments"]',
    position: 'bottom',
    icon: Package,
    animation: 'bounce',
    actionText: 'Manage Shipments'
  },
  {
    id: 'analytics',
    title: 'Performance Analytics',
    description: 'Monitor KPIs like delivery success rates (94.8%), cost savings, and partnership performance with interactive dashboards.',
    target: '[href="/analytics"]',
    position: 'bottom',
    icon: BarChart3,
    animation: 'pulse',
    actionText: 'View Analytics'
  },
  {
    id: 'complete',
    title: 'You\'re All Set! ⭐',
    description: 'Ready to revolutionize your logistics partnerships? Start by exploring opportunities or creating your first shipment.',
    target: '',
    position: 'bottom',
    icon: CheckCircle2,
    animation: 'bounce'
  }
];

export default function OnboardingWalkthrough({
  isActive,
  onComplete,
  onDismiss,
  autoPlay = false
}: OnboardingWalkthroughProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [showTooltip, setShowTooltip] = useState(true);
  const overlayRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  const currentStepData = onboardingSteps[currentStep];
  const progress = ((currentStep + 1) / onboardingSteps.length) * 100;

  // Auto-advance functionality
  useEffect(() => {
    if (!isActive || !isPlaying) return;

    const timer = setTimeout(() => {
      nextStep();
    }, 4000); // 4 seconds per step

    return () => clearTimeout(timer);
  }, [currentStep, isActive, isPlaying]);

  // Highlight target element
  useEffect(() => {
    if (!currentStepData.target) return;

    const targetElement = document.querySelector(currentStepData.target) as HTMLElement;
    if (targetElement) {
      targetElement.style.position = 'relative';
      targetElement.style.zIndex = '1001';
      targetElement.classList.add('onboarding-highlight');
      
      // Add pulsing effect
      targetElement.style.animation = `onboarding-${currentStepData.animation} 2s infinite`;
    }

    return () => {
      if (targetElement) {
        targetElement.style.position = '';
        targetElement.style.zIndex = '';
        targetElement.classList.remove('onboarding-highlight');
        targetElement.style.animation = '';
      }
    };
  }, [currentStep, currentStepData]);

  const nextStep = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const restart = () => {
    setCurrentStep(0);
    setIsPlaying(autoPlay);
  };

  if (!isActive) return null;

  return (
    <>
      {/* Onboarding Styles */}
      <style>{`
        .onboarding-highlight {
          box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.7), 0 0 20px rgba(59, 130, 246, 0.8) !important;
          border-radius: 8px !important;
        }
        
        @keyframes onboarding-bounce {
          0%, 20%, 53%, 80%, 100% { transform: translate3d(0, 0, 0); }
          40%, 43% { transform: translate3d(0, -10px, 0); }
          70% { transform: translate3d(0, -5px, 0); }
          90% { transform: translate3d(0, -2px, 0); }
        }
        
        @keyframes onboarding-pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        
        @keyframes onboarding-shake {
          10%, 90% { transform: translate3d(-1px, 0, 0); }
          20%, 80% { transform: translate3d(2px, 0, 0); }
          30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
          40%, 60% { transform: translate3d(4px, 0, 0); }
        }
        
        @keyframes onboarding-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes onboarding-float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
      `}</style>

      {/* Overlay */}
      <div 
        ref={overlayRef}
        className="fixed inset-0 bg-black/70 z-1000 transition-all duration-500"
        onClick={(e) => {
          if (e.target === overlayRef.current) {
            onDismiss();
          }
        }}
      />

      {/* Floating Tooltip */}
      <div
        ref={tooltipRef}
        className={`
          fixed z-1001 transition-all duration-500 ease-out
          ${showTooltip ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}
          ${currentStepData.target ? 'top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2' : 'top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'}
        `}
      >
        <Card className="w-96 shadow-2xl border-0 bg-gradient-to-br from-white to-blue-50/50">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <currentStepData.icon className="h-6 w-6 text-blue-600" />
                  {currentStep === 0 && <Heart className="h-3 w-3 text-red-500 absolute -top-1 -right-1 animate-pulse" />}
                </div>
                <Badge variant="outline" className="text-xs">
                  Step {currentStep + 1} of {onboardingSteps.length}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={onDismiss}
                className="h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Getting Started</span>
                <span>{Math.round(progress)}% Complete</span>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {currentStepData.title}
                </h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {currentStepData.description}
                </p>
              </div>

              {/* Action Button for interactive steps */}
              {currentStepData.actionText && (
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => {
                    // Simulate clicking the target element
                    const target = document.querySelector(currentStepData.target) as HTMLElement;
                    if (target) {
                      target.click();
                    }
                    nextStep();
                  }}
                >
                  <Star className="h-4 w-4 mr-2" />
                  {currentStepData.actionText}
                </Button>
              )}

              {/* Controls */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={togglePlay}
                    className="h-8"
                  >
                    {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={restart}
                    className="h-8"
                  >
                    <RotateCcw className="h-3 w-3" />
                  </Button>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={prevStep}
                    disabled={currentStep === 0}
                    className="h-8"
                  >
                    <ArrowLeft className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    onClick={nextStep}
                    className="h-8 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {currentStep === onboardingSteps.length - 1 ? (
                      <>
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Complete
                      </>
                    ) : (
                      <>
                        Next
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Fun elements */}
            {currentStep === onboardingSteps.length - 1 && (
              <div className="absolute -top-2 -right-2">
                <div className="animate-bounce">
                  <Sparkles className="h-6 w-6 text-yellow-500" />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}