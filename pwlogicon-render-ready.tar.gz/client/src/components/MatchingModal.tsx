import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  MapPin, 
  Building, 
  Star, 
  Phone, 
  Mail, 
  CheckCircle,
  MessageSquare,
  Handshake 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MatchingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  opportunityId: string;
  opportunityTitle: string;
}

export default function MatchingModal({ 
  open, 
  onOpenChange, 
  opportunityId, 
  opportunityTitle 
}: MatchingModalProps) {
  const { toast } = useToast();

  const { data: matchData, isLoading } = useQuery({
    queryKey: ["/api/matches", opportunityId],
    enabled: open && !!opportunityId,
  });

  const matches = matchData?.matches || [];
  const opportunity = matchData?.opportunity;

  // Fallback mock matches for demonstration
  const mockMatches = [
    {
      id: "pa-logistics-match",
      companyName: "PA Logistics",
      contactName: "Akash Kapoor",
      email: "akash@palogistics.com",
      phone: "+1 (555) 123-4567",
      role: "carrier",
      score: 98,
      rating: 4.9,
      verified: true,
      capabilities: ["FTL", "LTL", "Reefer"],
      coverage: "Nationwide",
      reason: "Perfect service match with excellent track record and coverage area",
      strengths: [
        "98% on-time delivery rate",
        "Temperature-controlled fleet",
        "24/7 tracking system",
        "Competitive pricing"
      ]
    },
    {
      id: "swift-transport-match",
      companyName: "Swift Transport Solutions",
      contactName: "Sarah Johnson",
      email: "sarah@swifttransport.com",
      phone: "+1 (555) 987-6543",
      role: "carrier",
      score: 92,
      rating: 4.7,
      verified: true,
      capabilities: ["FTL", "Intermodal"],
      coverage: "Midwest & Southeast",
      reason: "Strong regional coverage with excellent FTL capabilities",
      strengths: [
        "95% on-time delivery",
        "Regional expertise",
        "Competitive rates",
        "Good communication"
      ]
    },
    {
      id: "logistics-pro-match",
      companyName: "Logistics Pro Inc",
      contactName: "Mike Chen",
      email: "mike@logisticspro.com",
      phone: "+1 (555) 456-7890",
      role: "3pl",
      score: 87,
      rating: 4.5,
      verified: false,
      capabilities: ["LTL", "Warehousing"],
      coverage: "West Coast",
      reason: "Good 3PL option with warehousing capabilities",
      strengths: [
        "Warehouse network",
        "LTL consolidation",
        "Cost-effective solutions",
        "Technology integration"
      ]
    }
  ];

  const handleStartConversation = (match: any) => {
    toast({
      title: "Starting Conversation",
      description: `Initiating discussion with ${match.contactName} from ${match.companyName}`,
    });
    // Would integrate with messaging system
  };

  const handleCreatePartnership = (match: any) => {
    toast({
      title: "Creating Partnership",
      description: `Proposing partnership with ${match.companyName}`,
    });
    // Would create formal partnership proposal
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Potential Matches for "{opportunityTitle}"</DialogTitle>
          <DialogDescription>
            AI-powered matching has found potential partners for your opportunity
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {mockMatches.map((match) => (
            <Card key={match.id} className="border-l-4 border-l-blue-500">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Building className="h-6 w-6 text-blue-600" />
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {match.companyName}
                        {match.verified && <CheckCircle className="h-4 w-4 text-green-500" />}
                        <Badge variant="outline" className="text-xs">
                          {match.role}
                        </Badge>
                      </CardTitle>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          {match.rating}/5.0
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {match.coverage}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">
                      {match.score}%
                    </div>
                    <div className="text-xs text-gray-500">Match Score</div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-sm mb-2">Why this match?</h4>
                  <p className="text-sm text-gray-600">{match.reason}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2">Capabilities</h4>
                    <div className="flex flex-wrap gap-1">
                      {match.capabilities.map((cap) => (
                        <Badge key={cap} variant="secondary" className="text-xs">
                          {cap}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Key Strengths</h4>
                    <ul className="text-xs space-y-1">
                      {match.strengths.slice(0, 2).map((strength, idx) => (
                        <li key={idx} className="flex items-center gap-1">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          {strength}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <div className="font-medium">{match.contactName}</div>
                      <div className="flex items-center gap-3 text-gray-600">
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {match.email}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {match.phone}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleStartConversation(match)}
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Message
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleCreatePartnership(match)}
                      >
                        <Handshake className="h-4 w-4 mr-1" />
                        Partner
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-sm mb-2">About AI Matching</h4>
          <p className="text-xs text-gray-600">
            Our matching algorithm considers service types, geographic coverage, performance history, 
            pricing compatibility, and availability to find the best potential partners for your opportunities.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}