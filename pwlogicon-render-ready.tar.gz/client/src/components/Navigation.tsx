import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Target, 
  Users, 
  BarChart3, 
  MessageSquare, 
  Database,
  Smartphone,
  CreditCard,
  LogOut,
  Map,
  Monitor,
  Brain,
  Layers
} from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { path: "/", label: "Dashboard", icon: LayoutDashboard },
    { path: "/unified-dashboard", label: "Unified Operations", icon: Monitor },
    { path: "/predictive-analytics", label: "AI Analytics", icon: Brain },
    { path: "/geospatial-heatmap", label: "Heat Map", icon: Layers },
    { path: "/opportunities", label: "💼 Opportunities", icon: Target },
    { path: "/partnerships", label: "Partnerships", icon: Users },
    { path: "/shipments", label: "Shipments", icon: Target },
    { path: "/integrations", label: "Integrations", icon: Database },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
    { path: "/maps", label: "Maps", icon: Map },
    { path: "/messages", label: "Messages", icon: MessageSquare },
    { path: "/transactions", label: "Transactions", icon: CreditCard },
    { path: "/mobile", label: "Mobile", icon: Smartphone },
  ];

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <nav className="bg-white border-b border-gray-200 px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/">
            <div className="text-xl font-bold text-blue-600">PWLoGiCon</div>
          </Link>
          
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(({ path, label, icon: Icon }) => (
              <Link key={path} href={path}>
                <Button
                  variant={location === path ? "default" : "ghost"}
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </Button>
              </Link>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4">
          {user && (
            <div className="text-sm text-gray-600">
              Welcome, {((user as any)?.firstName || (user as any)?.email || "User") as string}
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden mt-3 flex overflow-x-auto gap-2 pb-2">
        {navItems.map(({ path, label, icon: Icon }) => (
          <Link key={path} href={path}>
            <Button
              variant={location === path ? "default" : "ghost"}
              size="sm"
              className="flex items-center gap-2 whitespace-nowrap"
            >
              <Icon className="h-4 w-4" />
              {label}
            </Button>
          </Link>
        ))}
      </div>
    </nav>
  );
}