import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Download, FileText, BarChart3, TrendingUp, Users, DollarSign, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ReportType {
  id: string;
  name: string;
  description: string;
  filters: string[];
}

interface ReportData {
  id: string;
  title: string;
  type: string;
  generatedAt: string;
  data: any[];
  summary: string;
  format: string;
}

const ReportBuilder = () => {
  const { toast } = useToast();
  const [selectedReportType, setSelectedReportType] = useState<string>('');
  const [reportFilters, setReportFilters] = useState<Record<string, any>>({
    dateRange: 'last_30_days',
    format: 'json'
  });
  const [generatedReport, setGeneratedReport] = useState<ReportData | null>(null);

  // Fetch available report types
  const { data: reportTypes, isLoading: loadingTypes } = useQuery<{ reportTypes: ReportType[] }>({
    queryKey: ['/api/report/types']
  });

  // Generate report mutation
  const generateReportMutation = useMutation({
    mutationFn: async (reportConfig: any) => {
      const response = await fetch('/api/report/generate', {
        method: 'POST',
        body: JSON.stringify(reportConfig),
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate report');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedReport(data);
      toast({ title: "Success", description: "Report generated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate report", variant: "destructive" });
    }
  });

  const handleGenerateReport = () => {
    if (!selectedReportType) {
      toast({ title: "Error", description: "Please select a report type", variant: "destructive" });
      return;
    }

    generateReportMutation.mutate({
      type: selectedReportType,
      filters: reportFilters,
      format: reportFilters.format
    });
  };

  const downloadReport = (format: string) => {
    if (!selectedReportType) return;

    const config = {
      type: selectedReportType,
      filters: { ...reportFilters, format },
      format
    };

    // For file downloads, we need to handle this differently
    const queryString = new URLSearchParams({
      type: selectedReportType,
      filters: JSON.stringify(reportFilters),
      format
    });

    window.open(`/api/report/generate?${queryString}`, '_blank');
  };

  const getReportIcon = (type: string) => {
    switch (type) {
      case 'lane_performance':
        return <MapPin className="h-5 w-5" />;
      case 'compliance_summary':
        return <FileText className="h-5 w-5" />;
      case 'financial_overview':
        return <DollarSign className="h-5 w-5" />;
      case 'carrier_analytics':
        return <Users className="h-5 w-5" />;
      case 'opportunity_trends':
        return <TrendingUp className="h-5 w-5" />;
      default:
        return <BarChart3 className="h-5 w-5" />;
    }
  };

  const renderFilterInputs = (filters: string[]) => {
    return filters.map(filter => (
      <div key={filter} className="space-y-2">
        <Label htmlFor={filter} className="capitalize">{filter.replace(/_/g, ' ')}</Label>
        {filter === 'dateRange' ? (
          <Select 
            value={reportFilters[filter]} 
            onValueChange={(value) => setReportFilters(prev => ({ ...prev, [filter]: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last_7_days">Last 7 Days</SelectItem>
              <SelectItem value="last_30_days">Last 30 Days</SelectItem>
              <SelectItem value="last_90_days">Last 90 Days</SelectItem>
              <SelectItem value="last_year">Last Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
        ) : filter === 'serviceType' ? (
          <Select 
            value={reportFilters[filter]} 
            onValueChange={(value) => setReportFilters(prev => ({ ...prev, [filter]: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select service type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Services</SelectItem>
              <SelectItem value="ftl">Full Truckload (FTL)</SelectItem>
              <SelectItem value="ltl">Less Than Truckload (LTL)</SelectItem>
              <SelectItem value="reefer">Refrigerated</SelectItem>
              <SelectItem value="intermodal">Intermodal</SelectItem>
            </SelectContent>
          </Select>
        ) : filter === 'complianceStatus' ? (
          <Select 
            value={reportFilters[filter]} 
            onValueChange={(value) => setReportFilters(prev => ({ ...prev, [filter]: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select compliance status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Verified">Verified</SelectItem>
              <SelectItem value="Pending">Pending</SelectItem>
              <SelectItem value="Rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        ) : (
          <Input
            id={filter}
            value={reportFilters[filter] || ''}
            onChange={(e) => setReportFilters(prev => ({ ...prev, [filter]: e.target.value }))}
            placeholder={`Enter ${filter.replace(/_/g, ' ')}`}
          />
        )}
      </div>
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Custom Report Builder</h2>
          <p className="text-gray-600">Generate comprehensive analytics and performance reports</p>
        </div>
        <Badge className="bg-blue-100 text-blue-800 border-blue-300">
          <BarChart3 className="h-4 w-4 mr-1" />
          Analytics
        </Badge>
      </div>

      <Tabs defaultValue="builder" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="builder">Report Builder</TabsTrigger>
          <TabsTrigger value="results">Results & Export</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Report Type Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Select Report Type
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {loadingTypes ? (
                  <div className="text-center py-4">Loading report types...</div>
                ) : reportTypes ? (
                  <div className="space-y-3">
                    {reportTypes.reportTypes.map((type) => (
                      <div
                        key={type.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedReportType === type.id 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedReportType(type.id)}
                      >
                        <div className="flex items-center gap-3">
                          {getReportIcon(type.id)}
                          <div>
                            <h4 className="font-medium">{type.name}</h4>
                            <p className="text-sm text-gray-600">{type.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4">No report types available</div>
                )}
              </CardContent>
            </Card>

            {/* Filters Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Configure Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedReportType && reportTypes ? (
                  <div className="space-y-4">
                    {renderFilterInputs(
                      reportTypes.reportTypes.find(t => t.id === selectedReportType)?.filters || []
                    )}
                    
                    {/* Output Format */}
                    <div className="space-y-2">
                      <Label htmlFor="format">Output Format</Label>
                      <Select 
                        value={reportFilters.format} 
                        onValueChange={(value) => setReportFilters(prev => ({ ...prev, format: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="json">JSON (Preview)</SelectItem>
                          <SelectItem value="csv">CSV</SelectItem>
                          <SelectItem value="excel">Excel</SelectItem>
                          <SelectItem value="pdf">PDF</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Select a report type to configure filters
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Generate Button */}
          <div className="flex justify-center">
            <Button 
              onClick={handleGenerateReport}
              disabled={!selectedReportType || generateReportMutation.isPending}
              size="lg"
              className="px-8"
            >
              {generateReportMutation.isPending ? "Generating..." : "Generate Report"}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {generatedReport ? (
            <div className="space-y-6">
              {/* Report Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{generatedReport.title}</span>
                    <div className="flex gap-2">
                      <Button variant="outline" onClick={() => downloadReport('csv')}>
                        <Download className="h-4 w-4 mr-2" />
                        CSV
                      </Button>
                      <Button variant="outline" onClick={() => downloadReport('excel')}>
                        <Download className="h-4 w-4 mr-2" />
                        Excel
                      </Button>
                      <Button variant="outline" onClick={() => downloadReport('pdf')}>
                        <Download className="h-4 w-4 mr-2" />
                        PDF
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-gray-600">Generated:</span>
                        <p className="font-medium">{new Date(generatedReport.generatedAt).toLocaleString()}</p>
                      </div>
                      <div>
                        <span className="text-sm text-gray-600">Records:</span>
                        <p className="font-medium">{generatedReport.data.length}</p>
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">Summary:</span>
                      <p className="mt-1">{generatedReport.summary}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Data Preview */}
              <Card>
                <CardHeader>
                  <CardTitle>Data Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <pre className="text-sm bg-gray-50 p-4 rounded-lg max-h-96 overflow-y-auto">
                      {JSON.stringify(generatedReport.data.slice(0, 10), null, 2)}
                      {generatedReport.data.length > 10 && "\n... and more"}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-12">
              <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Reports Generated</h3>
              <p className="text-gray-600">Generate a report from the Builder tab to see results here</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ReportBuilder;