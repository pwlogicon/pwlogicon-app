import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, AlertTriangle, Info, Truck, Clock, Target } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface GeofenceAlert {
  id: string;
  truckId: string;
  location: string;
  status: 'entered' | 'exited';
  distance: number;
  geofenceType: string;
  timestamp: string;
  coordinates: {
    truck: { lat: number; lng: number } | null;
    geofence: { lat: number; lng: number; radius: number };
  };
  severity: 'info' | 'warning';
}

interface Geofence {
  name: string;
  lat: number;
  lng: number;
  radius: number;
  type: string;
  activeVehicles: string[];
}

const GeofenceMonitor: React.FC = () => {
  const [selectedAlert, setSelectedAlert] = useState<GeofenceAlert | null>(null);

  const { data: geofenceData, refetch } = useQuery({
    queryKey: ['/api/geofences'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: alertsData } = useQuery({
    queryKey: ['/api/geofences/alerts'],
    refetchInterval: 5000, // Refresh alerts every 5 seconds
  });

  const getStatusIcon = (status: 'entered' | 'exited') => {
    return status === 'entered' ? (
      <MapPin className="h-4 w-4 text-green-600" />
    ) : (
      <AlertTriangle className="h-4 w-4 text-orange-600" />
    );
  };

  const getSeverityBadge = (severity: 'info' | 'warning') => {
    return (
      <Badge variant={severity === 'info' ? 'default' : 'destructive'}>
        {severity === 'info' ? <Info className="h-3 w-3 mr-1" /> : <AlertTriangle className="h-3 w-3 mr-1" />}
        {severity.charAt(0).toUpperCase() + severity.slice(1)}
      </Badge>
    );
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const geofences: Geofence[] = (geofenceData as any)?.geofences || [];
  const alerts: GeofenceAlert[] = (alertsData as any)?.alerts || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Geofence Monitoring</h2>
        <Button onClick={() => refetch()} variant="outline">
          <Clock className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="alerts">Live Alerts</TabsTrigger>
          <TabsTrigger value="geofences">Geofences</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Geofences</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{geofences.length}</div>
                <p className="text-xs text-muted-foreground">
                  Monitoring {geofences.reduce((acc, g) => acc + g.activeVehicles.length, 0)} vehicles
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recent Alerts</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{alerts.length}</div>
                <p className="text-xs text-muted-foreground">
                  Last 24 hours
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Vehicles</CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Array.from(new Set(alerts.map(a => a.truckId))).length}
                </div>
                <p className="text-xs text-muted-foreground">
                  In geofenced areas
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Alert Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-3">
                  {alerts.slice(0, 10).map((alert) => (
                    <div
                      key={alert.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                      onClick={() => setSelectedAlert(alert)}
                    >
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(alert.status)}
                        <div>
                          <p className="font-medium">{alert.truckId}</p>
                          <p className="text-sm text-gray-600">
                            {alert.status} {alert.location}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        {getSeverityBadge(alert.severity)}
                        <p className="text-xs text-gray-500 mt-1">
                          {formatTimestamp(alert.timestamp)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Alert Feed</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <Alert key={alert.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          {getStatusIcon(alert.status)}
                          <div>
                            <AlertDescription className="font-medium">
                              Truck {alert.truckId} has {alert.status} {alert.location}
                            </AlertDescription>
                            <div className="mt-2 text-sm text-gray-600 space-y-1">
                              <p>Distance from center: {alert.distance} miles</p>
                              <p>Geofence type: {alert.geofenceType}</p>
                              <p>Time: {formatTimestamp(alert.timestamp)}</p>
                              {alert.coordinates.truck && (
                                <p>
                                  Location: {alert.coordinates.truck.lat.toFixed(4)}, {alert.coordinates.truck.lng.toFixed(4)}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        {getSeverityBadge(alert.severity)}
                      </div>
                    </Alert>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="geofences" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {geofences.map((geofence) => (
              <Card key={geofence.name}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{geofence.name}</span>
                    <Badge variant="outline">{geofence.type}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm text-gray-600">
                    <p>Coordinates: {geofence.lat.toFixed(4)}, {geofence.lng.toFixed(4)}</p>
                    <p>Radius: {geofence.radius} miles</p>
                  </div>
                  
                  {geofence.activeVehicles.length > 0 ? (
                    <div>
                      <p className="text-sm font-medium text-green-600">
                        Active Vehicles ({geofence.activeVehicles.length})
                      </p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {geofence.activeVehicles.map((truckId) => (
                          <Badge key={truckId} variant="secondary" className="text-xs">
                            {truckId}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No active vehicles</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {selectedAlert && (
        <Alert className="border-blue-200 bg-blue-50">
          <Info className="h-4 w-4" />
          <AlertDescription>
            <strong>Alert Details:</strong> Truck {selectedAlert.truckId} {selectedAlert.status} {selectedAlert.location} 
            at {formatTimestamp(selectedAlert.timestamp)} 
            ({selectedAlert.distance} miles from geofence center)
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default GeofenceMonitor;