import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  AlertTriangle,
  FileText,
  Upload,
  Download,
  Clock
} from "lucide-react";

interface BatchItem {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  errorMessage?: string;
  result?: any;
}

interface BatchOperation {
  id: string;
  name: string;
  type: 'shipment_creation' | 'rate_quote' | 'label_generation';
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'paused';
  totalItems: number;
  processedItems: number;
  successfulItems: number;
  failedItems: number;
  startTime: Date;
  estimatedCompletion?: Date;
  items: BatchItem[];
}

interface BatchProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  batchOperation: BatchOperation | null;
  onCancel?: () => void;
  onRetry?: () => void;
  onDownloadResults?: () => void;
}

export default function BatchProgressModal({
  isOpen,
  onClose,
  batchOperation,
  onCancel,
  onRetry,
  onDownloadResults
}: BatchProgressModalProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (!batchOperation) return null;

  const overallProgress = (batchOperation.processedItems / batchOperation.totalItems) * 100;
  
  const getElapsedTime = () => {
    const elapsed = currentTime.getTime() - batchOperation.startTime.getTime();
    const minutes = Math.floor(elapsed / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getEstimatedTimeRemaining = () => {
    if (batchOperation.estimatedCompletion) {
      const remaining = batchOperation.estimatedCompletion.getTime() - currentTime.getTime();
      if (remaining <= 0) return 'Completing...';
      
      const minutes = Math.floor(remaining / 60000);
      const seconds = Math.floor((remaining % 60000) / 1000);
      return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    return 'Calculating...';
  };

  const getItemStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'processing': return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'pending': return <Clock className="h-4 w-4 text-gray-400" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getOperationTypeLabel = (type: string) => {
    switch (type) {
      case 'shipment_creation': return 'Shipment Creation';
      case 'rate_quote': return 'Rate Quote';
      case 'label_generation': return 'Label Generation';
      default: return 'Batch Operation';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Upload className="h-5 w-5" />
            <span>{getOperationTypeLabel(batchOperation.type)}</span>
          </DialogTitle>
          <DialogDescription>
            Processing {batchOperation.totalItems} items - {batchOperation.name}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-auto space-y-6">
          {/* Overall Progress */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Overall Progress</h3>
              <Badge 
                className={
                  batchOperation.status === 'completed' ? 'bg-green-100 text-green-800' :
                  batchOperation.status === 'failed' ? 'bg-red-100 text-red-800' :
                  batchOperation.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                  'bg-gray-100 text-gray-800'
                }
              >
                {batchOperation.status.charAt(0).toUpperCase() + batchOperation.status.slice(1)}
              </Badge>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span className="font-medium">{Math.round(overallProgress)}%</span>
              </div>
              <Progress value={overallProgress} className="h-3" />
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-4 gap-4 text-center">
              <div className="bg-gray-50 rounded-lg p-3">
                <div className="text-2xl font-bold text-gray-900">{batchOperation.totalItems}</div>
                <div className="text-sm text-gray-500">Total</div>
              </div>
              <div className="bg-blue-50 rounded-lg p-3">
                <div className="text-2xl font-bold text-blue-600">{batchOperation.processedItems}</div>
                <div className="text-sm text-blue-500">Processed</div>
              </div>
              <div className="bg-green-50 rounded-lg p-3">
                <div className="text-2xl font-bold text-green-600">{batchOperation.successfulItems}</div>
                <div className="text-sm text-green-500">Successful</div>
              </div>
              <div className="bg-red-50 rounded-lg p-3">
                <div className="text-2xl font-bold text-red-600">{batchOperation.failedItems}</div>
                <div className="text-sm text-red-500">Failed</div>
              </div>
            </div>

            {/* Timing */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Elapsed Time:</span>
                <span className="ml-2 font-medium">{getElapsedTime()}</span>
              </div>
              {batchOperation.status === 'processing' && (
                <div>
                  <span className="text-gray-500">Estimated Remaining:</span>
                  <span className="ml-2 font-medium">{getEstimatedTimeRemaining()}</span>
                </div>
              )}
            </div>
          </div>

          {/* Item List */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Item Details</h3>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {batchOperation.items.map((item, index) => (
                <div 
                  key={item.id}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                    item.status === 'processing' ? 'bg-blue-50 border-blue-200' :
                    item.status === 'completed' ? 'bg-green-50 border-green-200' :
                    item.status === 'failed' ? 'bg-red-50 border-red-200' :
                    'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-gray-500 w-8">#{index + 1}</span>
                    {getItemStatusIcon(item.status)}
                    <div>
                      <div className="font-medium">{item.name}</div>
                      {item.status === 'processing' && (
                        <Progress value={item.progress} className="w-32 h-2 mt-1" />
                      )}
                      {item.errorMessage && (
                        <div className="text-sm text-red-600 mt-1 flex items-center">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          {item.errorMessage}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-500">
                    {item.status === 'processing' && `${Math.round(item.progress)}%`}
                    {item.status === 'completed' && 'Done'}
                    {item.status === 'failed' && 'Error'}
                    {item.status === 'pending' && 'Waiting'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="flex justify-between">
          <div className="flex space-x-2">
            {batchOperation.status === 'processing' && onCancel && (
              <Button variant="destructive" onClick={onCancel}>
                Cancel Operation
              </Button>
            )}
            {batchOperation.status === 'failed' && onRetry && (
              <Button variant="outline" onClick={onRetry}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry Failed Items
              </Button>
            )}
          </div>
          
          <div className="flex space-x-2">
            {(batchOperation.status === 'completed' || batchOperation.status === 'failed') && onDownloadResults && (
              <Button variant="outline" onClick={onDownloadResults}>
                <Download className="h-4 w-4 mr-2" />
                Download Results
              </Button>
            )}
            <Button onClick={onClose}>
              {batchOperation.status === 'processing' ? 'Minimize' : 'Close'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}