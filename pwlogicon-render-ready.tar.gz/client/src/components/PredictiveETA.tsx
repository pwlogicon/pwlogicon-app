import React, { useState, useEffect } from 'react';

interface PredictiveETAProps {
  opportunityId: string;
  sid?: string;
}

interface ETAData {
  opportunityId: string;
  predictedETA: string;
  confidence: string;
  confidenceRange: [string, string];
  dwellTimeAtOrigin: string;
  exceptionRisk: string;
  lastUpdated: string;
}

interface Alert {
  type: 'warning' | 'danger' | 'error';
  message: string;
}

const PredictiveETA: React.FC<PredictiveETAProps> = ({ opportunityId, sid }) => {
  const [eta, setEta] = useState<ETAData | null>(null);
  const [loading, setLoading] = useState(true);
  const [alert, setAlert] = useState<Alert | null>(null);

  useEffect(() => {
    const fetchETA = async () => {
      try {
        const url = sid ? `/api/predictive-eta/${opportunityId}?sid=${sid}` : `/api/predictive-eta/${opportunityId}`;
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        setEta(data);

        // Check for risks
        const riskValue = parseFloat(data.exceptionRisk.replace('%', ''));
        if (riskValue > 30) {
          setAlert({
            type: 'warning',
            message: `High risk of delay (${data.exceptionRisk}) — monitor closely`
          });
        } else {
          setAlert(null);
        }
      } catch (err) {
        console.error('PredictiveETA fetch error:', err);
        setAlert({ type: 'error', message: 'Failed to load predictive ETA' });
      } finally {
        setLoading(false);
      }
    };

    fetchETA();
    const interval = setInterval(fetchETA, 300000); // Refresh every 5 mins
    return () => clearInterval(interval);
  }, [opportunityId, sid]);

  if (loading) {
    return (
      <div className="p-4 bg-white rounded-lg border border-gray-200">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
          <div className="h-8 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (!eta) {
    return (
      <div className="p-4 bg-red-50 rounded-lg border border-red-200">
        <p className="text-red-700">Unable to load predictive ETA data</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-3">🧠 Predictive ETA</h3>
      
      {alert && (
        <div className={`p-3 rounded-md mb-4 ${
          alert.type === 'warning' ? 'bg-yellow-50 border border-yellow-200 text-yellow-800' :
          alert.type === 'danger' ? 'bg-red-50 border border-red-200 text-red-800' :
          'bg-red-50 border border-red-200 text-red-800'
        }`}>
          {alert.message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="mb-2">
            <span className="text-sm font-medium text-gray-600">Predicted Arrival</span>
          </div>
          <div className="text-xl font-semibold text-blue-600 mb-1">
            {new Date(eta.predictedETA).toLocaleString()}
          </div>
          <div className="text-sm text-gray-500">
            Confidence: {eta.confidence} | Range: {new Date(eta.confidenceRange[0]).toLocaleTimeString()} – {new Date(eta.confidenceRange[1]).toLocaleTimeString()}
          </div>
        </div>

        <div>
          <div className="mb-2">
            <span className="text-sm font-medium text-gray-600">Performance Insights</span>
          </div>
          <div className="space-y-1 text-sm">
            <div>Dwell at Origin: <span className="font-medium">{eta.dwellTimeAtOrigin}</span></div>
            <div>Exception Risk: <span className="font-medium">{eta.exceptionRisk}</span></div>
            <div>Last Updated: <span className="font-medium">{new Date(eta.lastUpdated).toLocaleTimeString()}</span></div>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <button 
          className="inline-flex items-center px-3 py-2 text-sm font-medium text-blue-600 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 transition-colors"
          onClick={() => window.print()}
        >
          🖨️ Export ETA Report
        </button>
      </div>
    </div>
  );
};

export default PredictiveETA;