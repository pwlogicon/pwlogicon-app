import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Target, 
  DollarSign, 
  Truck, 
  Clock, 
  BarChart3,
  AlertTriangle,
  CheckCircle,
  RefreshCw
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface KPI {
  name: string;
  current: number;
  target: number;
  trend: 'up' | 'down' | 'stable';
  category: 'performance' | 'financial' | 'efficiency' | 'compliance' | 'coverage';
  description: string;
}

interface KPIData {
  kpis: KPI[];
  lastUpdated: string;
  summary: {
    totalKPIs: number;
    onTarget: number;
    needsImprovement: number;
    overallScore: number;
  };
}

const KPIDashboard: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('30d');

  const { data: kpiData, refetch } = useQuery<KPIData>({
    queryKey: ['/api/kpis'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: trendsData } = useQuery({
    queryKey: ['/api/kpis/trends', selectedPeriod],
    refetchInterval: 60000, // Refresh every minute
  }) as { data: any };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-red-600" />;
      default:
        return <Minus className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'financial':
        return <DollarSign className="h-5 w-5" />;
      case 'efficiency':
        return <Clock className="h-5 w-5" />;
      case 'performance':
        return <Target className="h-5 w-5" />;
      case 'compliance':
        return <CheckCircle className="h-5 w-5" />;
      case 'coverage':
        return <Truck className="h-5 w-5" />;
      default:
        return <BarChart3 className="h-5 w-5" />;
    }
  };

  const getPerformanceColor = (current: number, target: number) => {
    const percentage = (current / target) * 100;
    if (percentage >= 100) return 'text-green-600';
    if (percentage >= 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getProgressValue = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const filteredKPIs = selectedCategory === 'all' 
    ? kpiData?.kpis || []
    : kpiData?.kpis.filter(kpi => kpi.category === selectedCategory) || [];

  const categoryGroups = kpiData?.kpis.reduce((groups, kpi) => {
    const category = kpi.category;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(kpi);
    return groups;
  }, {} as Record<string, KPI[]>) || {};

  const formatTrendsData = () => {
    if (!trendsData?.trends) return [];
    
    const groupedByDate = trendsData.trends.reduce((acc: any, trend: any) => {
      if (!acc[trend.date]) {
        acc[trend.date] = { date: trend.date };
      }
      acc[trend.date][trend.name] = trend.value;
      return acc;
    }, {});

    return Object.values(groupedByDate) as any[];
  };

  if (!kpiData) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">KPI Dashboard</h2>
        <div className="flex items-center gap-4">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="performance">Performance</SelectItem>
              <SelectItem value="financial">Financial</SelectItem>
              <SelectItem value="efficiency">Efficiency</SelectItem>
              <SelectItem value="compliance">Compliance</SelectItem>
              <SelectItem value="coverage">Coverage</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => refetch()} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total KPIs</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.summary.totalKPIs}</div>
            <p className="text-xs text-muted-foreground">Tracked metrics</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">On Target</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{kpiData.summary.onTarget}</div>
            <p className="text-xs text-muted-foreground">Meeting targets</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Needs Improvement</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{kpiData.summary.needsImprovement}</div>
            <p className="text-xs text-muted-foreground">Below target</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Score</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpiData.summary.overallScore}%</div>
            <p className="text-xs text-muted-foreground">Performance score</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="grid" className="w-full">
        <TabsList>
          <TabsTrigger value="grid">Grid View</TabsTrigger>
          <TabsTrigger value="categories">By Category</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="grid" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredKPIs.map((kpi) => (
              <Card key={kpi.name} className="relative">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      {getCategoryIcon(kpi.category)}
                      {kpi.name}
                    </CardTitle>
                    {getTrendIcon(kpi.trend)}
                  </div>
                  <Badge variant="outline" className="w-fit">
                    {kpi.category}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">
                      {kpi.name.includes('$') ? '$' : ''}{kpi.current.toFixed(kpi.current < 10 ? 1 : 0)}
                      {kpi.name.includes('%') ? '%' : ''}
                    </span>
                    <span className={`text-lg font-semibold ${getPerformanceColor(kpi.current, kpi.target)}`}>
                      Target: {kpi.target.toFixed(kpi.target < 10 ? 1 : 0)}{kpi.name.includes('%') ? '%' : ''}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress to Target</span>
                      <span>{getProgressValue(kpi.current, kpi.target).toFixed(0)}%</span>
                    </div>
                    <Progress 
                      value={getProgressValue(kpi.current, kpi.target)} 
                      className="h-2"
                    />
                  </div>
                  
                  <p className="text-xs text-gray-600">{kpi.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          {Object.entries(categoryGroups).map(([category, kpis]) => (
            <Card key={category}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 capitalize">
                  {getCategoryIcon(category)}
                  {category} KPIs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {kpis.map((kpi) => (
                    <div key={kpi.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{kpi.name}</p>
                        <p className="text-sm text-gray-600">
                          Current: {kpi.current.toFixed(1)} | Target: {kpi.target.toFixed(1)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {getTrendIcon(kpi.trend)}
                        <Badge variant={kpi.current >= kpi.target ? "default" : "destructive"}>
                          {((kpi.current / kpi.target) * 100).toFixed(0)}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">KPI Trends</h3>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7 Days</SelectItem>
                <SelectItem value="30d">30 Days</SelectItem>
                <SelectItem value="90d">90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={formatTrendsData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="On-Time Delivery %" stroke="#10b981" strokeWidth={2} />
                  <Line type="monotone" dataKey="Lane Coverage %" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="Capacity Utilization %" stroke="#8b5cf6" strokeWidth={2} />
                  <Line type="monotone" dataKey="Partner Compliance %" stroke="#f59e0b" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default KPIDashboard;