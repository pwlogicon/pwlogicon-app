import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, XCircle, Clock, Shield, FileText, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ComplianceCheck {
  mcNumber: string;
  insuranceOnFile: string;
  safetyRating: string;
  dotCompliant: string;
  cargoCoverage: string;
  status: string;
  score: number;
  lastVerified: string;
}

interface ComplianceSummary {
  totalCarriers: number;
  verified: number;
  pending: number;
  rejected: number;
  averageScore: number;
  lastUpdated: string;
}

const CarrierCompliance = () => {
  const { toast } = useToast();
  const [selectedUserId, setSelectedUserId] = useState<string>("dev-user-1");
  const [complianceData, setComplianceData] = useState({
    mcNumber: "",
    dotNumber: "",
    insuranceExpiry: "",
    safetyRating: "",
    cargoCoverage: ""
  });

  // Fetch compliance data for selected user
  const { data: compliance, isLoading } = useQuery<ComplianceCheck>({
    queryKey: ['/api/compliance', selectedUserId],
    enabled: !!selectedUserId
  });

  // Fetch compliance summary
  const { data: summary } = useQuery<ComplianceSummary>({
    queryKey: ['/api/compliance/summary']
  });

  // Update compliance mutation
  const updateComplianceMutation = useMutation({
    mutationFn: (data: any) => 
      apiRequest(`/api/compliance/${selectedUserId}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/compliance'] });
      toast({ title: "Success", description: "Compliance information updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update compliance information", variant: "destructive" });
    }
  });

  useEffect(() => {
    if (compliance) {
      // Note: This would need actual user data in production
      setComplianceData({
        mcNumber: "MC123456",
        dotNumber: "1234567",
        insuranceExpiry: "2025-12-31",
        safetyRating: "Satisfactory",
        cargoCoverage: "150000"
      });
    }
  }, [compliance]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateComplianceMutation.mutate(complianceData);
  };

  const getStatusIcon = (check: string) => {
    if (check === '✅') return <CheckCircle className="h-5 w-5 text-green-600" />;
    return <XCircle className="h-5 w-5 text-red-600" />;
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      'Verified': 'bg-green-100 text-green-800 border-green-300',
      'Pending': 'bg-yellow-100 text-yellow-800 border-yellow-300',
      'Rejected': 'bg-red-100 text-red-800 border-red-300'
    };
    return variants[status as keyof typeof variants] || variants['Pending'];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Carrier Compliance Center</h2>
          <p className="text-gray-600">Monitor and manage carrier compliance requirements</p>
        </div>
        <Badge className="bg-blue-100 text-blue-800 border-blue-300">
          <Shield className="h-4 w-4 mr-1" />
          DOT Compliant
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="details">Compliance Details</TabsTrigger>
          <TabsTrigger value="update">Update Information</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="text-2xl font-bold text-green-600">
                      {summary?.verified || 0}
                    </div>
                    <div className="text-sm text-gray-600">Verified Carriers</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <div>
                    <div className="text-2xl font-bold text-yellow-600">
                      {summary?.pending || 0}
                    </div>
                    <div className="text-sm text-gray-600">Pending Review</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  <div>
                    <div className="text-2xl font-bold text-red-600">
                      {summary?.rejected || 0}
                    </div>
                    <div className="text-sm text-gray-600">Non-Compliant</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {Math.round(summary?.averageScore || 0)}%
                    </div>
                    <div className="text-sm text-gray-600">Average Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="details" className="space-y-6">
          {isLoading ? (
            <div className="text-center py-8">Loading compliance data...</div>
          ) : compliance ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Compliance Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Overall Status</span>
                    <Badge className={getStatusBadge(compliance.status)}>
                      {compliance.status}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span>Compliance Score</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${compliance.score}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{compliance.score}%</span>
                    </div>
                  </div>

                  <div className="text-sm text-gray-600">
                    Last verified: {new Date(compliance.lastVerified).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Compliance Checklist</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(compliance.mcNumber)}
                      <span>MC Number Valid</span>
                    </div>
                    <span className="text-2xl">{compliance.mcNumber}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(compliance.insuranceOnFile)}
                      <span>Insurance Current</span>
                    </div>
                    <span className="text-2xl">{compliance.insuranceOnFile}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(compliance.safetyRating)}
                      <span>Safety Rating</span>
                    </div>
                    <span className="text-2xl">{compliance.safetyRating}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(compliance.dotCompliant)}
                      <span>DOT Compliant</span>
                    </div>
                    <span className="text-2xl">{compliance.dotCompliant}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(compliance.cargoCoverage)}
                      <span>Cargo Coverage</span>
                    </div>
                    <span className="text-2xl">{compliance.cargoCoverage}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-8">No compliance data found</div>
          )}
        </TabsContent>

        <TabsContent value="update" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Update Compliance Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="mcNumber">MC Number</Label>
                    <Input
                      id="mcNumber"
                      value={complianceData.mcNumber}
                      onChange={(e) => setComplianceData(prev => ({ ...prev, mcNumber: e.target.value }))}
                      placeholder="MC123456"
                    />
                  </div>

                  <div>
                    <Label htmlFor="dotNumber">DOT Number</Label>
                    <Input
                      id="dotNumber"
                      value={complianceData.dotNumber}
                      onChange={(e) => setComplianceData(prev => ({ ...prev, dotNumber: e.target.value }))}
                      placeholder="1234567"
                    />
                  </div>

                  <div>
                    <Label htmlFor="insuranceExpiry">Insurance Expiry</Label>
                    <Input
                      id="insuranceExpiry"
                      type="date"
                      value={complianceData.insuranceExpiry}
                      onChange={(e) => setComplianceData(prev => ({ ...prev, insuranceExpiry: e.target.value }))}
                    />
                  </div>

                  <div>
                    <Label htmlFor="safetyRating">Safety Rating</Label>
                    <Select value={complianceData.safetyRating} onValueChange={(value) => setComplianceData(prev => ({ ...prev, safetyRating: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select rating" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Satisfactory">Satisfactory</SelectItem>
                        <SelectItem value="Conditional">Conditional</SelectItem>
                        <SelectItem value="Unsatisfactory">Unsatisfactory</SelectItem>
                        <SelectItem value="Not Rated">Not Rated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="md:col-span-2">
                    <Label htmlFor="cargoCoverage">Cargo Coverage ($)</Label>
                    <Input
                      id="cargoCoverage"
                      type="number"
                      value={complianceData.cargoCoverage}
                      onChange={(e) => setComplianceData(prev => ({ ...prev, cargoCoverage: e.target.value }))}
                      placeholder="100000"
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={updateComplianceMutation.isPending}
                >
                  {updateComplianceMutation.isPending ? "Updating..." : "Update Compliance Information"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CarrierCompliance;