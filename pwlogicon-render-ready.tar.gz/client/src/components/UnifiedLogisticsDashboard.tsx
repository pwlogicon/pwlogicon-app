import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { 
  Package, 
  Truck, 
  CheckCircle, 
  DollarSign, 
  RefreshCw, 
  TrendingUp,
  Clock,
  AlertTriangle,
  BarChart3,
  PieChart,
  Activity
} from "lucide-react";
import { PieChart as RechartsPieChart, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

interface DashboardMetrics {
  ordersToProcess: number;
  inTransit: number;
  deliveredToday: number;
  inventoryValue: number;
}

interface OrderStatus {
  status: string;
  count: number;
  color: string;
}

interface ShipmentStatus {
  status: string;
  count: number;
  color: string;
}

interface RecentOrder {
  id: string;
  customer: string;
  status: string;
  value: number;
  timestamp: string;
}

interface ActiveShipment {
  id: string;
  route: string;
  status: string;
  eta: string;
  carrier: string;
}

interface UnifiedDashboardData {
  metrics: DashboardMetrics;
  orderStatus: OrderStatus[];
  shipmentStatus: ShipmentStatus[];
  recentOrders: RecentOrder[];
  activeShipments: ActiveShipment[];
  lastUpdated: string;
}

interface UnifiedLogisticsDashboardProps {
  dateRange?: string;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

export default function UnifiedLogisticsDashboard({ 
  dateRange = 'today', 
  autoRefresh = true, 
  refreshInterval = 30000 
}: UnifiedLogisticsDashboardProps) {
  const [selectedDateRange, setSelectedDateRange] = useState(dateRange);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const { data: dashboardData, isLoading, error, refetch } = useQuery<UnifiedDashboardData>({
    queryKey: ['/api/dashboard/unified', selectedDateRange],
    refetchInterval: autoRefresh ? refreshInterval : false,
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refetch();
    } finally {
      setIsRefreshing(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const getStatusBadge = (status: string) => {
    const statusColors: Record<string, string> = {
      'processing': 'bg-blue-100 text-blue-800',
      'ready': 'bg-green-100 text-green-800',
      'shipped': 'bg-purple-100 text-purple-800',
      'delivered': 'bg-green-100 text-green-800',
      'in-transit': 'bg-blue-100 text-blue-800',
      'delayed': 'bg-red-100 text-red-800',
      'pending': 'bg-yellow-100 text-yellow-800'
    };

    return (
      <Badge className={statusColors[status.toLowerCase()] || 'bg-gray-100 text-gray-800'}>
        {status}
      </Badge>
    );
  };

  if (error) {
    return (
      <Alert className="border-red-200 bg-red-50">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Failed to load dashboard data. Please check your system connections and try again.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Dashboard Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Unified Logistics Dashboard</h1>
          <p className="text-gray-600">Real-time view across WMS, TMS, and ERP systems</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={selectedDateRange} onValueChange={setSelectedDateRange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            onClick={handleRefresh} 
            disabled={isRefreshing || isLoading}
            variant="outline"
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${(isRefreshing || isLoading) ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Orders to Process</p>
                <p className="text-2xl font-bold text-gray-900">
                  {isLoading ? '-' : dashboardData?.metrics.ordersToProcess.toLocaleString()}
                </p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Transit</p>
                <p className="text-2xl font-bold text-gray-900">
                  {isLoading ? '-' : dashboardData?.metrics.inTransit.toLocaleString()}
                </p>
              </div>
              <Truck className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Delivered Today</p>
                <p className="text-2xl font-bold text-gray-900">
                  {isLoading ? '-' : dashboardData?.metrics.deliveredToday.toLocaleString()}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Inventory Value</p>
                <p className="text-2xl font-bold text-gray-900">
                  {isLoading ? '-' : formatCurrency(dashboardData?.metrics.inventoryValue || 0)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Order Status Distribution
            </CardTitle>
            <CardDescription>Current order processing status</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-64 flex items-center justify-center">
                <Activity className="h-8 w-8 animate-pulse text-gray-400" />
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <RechartsPieChart>
                  <RechartsPieChart 
                    data={dashboardData?.orderStatus || []}
                    cx="50%" 
                    cy="50%" 
                    outerRadius={80}
                    dataKey="count"
                  >
                    {dashboardData?.orderStatus?.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </RechartsPieChart>
                  <Tooltip />
                  <Legend />
                </RechartsPieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Shipment Status
            </CardTitle>
            <CardDescription>Active shipment tracking</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-64 flex items-center justify-center">
                <Activity className="h-8 w-8 animate-pulse text-gray-400" />
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={dashboardData?.shipmentStatus || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="status" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tables Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest orders from WMS systems</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {isLoading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-12 bg-gray-100 rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                dashboardData?.recentOrders?.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <div className="font-medium">{order.customer}</div>
                      <div className="text-sm text-gray-500">#{order.id}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{formatCurrency(order.value)}</div>
                      <div className="text-sm">{getStatusBadge(order.status)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Shipments</CardTitle>
            <CardDescription>Current shipments from TMS systems</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {isLoading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-12 bg-gray-100 rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                dashboardData?.activeShipments?.map((shipment) => (
                  <div key={shipment.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <div className="font-medium">{shipment.route}</div>
                      <div className="text-sm text-gray-500">{shipment.carrier}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {shipment.eta}
                      </div>
                      <div className="text-sm">{getStatusBadge(shipment.status)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Footer */}
      {dashboardData?.lastUpdated && (
        <div className="text-center text-sm text-gray-500">
          Last updated: {formatTimestamp(dashboardData.lastUpdated)}
        </div>
      )}
    </div>
  );
}