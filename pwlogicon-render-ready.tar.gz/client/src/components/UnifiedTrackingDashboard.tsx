import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Truck, Activity, MapPin, Clock, Satellite, Wifi } from 'lucide-react';

interface UnifiedTrackingData {
  trucks: any[];
  shipments: any[];
  sources: string[];
  lastUpdated: string;
}

const UnifiedTrackingDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const { data: trackingData, isLoading, refetch } = useQuery<UnifiedTrackingData>({
    queryKey: ['/api/tracking/unified'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'GPS Simulation':
        return <Satellite className="h-4 w-4" />;
      case 'FourKites':
        return <Wifi className="h-4 w-4" />;
      case 'Project44':
        return <Activity className="h-4 w-4" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'GPS Simulation':
        return 'bg-blue-100 text-blue-800';
      case 'FourKites':
        return 'bg-green-100 text-green-800';
      case 'Project44':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'delivered':
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in transit':
      case 'moving':
        return 'bg-blue-100 text-blue-800';
      case 'out for delivery':
        return 'bg-orange-100 text-orange-800';
      case 'exception':
      case 'delayed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3">Loading unified tracking data...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Unified Logistics Tracking Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-blue-900">Active Trucks</span>
              </div>
              <div className="text-2xl font-bold text-blue-900 mt-2">
                {trackingData?.trucks.length || 0}
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-900">Active Shipments</span>
              </div>
              <div className="text-2xl font-bold text-green-900 mt-2">
                {trackingData?.shipments.length || 0}
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center gap-2">
                <Wifi className="h-5 w-5 text-purple-600" />
                <span className="font-semibold text-purple-900">Data Sources</span>
              </div>
              <div className="text-2xl font-bold text-purple-900 mt-2">
                {trackingData?.sources.length || 0}
              </div>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <span className="font-semibold text-orange-900">Last Update</span>
              </div>
              <div className="text-sm font-medium text-orange-900 mt-2">
                {trackingData?.lastUpdated ? new Date(trackingData.lastUpdated).toLocaleTimeString() : 'N/A'}
              </div>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="trucks">Trucks</TabsTrigger>
              <TabsTrigger value="shipments">Shipments</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Wifi className="h-5 w-5" />
                      Integrated Tracking Sources
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Satellite className="h-5 w-5 text-blue-600" />
                          <span className="font-medium">Live GPS</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800 border-green-300">
                          Active
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Wifi className="h-5 w-5 text-green-600" />
                          <span className="font-medium">FourKites</span>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                          Webhook
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Activity className="h-5 w-5 text-purple-600" />
                          <span className="font-medium">Project44</span>
                        </div>
                        <Badge className="bg-cyan-100 text-cyan-800 border-cyan-300">
                          API Sync
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      System Health
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                          <span className="font-medium">GPS Tracking</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800 border-green-300">
                          Operational
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                          <span className="font-medium">Webhook Integration</span>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                          Active
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                          <span className="font-medium">API Connections</span>
                        </div>
                        <Badge className="bg-purple-100 text-purple-800 border-purple-300">
                          Connected
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="trucks" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {trackingData?.trucks.map((truck, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Truck className="h-4 w-4 text-blue-600" />
                          <span className="font-semibold text-sm">{truck.truckId}</span>
                        </div>
                        <Badge className={getSourceColor(truck.source)}>
                          {truck.source}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Carrier:</span>
                          <span className="font-medium">{truck.carrierId}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Speed:</span>
                          <span className="font-medium">{truck.speed} mph</span>
                        </div>
                        {truck.status && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Status:</span>
                            <Badge className={getStatusColor(truck.status)} variant="outline">
                              {truck.status}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="shipments" className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-200">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="border border-gray-200 p-3 text-left">Shipment ID</th>
                      <th className="border border-gray-200 p-3 text-left">Status</th>
                      <th className="border border-gray-200 p-3 text-left">Carrier</th>
                      <th className="border border-gray-200 p-3 text-left">Source</th>
                      <th className="border border-gray-200 p-3 text-left">Last Update</th>
                      <th className="border border-gray-200 p-3 text-left">ETA</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trackingData?.shipments.map((shipment, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="border border-gray-200 p-3 font-mono text-sm">
                          {shipment.shipmentId}
                        </td>
                        <td className="border border-gray-200 p-3">
                          <Badge className={getStatusColor(shipment.status)}>
                            {shipment.status}
                          </Badge>
                        </td>
                        <td className="border border-gray-200 p-3 text-sm">
                          {shipment.carrier}
                        </td>
                        <td className="border border-gray-200 p-3">
                          <Badge className={getSourceColor(shipment.source)} variant="outline">
                            {shipment.source}
                          </Badge>
                        </td>
                        <td className="border border-gray-200 p-3 text-sm">
                          {shipment.lastUpdate ? new Date(shipment.lastUpdate).toLocaleString() : 'N/A'}
                        </td>
                        <td className="border border-gray-200 p-3 text-sm">
                          {shipment.estimatedArrival ? new Date(shipment.estimatedArrival).toLocaleString() : 'N/A'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 flex justify-between items-center">
            <Button onClick={() => refetch()} size="sm" variant="outline">
              <Activity className="h-4 w-4 mr-2" />
              Refresh Data
            </Button>
            
            <small className="text-gray-500">
              Unified tracking across {trackingData?.sources.length || 0} data sources
            </small>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UnifiedTrackingDashboard;