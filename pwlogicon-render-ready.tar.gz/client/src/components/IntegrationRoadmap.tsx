import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Clock, ArrowRight, Calendar, Users, Target } from "lucide-react";

interface Phase {
  name: string;
  duration: string;
  features: string[];
  status: 'completed' | 'in-progress' | 'planned';
  progress: number;
  startDate?: string;
  completionDate?: string;
}

interface IntegrationRoadmapProps {
  onStartPhase?: (phaseIndex: number) => void;
  onViewDetails?: (phaseIndex: number) => void;
}

export default function IntegrationRoadmap({ onStartPhase, onViewDetails }: IntegrationRoadmapProps) {
  const phases: Phase[] = [
    {
      name: 'Phase 1: Core WMS Integration',
      duration: '2-3 months',
      features: [
        'Basic WMS connectivity',
        'Inventory synchronization', 
        'Order status tracking'
      ],
      status: 'completed',
      progress: 100,
      startDate: 'Jan 2024',
      completionDate: 'Mar 2024'
    },
    {
      name: 'Phase 2: TMS Integration',
      duration: '2-3 months',
      features: [
        'TMS connectivity',
        'Shipment creation and tracking',
        'Carrier management'
      ],
      status: 'in-progress',
      progress: 65,
      startDate: 'Apr 2024'
    },
    {
      name: 'Phase 3: Unified Workflow',
      duration: '3-4 months', 
      features: [
        'Integrated order processing',
        'Automated handoffs between WMS and TMS',
        'End-to-end visibility dashboard'
      ],
      status: 'planned',
      progress: 0
    },
    {
      name: 'Phase 4: Advanced Features',
      duration: '2-3 months',
      features: [
        'Predictive analytics',
        'Automated exception handling',
        'Advanced reporting'
      ],
      status: 'planned',
      progress: 0
    }
  ];

  const getStatusIcon = (status: Phase['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />;
      case 'in-progress':
        return <Clock className="h-5 w-5 text-blue-600" />;
      case 'planned':
        return <Target className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: Phase['status']) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-100 text-green-800">Completed</Badge>;
      case 'in-progress':
        return <Badge variant="default" className="bg-blue-100 text-blue-800">In Progress</Badge>;
      case 'planned':
        return <Badge variant="secondary">Planned</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Integration Roadmap</h2>
        <p className="text-gray-600">Phased approach to logistics systems integration</p>
      </div>

      {/* Roadmap Overview */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Implementation Timeline
          </CardTitle>
          <CardDescription>
            Strategic phased approach spanning 9-13 months for complete logistics integration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">1</div>
              <div className="text-sm text-gray-600">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">1</div>
              <div className="text-sm text-gray-600">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-400">2</div>
              <div className="text-sm text-gray-600">Planned</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">65%</div>
              <div className="text-sm text-gray-600">Overall Progress</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Phase Details */}
      <div className="space-y-4">
        {phases.map((phase, index) => (
          <Card key={index} className={`transition-all duration-200 hover:shadow-md ${
            phase.status === 'in-progress' ? 'border-blue-300 bg-blue-50/30' : ''
          }`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(phase.status)}
                  <div>
                    <CardTitle className="text-lg">{phase.name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-1">
                      <Clock className="h-4 w-4" />
                      {phase.duration}
                      {phase.startDate && (
                        <>
                          <span className="text-gray-300">•</span>
                          <span>Started {phase.startDate}</span>
                        </>
                      )}
                      {phase.completionDate && (
                        <>
                          <span className="text-gray-300">•</span>
                          <span>Completed {phase.completionDate}</span>
                        </>
                      )}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(phase.status)}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Progress Bar */}
                {phase.status !== 'planned' && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Progress</span>
                      <span className="font-medium">{phase.progress}%</span>
                    </div>
                    <Progress value={phase.progress} className="h-2" />
                  </div>
                )}

                {/* Features List */}
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Key Features</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    {phase.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center gap-2 text-sm">
                        {phase.status === 'completed' ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                        ) : phase.status === 'in-progress' ? (
                          <Clock className="h-4 w-4 text-blue-600" />
                        ) : (
                          <div className="h-4 w-4 rounded-full border-2 border-gray-300" />
                        )}
                        <span className={phase.status === 'completed' ? 'text-green-700' : 'text-gray-700'}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  {phase.status === 'planned' && onStartPhase && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onStartPhase(index)}
                    >
                      Start Phase
                    </Button>
                  )}
                  {onViewDetails && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => onViewDetails(index)}
                    >
                      View Details
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Next Steps */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Next Steps
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-blue-600" />
              <span>Complete TMS carrier management integration (Phase 2)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-gray-400" />
              <span>Begin unified workflow development planning (Phase 3)</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Target className="h-4 w-4 text-gray-400" />
              <span>Conduct stakeholder review for advanced features roadmap (Phase 4)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}