import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CustomReportBuilderProps {
  sid?: string;
}

const CustomReportBuilder: React.FC<CustomReportBuilderProps> = ({ sid }) => {
  const { toast } = useToast();
  const [type, setType] = useState('performance');
  const [format, setFormat] = useState('json');
  const [filters, setFilters] = useState({ region: '', service: '' });
  const [loading, setLoading] = useState(false);

  const generateReport = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/report/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, filters, format })
      });

      if (!response.ok) {
        throw new Error('Failed to generate report');
      }

      if (format === 'json') {
        const data = await response.json();
        toast({ 
          title: "Report Generated", 
          description: `${data.title} is ready with ${data.data.length} records` 
        });
      } else {
        // Handle file download
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `report_${type}_${new Date().toISOString().split('T')[0]}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({ 
          title: "Download Started", 
          description: `Your ${format.toUpperCase()} report is downloading` 
        });
      }
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Failed to generate report", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="report-builder">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Custom Report Builder
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="type">Report Type</Label>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger>
              <SelectValue placeholder="Select report type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="performance">Performance Analysis</SelectItem>
              <SelectItem value="cost">Cost Analysis</SelectItem>
              <SelectItem value="compliance">Compliance Summary</SelectItem>
              <SelectItem value="lane_performance">Lane Performance</SelectItem>
              <SelectItem value="carrier_analytics">Carrier Analytics</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="region">Region Filter</Label>
            <Select value={filters.region} onValueChange={(value) => setFilters(prev => ({ ...prev, region: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="All Regions" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Regions</SelectItem>
                <SelectItem value="midwest">Midwest</SelectItem>
                <SelectItem value="south">South</SelectItem>
                <SelectItem value="west">West</SelectItem>
                <SelectItem value="northeast">Northeast</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="service">Service Filter</Label>
            <Select value={filters.service} onValueChange={(value) => setFilters(prev => ({ ...prev, service: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="All Services" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Services</SelectItem>
                <SelectItem value="ftl">Full Truckload</SelectItem>
                <SelectItem value="ltl">Less Than Truckload</SelectItem>
                <SelectItem value="reefer">Refrigerated</SelectItem>
                <SelectItem value="intermodal">Intermodal</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="format">Output Format</Label>
          <Select value={format} onValueChange={setFormat}>
            <SelectTrigger>
              <SelectValue placeholder="Select format" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="json">View in App</SelectItem>
              <SelectItem value="csv">CSV Download</SelectItem>
              <SelectItem value="pdf">PDF Download</SelectItem>
              <SelectItem value="excel">Excel Download</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button 
          onClick={generateReport} 
          disabled={loading}
          className="w-full"
        >
          <Download className="h-4 w-4 mr-2" />
          {loading ? "Generating..." : "Generate Report"}
        </Button>
      </CardContent>
    </Card>
  );
};

export default CustomReportBuilder;