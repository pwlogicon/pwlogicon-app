import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { 
  MapPin, 
  TrendingUp, 
  Truck, 
  Package, 
  DollarSign, 
  Clock,
  Target,
  Activity,
  BarChart3,
  Map,
  Layers
} from 'lucide-react';
import exampleImage from '@assets/image_1754108285611.png';

const FullDashboardMockup: React.FC = () => {
  const [activeView, setActiveView] = useState('overview');

  // Current vs Target KPI data matching the provided image
  const kpiData = [
    { 
      metric: 'On-Time Delivery %', 
      current: 92.3, 
      target: 95, 
      unit: '%',
      status: 'warning'
    },
    { 
      metric: 'Lane Coverage', 
      current: 87.8, 
      target: 90, 
      unit: '%',
      status: 'warning'
    },
    { 
      metric: 'Cost per Mile ($)', 
      current: 3.47, 
      target: 3.20, 
      unit: '$',
      status: 'warning'
    },
    { 
      metric: 'Detention Hours', 
      current: 4.2, 
      target: 3.0, 
      unit: 'hrs',
      status: 'critical'
    },
    { 
      metric: 'Empty Miles %', 
      current: 12.1, 
      target: 10.0, 
      unit: '%',
      status: 'critical'
    },
    { 
      metric: 'Capacity Utilization %', 
      current: 78.5, 
      target: 85, 
      unit: '%',
      status: 'warning'
    },
    { 
      metric: 'Partner Compliance %', 
      current: 89.7, 
      target: 95, 
      unit: '%',
      status: 'warning'
    }
  ];

  // Lane heat map data for geographic visualization
  const laneHeatMapData = [
    { lane: 'LA-Chicago', volume: 245, density: 'high', cost: 2.87, performance: 94.2 },
    { lane: 'NY-Atlanta', volume: 189, density: 'medium', cost: 2.34, performance: 91.8 },
    { lane: 'Dallas-Phoenix', volume: 167, density: 'medium', cost: 3.12, performance: 89.3 },
    { lane: 'Miami-Charlotte', volume: 134, density: 'low', cost: 2.91, performance: 87.1 },
    { lane: 'Seattle-Denver', volume: 98, density: 'low', cost: 3.45, performance: 92.7 },
    { lane: 'Houston-Memphis', volume: 156, density: 'medium', cost: 2.67, performance: 95.1 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-600 bg-green-50';
      case 'warning': return 'text-yellow-600 bg-yellow-50';
      case 'critical': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getDensityColor = (density: string) => {
    switch (density) {
      case 'high': return '#FF4444';
      case 'medium': return '#FFA500';
      case 'low': return '#90EE90';
      default: return '#CCCCCC';
    }
  };

  return (
    <div className="space-y-6 p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">PWLoGiCon Master Dashboard</h1>
          <p className="text-gray-600">Comprehensive logistics intelligence platform</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="bg-green-50 text-green-700">
            Live Data
          </Badge>
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            Real-time Analytics
          </Badge>
        </div>
      </div>

      <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">KPI Overview</TabsTrigger>
          <TabsTrigger value="heatmap">Lane Heat Map</TabsTrigger>
          <TabsTrigger value="integration">System Integration</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Reference Image Display */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-6 w-6 text-orange-500" />
                Current vs Target KPI Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <img 
                  src={exampleImage} 
                  alt="PWLoGiCon Master Dashboard KPI View"
                  className="w-full max-w-4xl mx-auto border rounded-lg shadow-lg"
                />
              </div>
              
              {/* Interactive KPI Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                {kpiData.map((kpi, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">{kpi.metric}</h4>
                        <Badge variant="outline" className={getStatusColor(kpi.status)}>
                          {kpi.status}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-xs text-gray-600">Current:</span>
                          <span className="text-sm font-bold text-orange-600">
                            {kpi.current}{kpi.unit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-xs text-gray-600">Target:</span>
                          <span className="text-sm font-bold text-orange-500">
                            {kpi.target}{kpi.unit}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-orange-500 h-2 rounded-full transition-all duration-500"
                            style={{ 
                              width: `${Math.min((kpi.current / kpi.target) * 100, 100)}%` 
                            }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Performance Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-500" />
                Performance Trends (30 Days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={[
                  { date: 'Week 1', onTime: 89.2, cost: 3.52, utilization: 76.3 },
                  { date: 'Week 2', onTime: 91.1, cost: 3.48, utilization: 77.8 },
                  { date: 'Week 3', onTime: 92.8, cost: 3.45, utilization: 78.9 },
                  { date: 'Week 4', onTime: 92.3, cost: 3.47, utilization: 78.5 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="onTime" fill="#FF8C00" name="On-Time %" />
                  <Line type="monotone" dataKey="cost" stroke="#FF6B35" strokeWidth={3} name="Cost/Mile" />
                  <Area type="monotone" dataKey="utilization" fill="#FFA500" fillOpacity={0.3} name="Utilization %" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="heatmap" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Map className="h-6 w-6 text-red-500" />
                Lane Density Heat Map Visualization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Heat Map Data Table */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Lane Performance Matrix</h3>
                  <div className="space-y-3">
                    {laneHeatMapData.map((lane, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: getDensityColor(lane.density) }}
                          ></div>
                          <div>
                            <h4 className="font-medium">{lane.lane}</h4>
                            <p className="text-sm text-gray-600">{lane.volume} shipments</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">${lane.cost}/mile</p>
                          <p className="text-sm text-gray-600">{lane.performance}% performance</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Geographic Visualization Mockup */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Geographic Distribution</h3>
                  <div className="bg-blue-50 p-6 rounded-lg border-2 border-dashed border-blue-200 text-center">
                    <MapPin className="h-12 w-12 text-blue-500 mx-auto mb-4" />
                    <h4 className="font-medium text-blue-900 mb-2">Interactive Heat Map</h4>
                    <p className="text-sm text-blue-700 mb-4">
                      Real-time visualization of logistics lanes with density analysis, 
                      route optimization, and performance metrics overlay.
                    </p>
                    <div className="flex justify-center space-x-4 text-xs">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                        High Density
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
                        Medium Density
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                        Low Density
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integration" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Package className="h-5 w-5 text-purple-500" />
                  MacroPoint Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="mb-3 bg-green-100 text-green-800">Connected</Badge>
                <p className="text-sm text-gray-600 mb-3">
                  Carrier compliance and broker operations for 3PLs and freight brokers.
                </p>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span>ELD Compliance:</span>
                    <span className="font-medium">99.3%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>On-Time Rate:</span>
                    <span className="font-medium">96.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Loads:</span>
                    <span className="font-medium">247</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Layers className="h-5 w-5 text-blue-500" />
                  OTM Control Tower
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="mb-3 bg-green-100 text-green-800">Connected</Badge>
                <p className="text-sm text-gray-600 mb-3">
                  Enterprise control tower for cost-to-serve analytics and financial planning.
                </p>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span>Total Spend:</span>
                    <span className="font-medium">$12.8M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Carriers:</span>
                    <span className="font-medium">347</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cost Savings:</span>
                    <span className="font-medium">18.3%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-orange-500" />
                  Power BI Analytics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="mb-3 bg-green-100 text-green-800">Connected</Badge>
                <p className="text-sm text-gray-600 mb-3">
                  Cross-platform insights for consulting and hybrid operations.
                </p>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span>Data Sources:</span>
                    <span className="font-medium">4 Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sync Health:</span>
                    <span className="font-medium">94.7%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Insights:</span>
                    <span className="font-medium">12 Active</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-green-500" />
                  Optimization Opportunities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border-l-4 border-green-500 bg-green-50 rounded-r-lg">
                    <h4 className="font-medium text-green-900">Route Consolidation</h4>
                    <p className="text-sm text-green-700 mt-1">
                      West Coast Distribution: Consolidate 47 LTL shipments into 18 FTL loads
                    </p>
                    <p className="text-xs text-green-600 mt-2">Potential savings: $234,750</p>
                  </div>
                  <div className="p-4 border-l-4 border-blue-500 bg-blue-50 rounded-r-lg">
                    <h4 className="font-medium text-blue-900">Carrier Performance</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      3 carriers showing declining performance - renegotiation recommended
                    </p>
                    <p className="text-xs text-blue-600 mt-2">Impact: 12% cost reduction potential</p>
                  </div>
                  <div className="p-4 border-l-4 border-orange-500 bg-orange-50 rounded-r-lg">
                    <h4 className="font-medium text-orange-900">Capacity Planning</h4>
                    <p className="text-sm text-orange-700 mt-1">
                      Q4 peak season requires 25% additional capacity based on trends
                    </p>
                    <p className="text-xs text-orange-600 mt-2">Confidence: 91%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-purple-500" />
                  Real-time Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div>
                      <h5 className="font-medium text-red-900">Critical: Detention Hours</h5>
                      <p className="text-sm text-red-700">Above target by 40%</p>
                    </div>
                    <Badge variant="destructive">High</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div>
                      <h5 className="font-medium text-yellow-900">Warning: Empty Miles</h5>
                      <p className="text-sm text-yellow-700">21% above target</p>
                    </div>
                    <Badge variant="outline" className="border-yellow-600 text-yellow-700">Medium</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div>
                      <h5 className="font-medium text-blue-900">Info: Geofencing Alert</h5>
                      <p className="text-sm text-blue-700">Truck TRK-1000 entered Chicago DC</p>
                    </div>
                    <Badge variant="outline" className="border-blue-600 text-blue-700">Info</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FullDashboardMockup;