import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Navigation, AlertTriangle, CheckCircle, RefreshCw, Truck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface GPSPosition {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
}

interface TrackingStatus {
  isActive: boolean;
  lastUpdate: string | null;
  totalUpdates: number;
  errors: number;
}

const LiveGPSTracker: React.FC = () => {
  const { toast } = useToast();
  const [truckId, setTruckId] = useState('TRK-1001');
  const [carrierId, setCarrierId] = useState('CARRIER-501');
  const [currentPosition, setCurrentPosition] = useState<GPSPosition | null>(null);
  const [trackingStatus, setTrackingStatus] = useState<TrackingStatus>({
    isActive: false,
    lastUpdate: null,
    totalUpdates: 0,
    errors: 0
  });
  const [permissionStatus, setPermissionStatus] = useState<'unknown' | 'granted' | 'denied'>('unknown');
  const [geofenceAlerts, setGeofenceAlerts] = useState<any[]>([]);
  const watchIdRef = useRef<number | null>(null);

  // Check geolocation permission status
  useEffect(() => {
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        setPermissionStatus(result.state as 'granted' | 'denied');
      });
    }
  }, []);

  const updateLocation = async (position: GeolocationPosition) => {
    const pos: GPSPosition = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: position.timestamp
    };

    setCurrentPosition(pos);

    try {
      const response = await fetch('/api/tracking/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          truckId,
          lat: pos.latitude,
          lng: pos.longitude,
          carrierId,
          heading: position.coords.heading || 0,
          speed: position.coords.speed || 0,
          timestamp: new Date(pos.timestamp).toISOString()
        })
      });

      if (response.ok) {
        setTrackingStatus(prev => ({
          ...prev,
          lastUpdate: new Date().toISOString(),
          totalUpdates: prev.totalUpdates + 1
        }));

        // Check for geofence alerts
        await checkGeofenceAlerts(pos.latitude, pos.longitude);
      } else {
        throw new Error('Failed to update location');
      }
    } catch (error) {
      console.error('Location update error:', error);
      setTrackingStatus(prev => ({
        ...prev,
        errors: prev.errors + 1
      }));
      
      toast({
        title: "Update Failed",
        description: "Failed to send location update to server",
        variant: "destructive"
      });
    }
  };

  const checkGeofenceAlerts = async (lat: number, lng: number) => {
    try {
      const response = await fetch('/api/geofences/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ truckId, lat, lng })
      });

      if (response.ok) {
        const data = await response.json();
        const inGeofence = data.results.filter((result: any) => result.inGeofence);
        
        if (inGeofence.length > 0) {
          setGeofenceAlerts(inGeofence);
          toast({
            title: "Geofence Alert",
            description: `Currently in ${inGeofence.length} geofenced area(s)`,
          });
        } else {
          setGeofenceAlerts([]);
        }
      }
    } catch (error) {
      console.error('Geofence check error:', error);
    }
  };

  const handleError = (error: GeolocationPositionError) => {
    console.warn('Geolocation error:', error);
    setTrackingStatus(prev => ({
      ...prev,
      errors: prev.errors + 1
    }));

    let message = 'Unknown location error';
    switch (error.code) {
      case error.PERMISSION_DENIED:
        message = 'Location access denied by user';
        setPermissionStatus('denied');
        break;
      case error.POSITION_UNAVAILABLE:
        message = 'Location information unavailable';
        break;
      case error.TIMEOUT:
        message = 'Location request timed out';
        break;
    }

    toast({
      title: "Location Error",
      description: message,
      variant: "destructive"
    });
  };

  const startTracking = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Not Supported",
        description: "Geolocation is not supported by this browser",
        variant: "destructive"
      });
      return;
    }

    const options: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 5000
    };

    try {
      watchIdRef.current = navigator.geolocation.watchPosition(
        updateLocation,
        handleError,
        options
      );

      setTrackingStatus(prev => ({
        ...prev,
        isActive: true
      }));

      toast({
        title: "Tracking Started",
        description: `Live GPS tracking enabled for ${truckId}`,
      });
    } catch (error) {
      console.error('Failed to start tracking:', error);
      toast({
        title: "Tracking Failed",
        description: "Could not start GPS tracking",
        variant: "destructive"
      });
    }
  };

  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    setTrackingStatus(prev => ({
      ...prev,
      isActive: false
    }));

    toast({
      title: "Tracking Stopped",
      description: "GPS tracking has been disabled",
    });
  };

  const formatCoordinate = (coord: number, precision: number = 6) => {
    return coord.toFixed(precision);
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Navigation className="h-5 w-5" />
            Live GPS Tracker
            {trackingStatus.isActive && (
              <Badge variant="default" className="animate-pulse">
                <CheckCircle className="h-3 w-3 mr-1" />
                Active
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="truckId">Truck ID</Label>
              <Input
                id="truckId"
                value={truckId}
                onChange={(e) => setTruckId(e.target.value)}
                disabled={trackingStatus.isActive}
                placeholder="TRK-1001"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="carrierId">Carrier ID</Label>
              <Input
                id="carrierId"
                value={carrierId}
                onChange={(e) => setCarrierId(e.target.value)}
                disabled={trackingStatus.isActive}
                placeholder="CARRIER-501"
              />
            </div>
          </div>

          <div className="flex gap-2">
            {!trackingStatus.isActive ? (
              <Button onClick={startTracking} className="flex-1">
                <MapPin className="h-4 w-4 mr-2" />
                Start Live Tracking
              </Button>
            ) : (
              <Button onClick={stopTracking} variant="destructive" className="flex-1">
                <RefreshCw className="h-4 w-4 mr-2" />
                Stop Tracking
              </Button>
            )}
          </div>

          {permissionStatus === 'denied' && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Location permission denied. Please enable location access in your browser settings.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {trackingStatus.isActive && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Current Position</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {currentPosition ? (
                <>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Latitude</p>
                      <p className="font-mono">{formatCoordinate(currentPosition.latitude)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Longitude</p>
                      <p className="font-mono">{formatCoordinate(currentPosition.longitude)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Accuracy</p>
                      <p className="font-mono">{currentPosition.accuracy.toFixed(0)}m</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Last Update</p>
                      <p className="font-mono">{formatTimestamp(new Date(currentPosition.timestamp).toISOString())}</p>
                    </div>
                  </div>
                </>
              ) : (
                <p className="text-gray-500">Waiting for GPS signal...</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Tracking Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Total Updates</p>
                  <p className="text-2xl font-bold text-green-600">{trackingStatus.totalUpdates}</p>
                </div>
                <div>
                  <p className="text-gray-600">Errors</p>
                  <p className="text-2xl font-bold text-red-600">{trackingStatus.errors}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-gray-600">Success Rate</p>
                  <p className="text-lg font-semibold">
                    {trackingStatus.totalUpdates > 0 
                      ? ((trackingStatus.totalUpdates / (trackingStatus.totalUpdates + trackingStatus.errors)) * 100).toFixed(1)
                      : 0}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {geofenceAlerts.length > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Truck className="h-5 w-5" />
              Geofence Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {geofenceAlerts.map((alert, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-white rounded border">
                  <div>
                    <p className="font-medium text-blue-900">{alert.name}</p>
                    <p className="text-sm text-blue-700">{alert.type}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-blue-600">{alert.distance} mi from center</p>
                    <Badge variant="default" className="text-xs">
                      Inside Zone
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default LiveGPSTracker;