import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip } from "@/components/ui/tooltip";
import { getContextualInsight, getRandomInsight } from "@/utils/logisticsInsights";
import { Truck, Search, Clock, DollarSign, Building, User, CheckCircle } from "lucide-react";

interface OpportunityCardProps {
  opportunity: {
    id: string;
    type: string;
    serviceType: string;
    origin: string;
    destination: string;
    volume?: string;
    urgency?: string;
    pricingRange?: string;
    description: string;
    userRole: string;
    userCompanyName: string;
    userFirstName: string;
    userLastName: string;
    userEmail: string;
    userVerified: boolean;
    createdAt: string;
  };
  onViewMatches?: (opportunityId: string) => void;
}

export default function OpportunityCard({ opportunity, onViewMatches }: OpportunityCardProps) {
  const isCapacityOffer = opportunity.type === "capacity_offer";
  const isUrgent = opportunity.urgency === "Urgent";
  
  const serviceTypeLabels: Record<string, string> = {
    ftl: "Full Truckload",
    ltl: "Less Than Truckload", 
    reefer: "Refrigerated",
    intermodal: "Intermodal",
    drayage: "Drayage"
  };

  return (
    <Card className="mb-4">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            {isCapacityOffer ? (
              <Truck className="h-5 w-5 text-blue-600" />
            ) : (
              <Search className="h-5 w-5 text-green-600" />
            )}
            <CardTitle className="text-lg">
              {isCapacityOffer ? "Offering" : "Needing"} 
              <Tooltip content={getContextualInsight(opportunity.serviceType, `${opportunity.origin} to ${opportunity.destination}`, opportunity.urgency)}>
                <span className="underline decoration-dotted cursor-help ml-1">
                  {serviceTypeLabels[opportunity.serviceType] || opportunity.serviceType}
                </span>
              </Tooltip>
            </CardTitle>
            {isUrgent && (
              <Tooltip content={getRandomInsight('capacity')}>
                <Badge variant="destructive" className="ml-2 cursor-help">
                  <Clock className="h-3 w-3 mr-1" />
                Urgent
                </Badge>
              </Tooltip>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onViewMatches?.(opportunity.id)}
          >
            View Matches
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {/* Route Information */}
        <div className="flex items-center text-sm text-gray-600">
          <span className="font-medium">From</span>
          <Badge variant="outline" className="mx-2">{opportunity.origin}</Badge>
          <span className="font-medium">to</span>
          <Badge variant="outline" className="mx-2">{opportunity.destination}</Badge>
        </div>

        {/* Volume and Pricing */}
        <div className="flex gap-4 text-sm">
          {opportunity.volume && (
            <Tooltip content={getRandomInsight('capacity')}>
              <div className="flex items-center gap-1 cursor-help">
                <span className="font-medium">Volume:</span>
                <span>{opportunity.volume}</span>
              </div>
            </Tooltip>
          )}
          {opportunity.pricingRange && (
            <Tooltip content={getRandomInsight('cost')}>
              <div className="flex items-center gap-1 cursor-help">
                <DollarSign className="h-4 w-4 text-green-600" />
                <span>{opportunity.pricingRange}</span>
              </div>
            </Tooltip>
          )}
        </div>

        {/* Description */}
        {opportunity.description && (
          <p className="text-sm text-gray-700 bg-gray-50 p-2 rounded">
            {opportunity.description}
          </p>
        )}

        {/* User Information */}
        <div className="border-t pt-3 mt-3">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Building className="h-4 w-4 text-gray-500" />
              <span className="font-medium">{opportunity.userCompanyName}</span>
              <Badge variant="secondary" className="text-xs">
                {opportunity.userRole}
              </Badge>
              {opportunity.userVerified && (
                <CheckCircle className="h-4 w-4 text-green-500" />
              )}
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <User className="h-4 w-4" />
              <span>{opportunity.userFirstName} {opportunity.userLastName}</span>
            </div>
          </div>
        </div>

        {/* Posted Date */}
        <div className="text-xs text-gray-400">
          Posted {new Date(opportunity.createdAt).toLocaleDateString()}
        </div>
      </CardContent>
    </Card>
  );
}