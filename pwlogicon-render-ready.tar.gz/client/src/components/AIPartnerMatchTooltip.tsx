import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Brain,
  TrendingUp,
  MapPin,
  Clock,
  Star,
  Zap,
  Target,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from "lucide-react";

interface MatchInsight {
  factor: string;
  score: number;
  explanation: string;
  icon: React.ComponentType<any>;
  color: string;
}

interface AIPartnerMatchTooltipProps {
  partnerMatch: {
    id: string;
    companyName: string;
    matchScore: number;
    confidence: number;
    reasoning?: string;
    serviceCompatibility?: number;
    regionalCoverage?: number;
    capacityMatch?: number;
    urgencyAlignment?: number;
  };
  trigger: React.ReactNode;
  isVisible?: boolean;
}

export default function AIPartnerMatchTooltip({ 
  partnerMatch, 
  trigger, 
  isVisible = false 
}: AIPartnerMatchTooltipProps) {
  const [isOpen, setIsOpen] = useState(isVisible);
  const [animatedScore, setAnimatedScore] = useState(0);
  const [showInsights, setShowInsights] = useState(false);

  const matchInsights: MatchInsight[] = [
    {
      factor: "Service Compatibility",
      score: partnerMatch.serviceCompatibility || 85,
      explanation: "Perfect match for FTL services with specialized equipment capabilities",
      icon: Target,
      color: "text-blue-600"
    },
    {
      factor: "Regional Coverage", 
      score: partnerMatch.regionalCoverage || 92,
      explanation: "Excellent coverage in target lanes with established depot network",
      icon: MapPin,
      color: "text-green-600"
    },
    {
      factor: "Capacity Availability",
      score: partnerMatch.capacityMatch || 78,
      explanation: "Good availability with 15+ trucks available in your timeframe",
      icon: TrendingUp,
      color: "text-purple-600"
    },
    {
      factor: "Urgency Alignment",
      score: partnerMatch.urgencyAlignment || 88,
      explanation: "Well-suited for time-sensitive shipments with priority handling",
      icon: Clock,
      color: "text-orange-600"
    }
  ];

  useEffect(() => {
    if (isOpen) {
      // Animate the overall match score
      const timer = setTimeout(() => {
        let current = 0;
        const target = partnerMatch.matchScore;
        const increment = target / 30;
        
        const scoreAnimation = setInterval(() => {
          current += increment;
          if (current >= target) {
            setAnimatedScore(target);
            clearInterval(scoreAnimation);
            // Show insights after score animation
            setTimeout(() => setShowInsights(true), 500);
          } else {
            setAnimatedScore(Math.floor(current));
          }
        }, 50);
      }, 300);

      return () => clearTimeout(timer);
    } else {
      setAnimatedScore(0);
      setShowInsights(false);
    }
  }, [isOpen, partnerMatch.matchScore]);

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreBadgeColor = (score: number) => {
    if (score >= 85) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 70) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-red-100 text-red-800 border-red-200";
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 90) return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    if (confidence >= 70) return <AlertCircle className="h-4 w-4 text-yellow-500" />;
    return <AlertCircle className="h-4 w-4 text-red-500" />;
  };

  return (
    <TooltipProvider>
      <Tooltip open={isOpen} onOpenChange={setIsOpen}>
        <TooltipTrigger asChild>
          {trigger}
        </TooltipTrigger>
        <TooltipContent 
          side="right" 
          className="w-96 p-0 border-0 shadow-2xl"
          sideOffset={10}
        >
          <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-blue-50/30">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Brain className="h-5 w-5 text-blue-600" />
                    <Sparkles className="h-3 w-3 text-yellow-500 absolute -top-1 -right-1 animate-pulse" />
                  </div>
                  <CardTitle className="text-lg">AI Match Analysis</CardTitle>
                </div>
                <Badge className={getScoreBadgeColor(partnerMatch.matchScore)}>
                  {animatedScore}% Match
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                {partnerMatch.companyName}
              </p>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Overall Score Circle */}
              <div className="flex items-center justify-center">
                <div className="relative w-24 h-24">
                  <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="#e5e7eb"
                      strokeWidth="8"
                      fill="none"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${(animatedScore / 100) * 251.2} 251.2`}
                      className={`transition-all duration-1000 ease-out ${getScoreColor(animatedScore)}`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className={`text-xl font-bold ${getScoreColor(animatedScore)}`}>
                      {animatedScore}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Confidence Indicator */}
              <div className="flex items-center justify-center space-x-2 p-2 bg-gray-50 rounded-lg">
                {getConfidenceIcon(partnerMatch.confidence)}
                <span className="text-sm font-medium">
                  {partnerMatch.confidence}% AI Confidence
                </span>
                <Zap className="h-4 w-4 text-yellow-500" />
              </div>

              {/* Match Factors */}
              {showInsights && (
                <div className="space-y-3 animate-in slide-in-from-bottom-2 duration-500">
                  {matchInsights.map((insight, index) => (
                    <div 
                      key={insight.factor}
                      className="space-y-2 animate-in slide-in-from-left-2 duration-300"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <insight.icon className={`h-4 w-4 ${insight.color}`} />
                          <span className="text-sm font-medium">{insight.factor}</span>
                        </div>
                        <span className={`text-sm font-bold ${getScoreColor(insight.score)}`}>
                          {insight.score}%
                        </span>
                      </div>
                      <Progress 
                        value={insight.score} 
                        className="h-2"
                      />
                      <p className="text-xs text-muted-foreground pl-6">
                        {insight.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* AI Reasoning */}
              {showInsights && partnerMatch.reasoning && (
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 animate-in fade-in duration-700">
                  <div className="flex items-start space-x-2">
                    <Brain className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-blue-900 mb-1">AI Recommendation</p>
                      <p className="text-xs text-blue-700">
                        {partnerMatch.reasoning || "This partner shows excellent alignment with your requirements based on historical performance data and current capacity availability."}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Button */}
              {showInsights && (
                <div className="pt-2 animate-in slide-in-from-bottom duration-500">
                  <Button 
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    size="sm"
                  >
                    <Star className="h-4 w-4 mr-2" />
                    Connect with Partner
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}