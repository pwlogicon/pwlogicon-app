import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { 
  TruckIcon, 
  PackageIcon, 
  ClockIcon, 
  CheckCircle2Icon,
  AlertCircleIcon,
  RefreshCwIcon,
  MapPinIcon,
  BarChart3Icon,
  DollarSignIcon,
  TrendingUpIcon,
  Users2Icon
} from "lucide-react";

interface UnifiedDashboardData {
  overview: {
    ordersToProcess: number;
    inTransit: number;
    deliveredToday: number;
    inventoryValue: number;
    totalRevenue: number;
    successRate: number;
  };
  orderStatuses: {
    pending: number;
    picking: number;
    packed: number;
    readyToShip: number;
    shipped: number;
    delivered: number;
  };
  shipmentStatuses: {
    pending: number;
    pickedUp: number;
    inTransit: number;
    outForDelivery: number;
    delivered: number;
    exception: number;
  };
  recentOrders: Array<{
    id: string;
    customerName: string;
    status: string;
    priority: string;
    items: number;
    value: number;
    createdAt: string;
  }>;
  activeShipments: Array<{
    id: string;
    carrier: string;
    trackingNumber: string;
    origin: string;
    destination: string;
    status: string;
    estimatedDelivery: string;
    priority: string;
  }>;
  kpis: {
    averageDeliveryTime: number;
    costPerShipment: number;
    onTimeDeliveryRate: number;
    customerSatisfaction: number;
  };
}

interface UnifiedDashboardProps {
  onOrderAction?: (orderId: string, action: string) => void;
  onShipmentAction?: (shipmentId: string, action: string) => void;
  onRefreshData?: () => void;
}

export default function UnifiedDashboard({ 
  onOrderAction, 
  onShipmentAction, 
  onRefreshData 
}: UnifiedDashboardProps) {
  const [dateRange, setDateRange] = useState("today");
  const [autoRefresh, setAutoRefresh] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch unified dashboard data
  const { data: dashboardData, isLoading, error } = useQuery<UnifiedDashboardData>({
    queryKey: ['/api/unified-dashboard', dateRange],
    refetchInterval: autoRefresh ? 30000 : false, // Auto-refresh every 30s if enabled
  });

  // Refresh data mutation
  const refreshMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/unified-dashboard/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dateRange })
      });
      if (!response.ok) throw new Error('Failed to refresh data');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/unified-dashboard'] });
      toast({ title: "Data refreshed successfully" });
      onRefreshData?.();
    },
    onError: (error: any) => {
      toast({ 
        title: "Refresh failed", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'bg-yellow-500';
      case 'in-transit': 
      case 'picking': 
      case 'packed': return 'bg-blue-500';
      case 'delivered': 
      case 'ready-to-ship': return 'bg-green-500';
      case 'exception': 
      case 'delayed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'outline';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-8 bg-gray-200 rounded mb-2"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-red-600">
            <AlertCircleIcon className="h-5 w-5" />
            <span>Failed to load dashboard data</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Dashboard Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Unified Logistics Dashboard</h2>
          <p className="text-gray-600">Real-time visibility across warehouse and transportation operations</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={autoRefresh ? "bg-green-50 border-green-200" : ""}
          >
            <RefreshCwIcon className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
            Auto Refresh
          </Button>
          
          <Button
            onClick={() => refreshMutation.mutate()}
            disabled={refreshMutation.isPending}
            size="sm"
          >
            <RefreshCwIcon className={`h-4 w-4 mr-2 ${refreshMutation.isPending ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Orders to Process</p>
                <p className="text-2xl font-bold">{dashboardData?.overview.ordersToProcess || 0}</p>
              </div>
              <PackageIcon className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">In Transit</p>
                <p className="text-2xl font-bold">{dashboardData?.overview.inTransit || 0}</p>
              </div>
              <TruckIcon className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Delivered Today</p>
                <p className="text-2xl font-bold">{dashboardData?.overview.deliveredToday || 0}</p>
              </div>
              <CheckCircle2Icon className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Inventory Value</p>
                <p className="text-2xl font-bold">{formatCurrency(dashboardData?.overview.inventoryValue || 0)}</p>
              </div>
              <BarChart3Icon className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Revenue</p>
                <p className="text-2xl font-bold">{formatCurrency(dashboardData?.overview.totalRevenue || 0)}</p>
              </div>
              <DollarSignIcon className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold">{dashboardData?.overview.successRate || 0}%</p>
              </div>
              <TrendingUpIcon className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Distribution and KPIs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PackageIcon className="h-5 w-5" />
              Order Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {dashboardData?.orderStatuses && Object.entries(dashboardData.orderStatuses).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(status)}`}></div>
                  <span className="capitalize text-sm">{status.replace(/([A-Z])/g, ' $1')}</span>
                </div>
                <Badge variant="secondary">{count as number}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Shipment Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TruckIcon className="h-5 w-5" />
              Shipment Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {dashboardData?.shipmentStatuses && Object.entries(dashboardData.shipmentStatuses).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(status)}`}></div>
                  <span className="capitalize text-sm">{status.replace(/([A-Z])/g, ' $1')}</span>
                </div>
                <Badge variant="secondary">{count as number}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Performance KPIs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3Icon className="h-5 w-5" />
              Performance KPIs
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Avg Delivery Time</span>
                <span className="text-sm font-medium">{dashboardData?.kpis.averageDeliveryTime || 0}h</span>
              </div>
              <Progress value={(dashboardData?.kpis.averageDeliveryTime || 0) / 48 * 100} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Cost per Shipment</span>
                <span className="text-sm font-medium">{formatCurrency(dashboardData?.kpis.costPerShipment || 0)}</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">On-Time Delivery</span>
                <span className="text-sm font-medium">{dashboardData?.kpis.onTimeDeliveryRate || 0}%</span>
              </div>
              <Progress value={dashboardData?.kpis.onTimeDeliveryRate || 0} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm">Customer Satisfaction</span>
                <span className="text-sm font-medium">{dashboardData?.kpis.customerSatisfaction || 0}/5</span>
              </div>
              <Progress value={(dashboardData?.kpis.customerSatisfaction || 0) / 5 * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tables */}
      <Tabs defaultValue="orders" className="space-y-4">
        <TabsList>
          <TabsTrigger value="orders">Recent Orders</TabsTrigger>
          <TabsTrigger value="shipments">Active Shipments</TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
              <CardDescription>Latest orders requiring processing or attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dashboardData?.recentOrders?.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="font-medium">{order.customerName}</p>
                        <p className="text-sm text-gray-600">Order #{order.id}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={getPriorityColor(order.priority)}>{order.priority}</Badge>
                        <Badge variant="outline">{order.status}</Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatCurrency(order.value)}</p>
                      <p className="text-sm text-gray-600">{order.items} items</p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => onOrderAction?.(order.id, 'view')}
                      >
                        View
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => onOrderAction?.(order.id, 'process')}
                      >
                        Process
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipments">
          <Card>
            <CardHeader>
              <CardTitle>Active Shipments</CardTitle>
              <CardDescription>Shipments currently in transit or pending pickup</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dashboardData?.activeShipments?.map((shipment) => (
                  <div key={shipment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="font-medium">{shipment.carrier}</p>
                        <p className="text-sm text-gray-600">#{shipment.trackingNumber}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPinIcon className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">{shipment.origin} → {shipment.destination}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={getPriorityColor(shipment.priority)}>{shipment.priority}</Badge>
                      <Badge variant="outline">{shipment.status}</Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">ETA: {new Date(shipment.estimatedDelivery).toLocaleDateString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => onShipmentAction?.(shipment.id, 'track')}
                      >
                        Track
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => onShipmentAction?.(shipment.id, 'update')}
                      >
                        Update
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}