import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';

interface ComplianceData {
  carrierId: string;
  carrierName: string;
  region: string;
  mcNumber: string;
  dotCompliance: number;
  insuranceStatus: 'active' | 'expired' | 'pending';
  safetyRating: 'satisfactory' | 'conditional' | 'unsatisfactory';
  onTimeDelivery: number;
  documentCompliance: number;
  lastAudit: string;
  overallScore: number;
  lat: number;
  lng: number;
}

const mockComplianceData: ComplianceData[] = [
  {
    carrierId: 'CAR-001',
    carrierName: 'Swift Logistics LLC',
    region: 'Southwest',
    mcNumber: 'MC-123456',
    dotCompliance: 95,
    insuranceStatus: 'active',
    safetyRating: 'satisfactory',
    onTimeDelivery: 92,
    documentCompliance: 88,
    lastAudit: '2024-01-15',
    overallScore: 91,
    lat: 32.7767,
    lng: -96.7970
  },
  {
    carrierId: 'CAR-002',
    carrierName: 'Regional Transport Co',
    region: 'Midwest',
    mcNumber: 'MC-789012',
    dotCompliance: 78,
    insuranceStatus: 'pending',
    safetyRating: 'conditional',
    onTimeDelivery: 85,
    documentCompliance: 72,
    lastAudit: '2024-01-20',
    overallScore: 78,
    lat: 41.8781,
    lng: -87.6298
  },
  {
    carrierId: 'CAR-003',
    carrierName: 'Pacific Freight Systems',
    region: 'West Coast',
    mcNumber: 'MC-345678',
    dotCompliance: 97,
    insuranceStatus: 'active',
    safetyRating: 'satisfactory',
    onTimeDelivery: 96,
    documentCompliance: 94,
    lastAudit: '2024-01-10',
    overallScore: 95,
    lat: 34.0522,
    lng: -118.2437
  },
  {
    carrierId: 'CAR-004',
    carrierName: 'Eastern Express Inc',
    region: 'Northeast',
    mcNumber: 'MC-901234',
    dotCompliance: 82,
    insuranceStatus: 'active',
    safetyRating: 'satisfactory',
    onTimeDelivery: 89,
    documentCompliance: 86,
    lastAudit: '2024-01-25',
    overallScore: 85,
    lat: 40.7128,
    lng: -74.0060
  },
  {
    carrierId: 'CAR-005',
    carrierName: 'Southern Haulers',
    region: 'Southeast',
    mcNumber: 'MC-567890',
    dotCompliance: 68,
    insuranceStatus: 'expired',
    safetyRating: 'unsatisfactory',
    onTimeDelivery: 74,
    documentCompliance: 65,
    lastAudit: '2024-02-01',
    overallScore: 69,
    lat: 33.4484,
    lng: -84.3880
  },
  {
    carrierId: 'CAR-006',
    carrierName: 'Mountain Logistics',
    region: 'Mountain West',
    mcNumber: 'MC-112233',
    dotCompliance: 91,
    insuranceStatus: 'active',
    safetyRating: 'satisfactory',
    onTimeDelivery: 88,
    documentCompliance: 90,
    lastAudit: '2024-01-18',
    overallScore: 89,
    lat: 39.7392,
    lng: -104.9903
  }
];

const getComplianceColor = (score: number): string => {
  if (score >= 90) return 'bg-green-500';
  if (score >= 80) return 'bg-yellow-500';
  if (score >= 70) return 'bg-orange-500';
  return 'bg-red-500';
};

const getInsuranceIcon = (status: string) => {
  switch (status) {
    case 'active': return <CheckCircle className="h-4 w-4 text-green-600" />;
    case 'expired': return <XCircle className="h-4 w-4 text-red-600" />;
    case 'pending': return <Clock className="h-4 w-4 text-yellow-600" />;
    default: return <AlertTriangle className="h-4 w-4 text-gray-600" />;
  }
};

const getSafetyBadgeColor = (rating: string): string => {
  switch (rating) {
    case 'satisfactory': return 'bg-green-100 text-green-800';
    case 'conditional': return 'bg-yellow-100 text-yellow-800';
    case 'unsatisfactory': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

export const CarrierComplianceHeatmap: React.FC = () => {
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedMetric, setSelectedMetric] = useState<string>('overall');
  const [complianceData, setComplianceData] = useState<ComplianceData[]>(mockComplianceData);
  const [selectedCarrier, setSelectedCarrier] = useState<ComplianceData | null>(null);

  const regions = ['all', ...Array.from(new Set(complianceData.map(c => c.region)))];

  const filteredData = selectedRegion === 'all' 
    ? complianceData 
    : complianceData.filter(c => c.region === selectedRegion);

  const getMetricValue = (carrier: ComplianceData, metric: string): number => {
    switch (metric) {
      case 'overall': return carrier.overallScore;
      case 'dot': return carrier.dotCompliance;
      case 'delivery': return carrier.onTimeDelivery;
      case 'documents': return carrier.documentCompliance;
      default: return carrier.overallScore;
    }
  };

  const regionStats = regions.slice(1).map(region => {
    const regionCarriers = complianceData.filter(c => c.region === region);
    const avgScore = regionCarriers.reduce((sum, c) => sum + c.overallScore, 0) / regionCarriers.length;
    const activeInsurance = regionCarriers.filter(c => c.insuranceStatus === 'active').length;
    const satisfactoryRating = regionCarriers.filter(c => c.safetyRating === 'satisfactory').length;
    
    return {
      region,
      avgScore: Math.round(avgScore),
      carriers: regionCarriers.length,
      activeInsurance,
      satisfactoryRating,
      complianceRate: Math.round((satisfactoryRating / regionCarriers.length) * 100)
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row gap-4 mb-6">
        <Card className="flex-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Interactive Carrier Compliance Heatmap
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4 mb-4">
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Region:</label>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map(region => (
                      <SelectItem key={region} value={region}>
                        {region === 'all' ? 'All Regions' : region}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Metric:</label>
                <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="overall">Overall Score</SelectItem>
                    <SelectItem value="dot">DOT Compliance</SelectItem>
                    <SelectItem value="delivery">On-Time Delivery</SelectItem>
                    <SelectItem value="documents">Document Compliance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Compliance Legend */}
            <div className="flex flex-wrap gap-4 mb-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className="text-sm">Excellent (90-100%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                <span className="text-sm">Good (80-89%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-orange-500 rounded"></div>
                <span className="text-sm">Fair (70-79%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-500 rounded"></div>
                <span className="text-sm">Poor (&lt;70%)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="heatmap" className="space-y-4">
        <TabsList>
          <TabsTrigger value="heatmap">Compliance Heatmap</TabsTrigger>
          <TabsTrigger value="regional">Regional Analytics</TabsTrigger>
          <TabsTrigger value="details">Carrier Details</TabsTrigger>
        </TabsList>

        <TabsContent value="heatmap">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredData.map((carrier) => {
              const metricValue = getMetricValue(carrier, selectedMetric);
              const colorClass = getComplianceColor(metricValue);
              
              return (
                <Card 
                  key={carrier.carrierId}
                  className={`cursor-pointer transition-all hover:shadow-lg border-l-4 ${colorClass.replace('bg-', 'border-l-')}`}
                  onClick={() => setSelectedCarrier(carrier)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-sm truncate">{carrier.carrierName}</h3>
                        <p className="text-xs text-gray-600">{carrier.mcNumber}</p>
                      </div>
                      <div className={`w-8 h-8 rounded-full ${colorClass} flex items-center justify-center text-white text-xs font-bold`}>
                        {metricValue}
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span>Insurance:</span>
                        {getInsuranceIcon(carrier.insuranceStatus)}
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span>Safety:</span>
                        <Badge className={`text-xs ${getSafetyBadgeColor(carrier.safetyRating)}`}>
                          {carrier.safetyRating}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-600">
                        Region: {carrier.region}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="regional">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regionStats.map((stat) => (
              <Card key={stat.region}>
                <CardHeader>
                  <CardTitle className="text-lg">{stat.region}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Average Score:</span>
                      <div className={`px-2 py-1 rounded text-white text-sm font-bold ${getComplianceColor(stat.avgScore)}`}>
                        {stat.avgScore}%
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Total Carriers:</span>
                      <span className="font-semibold">{stat.carriers}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Active Insurance:</span>
                      <span className="font-semibold">{stat.activeInsurance}/{stat.carriers}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Compliance Rate:</span>
                      <span className="font-semibold">{stat.complianceRate}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="details">
          {selectedCarrier ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{selectedCarrier.carrierName}</span>
                  <Badge className={`${getSafetyBadgeColor(selectedCarrier.safetyRating)}`}>
                    {selectedCarrier.safetyRating}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Basic Information</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>MC Number:</span>
                          <span className="font-medium">{selectedCarrier.mcNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Region:</span>
                          <span className="font-medium">{selectedCarrier.region}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Last Audit:</span>
                          <span className="font-medium">{selectedCarrier.lastAudit}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Compliance Metrics</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Overall Score:</span>
                          <div className={`px-2 py-1 rounded text-white text-sm font-bold ${getComplianceColor(selectedCarrier.overallScore)}`}>
                            {selectedCarrier.overallScore}%
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">DOT Compliance:</span>
                          <div className={`px-2 py-1 rounded text-white text-sm font-bold ${getComplianceColor(selectedCarrier.dotCompliance)}`}>
                            {selectedCarrier.dotCompliance}%
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">On-Time Delivery:</span>
                          <div className={`px-2 py-1 rounded text-white text-sm font-bold ${getComplianceColor(selectedCarrier.onTimeDelivery)}`}>
                            {selectedCarrier.onTimeDelivery}%
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Document Compliance:</span>
                          <div className={`px-2 py-1 rounded text-white text-sm font-bold ${getComplianceColor(selectedCarrier.documentCompliance)}`}>
                            {selectedCarrier.documentCompliance}%
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-500">Select a carrier from the heatmap to view detailed compliance information.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};