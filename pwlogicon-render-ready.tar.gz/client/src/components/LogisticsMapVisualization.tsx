import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
// import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Map, 
  BarChart3, 
  TrendingUp, 
  MapPin, 
  Route,
  Zap,
  Layers,
  Maximize2,
  Filter
} from "lucide-react";

interface LaneData {
  id: string;
  origin: {
    city: string;
    state: string;
    coordinates: [number, number];
  };
  destination: {
    city: string;
    state: string;
    coordinates: [number, number];
  };
  density: "high" | "medium" | "low";
  matches: number;
  avgRate: number;
  serviceTypes: string[];
  lastActivity: string;
}

interface MapVisualizationProps {
  className?: string;
}

// Mock data for lane visualization
const mockLaneData: LaneData[] = [
  {
    id: "lane-1",
    origin: { city: "Chicago", state: "IL", coordinates: [41.8781, -87.6298] },
    destination: { city: "Dallas", state: "TX", coordinates: [32.7767, -96.7970] },
    density: "high",
    matches: 8,
    avgRate: 2400,
    serviceTypes: ["FTL", "LTL"],
    lastActivity: "2024-01-02T10:30:00Z"
  },
  {
    id: "lane-2",
    origin: { city: "Los Angeles", state: "CA", coordinates: [34.0522, -118.2437] },
    destination: { city: "Phoenix", state: "AZ", coordinates: [33.4484, -112.0740] },
    density: "high",
    matches: 12,
    avgRate: 1800,
    serviceTypes: ["FTL", "Reefer"],
    lastActivity: "2024-01-02T14:15:00Z"
  },
  {
    id: "lane-3",
    origin: { city: "Portland", state: "OR", coordinates: [45.5051, -122.6750] },
    destination: { city: "Denver", state: "CO", coordinates: [39.7392, -104.9903] },
    density: "low",
    matches: 1,
    avgRate: 2100,
    serviceTypes: ["FTL"],
    lastActivity: "2024-01-01T09:20:00Z"
  },
  {
    id: "lane-4",
    origin: { city: "Atlanta", state: "GA", coordinates: [33.7490, -84.3880] },
    destination: { city: "Miami", state: "FL", coordinates: [25.7617, -80.1918] },
    density: "medium",
    matches: 5,
    avgRate: 1650,
    serviceTypes: ["FTL", "LTL", "Reefer"],
    lastActivity: "2024-01-02T16:45:00Z"
  },
  {
    id: "lane-5",
    origin: { city: "New York", state: "NY", coordinates: [40.7128, -74.0060] },
    destination: { city: "Boston", state: "MA", coordinates: [42.3601, -71.0589] },
    density: "high",
    matches: 15,
    avgRate: 950,
    serviceTypes: ["LTL", "Express"],
    lastActivity: "2024-01-02T18:10:00Z"
  },
  {
    id: "lane-6",
    origin: { city: "Seattle", state: "WA", coordinates: [47.6062, -122.3321] },
    destination: { city: "San Francisco", state: "CA", coordinates: [37.7749, -122.4194] },
    density: "medium",
    matches: 4,
    avgRate: 1450,
    serviceTypes: ["FTL", "LTL"],
    lastActivity: "2024-01-02T12:30:00Z"
  }
];

export default function LogisticsMapVisualization({ className }: MapVisualizationProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [selectedDensity, setSelectedDensity] = useState<string>("all");
  const [selectedService, setSelectedService] = useState<string>("all");

  // Fetch lane analytics data
  const { data: laneData, isLoading } = useQuery({
    queryKey: ["/api/analytics/lanes"],
    select: (data) => data || mockLaneData,
  });

  const initializeMap = () => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Check if Leaflet is already loaded
    if ((window as any).L) {
      const L = (window as any).L;
      mapInstanceRef.current = L.map(mapRef.current).setView([39.8283, -98.5795], 4);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(mapInstanceRef.current);

      setIsMapLoaded(true);
      return;
    }

    // Load Leaflet CSS first
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(link);

    // Load Leaflet JavaScript
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.onload = () => {
      // Wait a bit for script to fully initialize
      setTimeout(() => {
        if (mapRef.current && (window as any).L) {
          const L = (window as any).L;
          try {
            mapInstanceRef.current = L.map(mapRef.current).setView([39.8283, -98.5795], 4);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              attribution: '&copy; OpenStreetMap contributors'
            }).addTo(mapInstanceRef.current);

            setIsMapLoaded(true);
          } catch (error) {
            console.error("Error initializing map:", error);
            setIsMapLoaded(false);
          }
        }
      }, 100);
    };
    script.onerror = () => {
      console.error("Failed to load Leaflet script");
      setIsMapLoaded(false);
    };
    document.head.appendChild(script);
  };

  const renderLanes = () => {
    if (!isMapLoaded || !mapInstanceRef.current || !laneData) return;

    const L = (window as any).L;
    
    // Clear existing layers
    mapInstanceRef.current.eachLayer((layer: any) => {
      if (layer.options && layer.options.attribution) return; // Keep tile layer
      mapInstanceRef.current.removeLayer(layer);
    });

    // Filter data based on selected filters
    const filteredData = laneData.filter((lane: LaneData) => {
      const densityMatch = selectedDensity === "all" || lane.density === selectedDensity;
      const serviceMatch = selectedService === "all" || lane.serviceTypes.includes(selectedService);
      return densityMatch && serviceMatch;
    });

    filteredData.forEach((lane: LaneData) => {
      const color = getDensityColor(lane.density);
      const weight = getDensityWeight(lane.density);

      // Draw lane polyline
      const polyline = L.polyline([lane.origin.coordinates, lane.destination.coordinates], {
        color,
        weight,
        opacity: 0.7
      }).addTo(mapInstanceRef.current);

      // Create popup content
      const popupContent = `
        <div style="font-family: system-ui; padding: 8px;">
          <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600;">
            ${lane.origin.city}, ${lane.origin.state} → ${lane.destination.city}, ${lane.destination.state}
          </h3>
          <div style="margin-bottom: 4px;">
            <strong>Density:</strong> 
            <span style="color: ${color}; font-weight: 600; text-transform: capitalize;">
              ${lane.density}
            </span>
          </div>
          <div style="margin-bottom: 4px;">
            <strong>Matches:</strong> ${lane.matches} in 30 days
          </div>
          <div style="margin-bottom: 4px;">
            <strong>Avg Rate:</strong> $${lane.avgRate.toLocaleString()}
          </div>
          <div style="margin-bottom: 4px;">
            <strong>Services:</strong> ${lane.serviceTypes.join(", ")}
          </div>
          <div style="font-size: 11px; color: #666;">
            Last activity: ${new Date(lane.lastActivity).toLocaleDateString()}
          </div>
        </div>
      `;

      polyline.bindPopup(popupContent);

      // Add origin and destination markers
      L.circleMarker(lane.origin.coordinates, {
        radius: getMarkerSize(lane.density),
        fillColor: color,
        color: "white",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8
      }).addTo(mapInstanceRef.current)
        .bindPopup(`<strong>${lane.origin.city}, ${lane.origin.state}</strong><br>Origin`);

      L.circleMarker(lane.destination.coordinates, {
        radius: getMarkerSize(lane.density),
        fillColor: color,
        color: "white",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8
      }).addTo(mapInstanceRef.current)
        .bindPopup(`<strong>${lane.destination.city}, ${lane.destination.state}</strong><br>Destination`);
    });
  };

  const getDensityColor = (density: string) => {
    switch (density) {
      case "high": return "#dc2626"; // red
      case "medium": return "#ea580c"; // orange
      case "low": return "#2563eb"; // blue
      default: return "#6b7280"; // gray
    }
  };

  const getDensityWeight = (density: string) => {
    switch (density) {
      case "high": return 8;
      case "medium": return 5;
      case "low": return 2;
      default: return 3;
    }
  };

  const getMarkerSize = (density: string) => {
    switch (density) {
      case "high": return 8;
      case "medium": return 6;
      case "low": return 4;
      default: return 5;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  useEffect(() => {
    initializeMap();
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (isMapLoaded && laneData) {
      renderLanes();
    }
  }, [isMapLoaded, laneData, selectedDensity, selectedService]);

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <div className="h-6 w-48 bg-gray-200 rounded animate-pulse" />
          <div className="h-4 w-64 bg-gray-200 rounded animate-pulse mt-2" />
        </CardHeader>
        <CardContent>
          <div className="h-96 w-full bg-gray-200 rounded animate-pulse" />
        </CardContent>
      </Card>
    );
  }

  const densityStats = laneData?.reduce((acc: any, lane: LaneData) => {
    acc[lane.density] = (acc[lane.density] || 0) + 1;
    return acc;
  }, {}) || {};

  const totalMatches = laneData?.reduce((sum: number, lane: LaneData) => sum + lane.matches, 0) || 0;
  const avgRate = laneData?.reduce((sum: number, lane: LaneData) => sum + lane.avgRate, 0) / (laneData?.length || 1) || 0;

  return (
    <div className={className}>
      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Lanes</p>
                <p className="text-2xl font-bold">{laneData?.length || 0}</p>
              </div>
              <Route className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Matches</p>
                <p className="text-2xl font-bold">{totalMatches}</p>
              </div>
              <Zap className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Rate</p>
                <p className="text-2xl font-bold">{formatCurrency(avgRate)}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">High-Density Lanes</p>
                <p className="text-2xl font-bold">{densityStats.high || 0}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Map Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Map className="h-5 w-5" />
                Logistics Lane Density Map
              </CardTitle>
              <CardDescription>
                Interactive visualization of shipping lanes, demand patterns, and market opportunities
              </CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Maximize2 className="h-4 w-4 mr-2" />
              Fullscreen
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            
            <Select value={selectedDensity} onValueChange={setSelectedDensity}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Density</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedService} onValueChange={setSelectedService}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Services</SelectItem>
                <SelectItem value="FTL">FTL</SelectItem>
                <SelectItem value="LTL">LTL</SelectItem>
                <SelectItem value="Reefer">Reefer</SelectItem>
                <SelectItem value="Express">Express</SelectItem>
              </SelectContent>
            </Select>

            {/* Legend */}
            <div className="flex items-center gap-4 ml-auto">
              <div className="flex items-center gap-1">
                <div className="w-4 h-1 bg-red-600 rounded"></div>
                <span className="text-xs">High Density</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-4 h-1 bg-orange-600 rounded"></div>
                <span className="text-xs">Medium</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-4 h-1 bg-blue-600 rounded"></div>
                <span className="text-xs">Low Density</span>
              </div>
            </div>
          </div>

          {/* Map Container */}
          <div 
            ref={mapRef} 
            className="w-full h-96 rounded-lg border bg-gray-50"
            style={{ minHeight: "400px" }}
          />
          
          {!isMapLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded-lg">
              <div className="text-center">
                <Layers className="h-12 w-12 text-gray-400 mx-auto mb-2 animate-pulse" />
                <p className="text-gray-600 mb-2">Loading interactive map...</p>
                <div className="w-32 h-2 bg-gray-200 rounded-full mx-auto">
                  <div className="h-2 bg-blue-500 rounded-full animate-pulse" style={{ width: '60%' }}></div>
                </div>
                <p className="text-xs text-gray-500 mt-2">Loading Leaflet.js mapping library</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lane Details Table */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg">Lane Performance Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Route</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Density</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Matches</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Avg Rate</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Services</th>
                  <th className="text-left py-3 px-2 text-sm font-medium text-gray-500">Last Activity</th>
                </tr>
              </thead>
              <tbody>
                {laneData?.map((lane: LaneData) => (
                  <tr key={lane.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-2 text-sm">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3 w-3 text-gray-400" />
                        {lane.origin.city}, {lane.origin.state} → {lane.destination.city}, {lane.destination.state}
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <Badge 
                        variant={lane.density === "high" ? "destructive" : lane.density === "medium" ? "default" : "secondary"}
                        className="capitalize"
                      >
                        {lane.density}
                      </Badge>
                    </td>
                    <td className="py-3 px-2 text-sm font-medium">{lane.matches}</td>
                    <td className="py-3 px-2 text-sm font-medium">{formatCurrency(lane.avgRate)}</td>
                    <td className="py-3 px-2 text-sm">{lane.serviceTypes.join(", ")}</td>
                    <td className="py-3 px-2 text-sm text-gray-600">
                      {new Date(lane.lastActivity).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}