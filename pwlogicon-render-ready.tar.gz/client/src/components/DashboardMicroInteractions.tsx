import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  Target,
  Clock,
  DollarSign,
  Truck,
  Package,
  AlertTriangle,
  CheckCircle2,
  ArrowUp,
  ArrowDown,
  Sparkles
} from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  previousValue: string | number;
  change: number;
  changeLabel: string;
  icon: React.ComponentType<any>;
  color: string;
  format?: 'currency' | 'percentage' | 'number' | 'time';
  animated?: boolean;
  showTrend?: boolean;
}

export function MetricCard({
  title,
  value,
  previousValue,
  change,
  changeLabel,
  icon: Icon,
  color,
  format = 'number',
  animated = true,
  showTrend = true
}: MetricCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [displayValue, setDisplayValue] = useState(0);
  const [showSparkle, setShowSparkle] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // Animate value counting up
  useEffect(() => {
    if (!animated) return;
    
    const numericValue = typeof value === 'string' ? parseFloat(value.replace(/[^0-9.-]/g, '')) : value;
    if (isNaN(numericValue)) return;

    let start = 0;
    const duration = 1500;
    const increment = numericValue / (duration / 16);
    
    const timer = setInterval(() => {
      start += increment;
      if (start >= numericValue) {
        setDisplayValue(numericValue);
        clearInterval(timer);
        // Show sparkle effect on completion
        setShowSparkle(true);
        setTimeout(() => setShowSparkle(false), 1000);
      } else {
        setDisplayValue(start);
      }
    }, 16);

    return () => clearInterval(timer);
  }, [value, animated]);

  const formatValue = (val: number) => {
    switch (format) {
      case 'currency':
        return `$${val.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
      case 'percentage':
        return `${val.toFixed(1)}%`;
      case 'time':
        return `${Math.round(val)}hrs`;
      default:
        return val.toLocaleString();
    }
  };

  const getTrendIcon = () => {
    if (change > 0) return <TrendingUp className="h-3 w-3 text-green-600" />;
    if (change < 0) return <TrendingDown className="h-3 w-3 text-red-600" />;
    return <Activity className="h-3 w-3 text-gray-600" />;
  };

  const getTrendColor = () => {
    if (change > 0) return "text-green-600";
    if (change < 0) return "text-red-600";
    return "text-gray-600";
  };

  // Pulse effect for significant changes
  const shouldPulse = Math.abs(change) > 10;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Card 
            ref={cardRef}
            className={`
              transition-all duration-300 cursor-pointer relative overflow-hidden
              ${isHovered ? 'shadow-lg scale-105 ring-2 ring-blue-200' : 'shadow-sm hover:shadow-md'}
              ${shouldPulse ? 'animate-pulse' : ''}
            `}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {/* Background gradient effect on hover */}
            <div 
              className={`
                absolute inset-0 bg-gradient-to-br from-transparent to-blue-50/20 
                transition-opacity duration-300
                ${isHovered ? 'opacity-100' : 'opacity-0'}
              `}
            />
            
            {/* Sparkle effect */}
            {showSparkle && (
              <div className="absolute top-2 right-2">
                <Sparkles className="h-4 w-4 text-yellow-500 animate-bounce" />
              </div>
            )}

            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative">
              <CardTitle className="text-sm font-medium">{title}</CardTitle>
              <Icon className={`h-4 w-4 ${color} transition-all duration-300 ${isHovered ? 'scale-110' : ''}`} />
            </CardHeader>
            
            <CardContent className="relative">
              <div className="flex items-baseline space-x-2">
                <div 
                  className={`
                    text-2xl font-bold transition-all duration-300
                    ${isHovered ? `${color} scale-105` : 'text-gray-900'}
                  `}
                >
                  {animated ? formatValue(displayValue) : value}
                </div>
                
                {showTrend && (
                  <div className={`
                    flex items-center space-x-1 transition-all duration-300
                    ${isHovered ? 'scale-110' : ''}
                  `}>
                    {getTrendIcon()}
                    <span className={`text-xs font-medium ${getTrendColor()}`}>
                      {Math.abs(change).toFixed(1)}%
                    </span>
                  </div>
                )}
              </div>
              
              <p className={`
                text-xs text-muted-foreground mt-1 transition-all duration-300
                ${isHovered ? 'text-gray-700' : ''}
              `}>
                {changeLabel}
              </p>

              {/* Progress bar for percentage-based metrics */}
              {format === 'percentage' && (
                <div className="mt-2">
                  <Progress 
                    value={displayValue} 
                    className={`h-1 transition-all duration-500 ${isHovered ? 'h-2' : ''}`}
                  />
                </div>
              )}
            </CardContent>

            {/* Hover overlay with additional info */}
            <div className={`
              absolute inset-0 bg-white/95 flex items-center justify-center
              transition-all duration-300 pointer-events-none
              ${isHovered ? 'opacity-100' : 'opacity-0'}
            `}>
              <div className="text-center space-y-1">
                <div className="text-xs text-gray-600">Previous Period</div>
                <div className="text-lg font-semibold text-gray-800">
                  {typeof previousValue === 'string' ? previousValue : formatValue(Number(previousValue))}
                </div>
                <div className="flex items-center justify-center space-x-1">
                  {change > 0 ? (
                    <ArrowUp className="h-3 w-3 text-green-600" />
                  ) : (
                    <ArrowDown className="h-3 w-3 text-red-600" />
                  )}
                  <span className={`text-xs font-medium ${getTrendColor()}`}>
                    {changeLabel}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </TooltipTrigger>
        
        <TooltipContent>
          <div className="space-y-1">
            <p className="font-medium">{title} Details</p>
            <p className="text-xs">Current: {value}</p>
            <p className="text-xs">Previous: {previousValue}</p>
            <p className="text-xs">Change: {change > 0 ? '+' : ''}{change.toFixed(1)}%</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface PulseNotificationProps {
  type: 'success' | 'warning' | 'info';
  message: string;
  show: boolean;
  onDismiss: () => void;
}

export function PulseNotification({ type, message, show, onDismiss }: PulseNotificationProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onDismiss();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [show, onDismiss]);

  const getIcon = () => {
    switch (type) {
      case 'success': return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'info': return <Zap className="h-4 w-4 text-blue-600" />;
    }
  };

  const getColorClasses = () => {
    switch (type) {
      case 'success': return "bg-green-50 border-green-200 text-green-800";
      case 'warning': return "bg-yellow-50 border-yellow-200 text-yellow-800";
      case 'info': return "bg-blue-50 border-blue-200 text-blue-800";
    }
  };

  if (!show) return null;

  return (
    <div className={`
      fixed top-4 right-4 p-3 rounded-lg border shadow-lg z-50
      ${getColorClasses()}
      animate-in slide-in-from-right-2 duration-300
    `}>
      <div className="flex items-center space-x-2">
        {getIcon()}
        <span className="text-sm font-medium">{message}</span>
        <button 
          onClick={onDismiss}
          className="ml-2 hover:opacity-70 transition-opacity"
        >
          ×
        </button>
      </div>
    </div>
  );
}

// Hook for managing dashboard micro-interactions
export function useDashboardMicroInteractions() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    type: 'success' | 'warning' | 'info';
    message: string;
    show: boolean;
  }>>([]);

  const showNotification = (type: 'success' | 'warning' | 'info', message: string) => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { id, type, message, show: true }]);
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, show: false } : n)
    );
    
    // Remove from array after animation
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 300);
  };

  return {
    notifications,
    showNotification,
    dismissNotification
  };
}