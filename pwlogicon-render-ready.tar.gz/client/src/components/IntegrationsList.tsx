import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Settings,
  Truck,
  Package,
  Database
} from "lucide-react";
import type { Integration } from "@shared/schema";

interface IntegrationsListProps {
  integrations: Integration[] | undefined;
  onSelectIntegration: (integration: Integration) => void;
}

export default function IntegrationsList({ integrations, onSelectIntegration }: IntegrationsListProps) {
  const queryClient = useQueryClient();

  const syncMutation = useMutation({
    mutationFn: async (integrationId: string) => {
      const response = await fetch(`/api/integrations/${integrationId}/sync`, {
        method: "POST"
      });
      if (!response.ok) throw new Error("Sync failed");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
    }
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "tms": return <Truck className="h-5 w-5 text-blue-600" />;
      case "wms": return <Package className="h-5 w-5 text-green-600" />;
      default: return <Database className="h-5 w-5 text-gray-600" />;
    }
  };

  if (!integrations || integrations.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      {integrations.map((integration) => (
        <Card key={integration.id} className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {getTypeIcon(integration.type)}
                <div>
                  <div className="flex items-center gap-2">
                    <strong className="text-lg">{integration.type.toUpperCase()}</strong>
                    <span className="text-muted-foreground">connected</span>
                    {integration.status === "active" ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    URL: <span className="font-mono text-xs">{integration.apiEndpoint || "Not configured"}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant={integration.status === "active" ? "default" : "secondary"}>
                  {integration.status}
                </Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => syncMutation.mutate(integration.id)}
                  disabled={syncMutation.isPending}
                >
                  <RefreshCw className={`h-4 w-4 mr-1 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                  Sync
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onSelectIntegration(integration)}
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {integration.errorMessage && (
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded text-sm text-red-600">
                <div className="flex items-center gap-2">
                  <XCircle className="h-4 w-4" />
                  <span className="font-medium">Connection Error:</span>
                </div>
                <p className="mt-1">{integration.errorMessage}</p>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}