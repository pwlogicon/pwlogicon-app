import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  UserCheck, 
  Building, 
  Truck, 
  BarChart3, 
  Shield, 
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRightLeft,
  Eye,
  Settings
} from "lucide-react";

interface RoleContext {
  id: string;
  userId: string;
  context: "provider" | "requester";
  isActive: boolean;
  lastSwitchedAt: string;
  preferences?: any;
  createdAt: string;
  updatedAt: string;
}

interface PerformanceMetrics {
  id: string;
  userId: string;
  roleContext: "provider" | "requester";
  onTimeDeliveryRate?: number;
  averageDeliveryTime?: number;
  customerSatisfactionScore?: number;
  costEfficiencyRating?: number;
  communicationRating?: number;
  overallRating: "excellent" | "good" | "fair" | "poor" | "unrated";
  totalShipments: number;
  totalRevenue?: number;
  averageOrderValue?: number;
  periodStart: string;
  periodEnd: string;
}

export default function DualRoleManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"provider" | "requester">("provider");

  // Fetch role contexts
  const { data: roleContexts, isLoading: contextsLoading } = useQuery({
    queryKey: ["/api/role-contexts"],
    enabled: !!user && user.role === "3pl",
  });

  // Fetch performance metrics for both roles
  const { data: performanceMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/performance-metrics"],
    enabled: !!user && user.role === "3pl",
  });

  // Role switching mutation
  const roleSwitchMutation = useMutation({
    mutationFn: async (context: "provider" | "requester") => {
      return apiRequest("/api/role-contexts/switch", {
        method: "POST",
        body: { context }
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/role-contexts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Role Switched",
        description: `Successfully switched to ${data.context} mode`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Switch Failed",
        description: error.message || "Failed to switch role context",
        variant: "destructive",
      });
    },
  });

  // Get current active context
  const currentContext = Array.isArray(roleContexts) 
    ? roleContexts.find((ctx: RoleContext) => ctx.isActive)
    : null;

  // Get metrics for current context
  const currentMetrics = Array.isArray(performanceMetrics)
    ? performanceMetrics.find((metrics: PerformanceMetrics) => 
        metrics.roleContext === (currentContext?.context || "provider")
      )
    : null;

  const providerMetrics = Array.isArray(performanceMetrics)
    ? performanceMetrics.find((m: PerformanceMetrics) => m.roleContext === "provider")
    : null;

  const requesterMetrics = Array.isArray(performanceMetrics)
    ? performanceMetrics.find((m: PerformanceMetrics) => m.roleContext === "requester")
    : null;

  // Only show for 3PL users
  if (!user || user.role !== "3pl") {
    return null;
  }

  const handleRoleSwitch = (context: "provider" | "requester") => {
    if (currentContext?.context === context) return;
    roleSwitchMutation.mutate(context);
  };

  const getRatingColor = (rating: string) => {
    switch (rating) {
      case "excellent": return "text-green-600 bg-green-100";
      case "good": return "text-blue-600 bg-blue-100";
      case "fair": return "text-yellow-600 bg-yellow-100";
      case "poor": return "text-red-600 bg-red-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const formatCurrency = (amount?: number) => {
    if (!amount) return "$0";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD"
    }).format(amount);
  };

  const formatPercentage = (value?: number) => {
    if (!value) return "0%";
    return `${value.toFixed(1)}%`;
  };

  if (contextsLoading || metricsLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-64" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Role Switch Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <ArrowRightLeft className="h-5 w-5" />
                Dual-Role Management
              </CardTitle>
              <CardDescription>
                Seamlessly switch between service provider and requester roles
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                Current: {currentContext?.context || "provider"}
              </Badge>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Button
              variant={currentContext?.context === "provider" ? "default" : "outline"}
              onClick={() => handleRoleSwitch("provider")}
              disabled={roleSwitchMutation.isPending}
              className="flex-1 gap-2"
            >
              <Building className="h-4 w-4" />
              Service Provider
              {currentContext?.context === "provider" && (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              )}
            </Button>
            <Button
              variant={currentContext?.context === "requester" ? "default" : "outline"}
              onClick={() => handleRoleSwitch("requester")}
              disabled={roleSwitchMutation.isPending}
              className="flex-1 gap-2"
            >
              <Users className="h-4 w-4" />
              Service Requester
              {currentContext?.context === "requester" && (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              )}
            </Button>
          </div>
          
          {roleSwitchMutation.isPending && (
            <Alert className="mt-4">
              <Clock className="h-4 w-4" />
              <AlertDescription>
                Switching role context and updating dashboard...
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Role-Specific Performance Metrics */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "provider" | "requester")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="provider" className="gap-2">
            <Building className="h-4 w-4" />
            Provider Performance
          </TabsTrigger>
          <TabsTrigger value="requester" className="gap-2">
            <Users className="h-4 w-4" />
            Requester Performance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="provider" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Overall Rating</p>
                    <Badge className={getRatingColor(providerMetrics?.overallRating || "unrated")}>
                      {providerMetrics?.overallRating || "Unrated"}
                    </Badge>
                  </div>
                  <Shield className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">On-Time Delivery</p>
                    <p className="text-xl font-bold">
                      {formatPercentage(providerMetrics?.onTimeDeliveryRate)}
                    </p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Revenue</p>
                    <p className="text-xl font-bold">
                      {formatCurrency(providerMetrics?.totalRevenue)}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Service Provider KPIs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Customer Satisfaction</span>
                    <span className="font-medium">
                      {providerMetrics?.customerSatisfactionScore?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Communication Rating</span>
                    <span className="font-medium">
                      {providerMetrics?.communicationRating?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Cost Efficiency</span>
                    <span className="font-medium">
                      {providerMetrics?.costEfficiencyRating?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Avg Delivery Time</span>
                    <span className="font-medium">
                      {providerMetrics?.averageDeliveryTime?.toFixed(1) || "N/A"} hrs
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Business Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Shipments</span>
                    <span className="font-medium">{providerMetrics?.totalShipments || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Average Order Value</span>
                    <span className="font-medium">
                      {formatCurrency(providerMetrics?.averageOrderValue)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Active Since</span>
                    <span className="font-medium">
                      {providerMetrics?.periodStart 
                        ? new Date(providerMetrics.periodStart).toLocaleDateString()
                        : "N/A"
                      }
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="requester" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Overall Rating</p>
                    <Badge className={getRatingColor(requesterMetrics?.overallRating || "unrated")}>
                      {requesterMetrics?.overallRating || "Unrated"}
                    </Badge>
                  </div>
                  <UserCheck className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Requests Fulfilled</p>
                    <p className="text-xl font-bold">
                      {formatPercentage(requesterMetrics?.onTimeDeliveryRate)}
                    </p>
                  </div>
                  <Truck className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Spent</p>
                    <p className="text-xl font-bold">
                      {formatCurrency(requesterMetrics?.totalRevenue)}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Requester KPIs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Payment Reliability</span>
                    <span className="font-medium">
                      {requesterMetrics?.customerSatisfactionScore?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Communication Rating</span>
                    <span className="font-medium">
                      {requesterMetrics?.communicationRating?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Request Clarity</span>
                    <span className="font-medium">
                      {requesterMetrics?.costEfficiencyRating?.toFixed(1) || "N/A"}/5.0
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Response Time</span>
                    <span className="font-medium">
                      {requesterMetrics?.averageDeliveryTime?.toFixed(1) || "N/A"} hrs
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Usage Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Requests</span>
                    <span className="font-medium">{requesterMetrics?.totalShipments || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Average Request Value</span>
                    <span className="font-medium">
                      {formatCurrency(requesterMetrics?.averageOrderValue)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Member Since</span>
                    <span className="font-medium">
                      {requesterMetrics?.periodStart 
                        ? new Date(requesterMetrics.periodStart).toLocaleDateString()
                        : "N/A"
                      }
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Current Context Alert */}
      <Alert>
        <ArrowRightLeft className="h-4 w-4" />
        <AlertDescription>
          You are currently operating in <strong>{currentContext?.context || "provider"}</strong> mode. 
          Your dashboard, opportunities, and workflows are customized for this role. 
          Switch roles anytime using the buttons above.
        </AlertDescription>
      </Alert>
    </div>
  );
}