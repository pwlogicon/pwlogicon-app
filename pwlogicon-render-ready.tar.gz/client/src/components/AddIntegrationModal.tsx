import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";

const addIntegrationSchema = z.object({
  name: z.string().optional(),
  type: z.enum(["Oracle TMS", "Manhattan SCALE", "Trimble TMS", "SAP EWM", "Blue Yonder", "Custom API"]),
  apiEndpoint: z.string().url("Must be a valid URL"),
  apiKey: z.string().min(1, "API key is required"),
  syncInterval: z.number().min(60, "Minimum sync interval is 60 seconds").default(300),
  active: z.boolean().default(true),
  config: z.object({
    timeout: z.number().default(30),
    retries: z.number().default(3),
    enableLogging: z.boolean().default(true),
  }),
});

type AddIntegrationForm = z.infer<typeof addIntegrationSchema>;

interface AddIntegrationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddIntegrationModal({ open, onOpenChange }: AddIntegrationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<"idle" | "success" | "error">("idle");

  const form = useForm<AddIntegrationForm>({
    resolver: zodResolver(addIntegrationSchema),
    defaultValues: {
      name: "",
      type: "Oracle TMS",
      apiEndpoint: "",
      apiKey: "",
      syncInterval: 300,
      active: true,
      config: {
        timeout: 30,
        retries: 3,
        enableLogging: true,
      },
    },
  });

  const addIntegrationMutation = useMutation({
    mutationFn: async (data: AddIntegrationForm) => {
      const response = await fetch("/api/integrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to create integration");
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      
      // Show success state with spinning animation
      toast({
        title: "✅ Connected!",
        description: `Successfully connected to ${form.getValues("type")}. Syncing capacity and lane data...`,
        duration: 3000,
      });
      
      // Auto-close modal after brief delay to show success
      setTimeout(() => {
        onOpenChange(false);
        form.reset();
        setConnectionStatus("idle");
      }, 1500);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add integration",
        variant: "destructive",
      });
    },
  });

  const testConnection = async () => {
    const apiEndpoint = form.getValues("apiEndpoint");
    const apiKey = form.getValues("apiKey");
    
    if (!apiEndpoint || !apiKey) {
      toast({
        title: "Missing Information",
        description: "Please enter API endpoint and key before testing connection",
        variant: "destructive",
      });
      return;
    }

    setTestingConnection(true);
    try {
      const response = await fetch("/api/integrations/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiEndpoint, apiKey }),
      });
      
      if (response.ok) {
        setConnectionStatus("success");
        toast({
          title: "Connection Successful",
          description: "API endpoint is reachable and authentication is valid",
        });
      } else {
        setConnectionStatus("error");
        toast({
          title: "Connection Failed",
          description: "Unable to connect to the API endpoint. Please check your URL and API key.",
          variant: "destructive",
        });
      }
    } catch (error) {
      setConnectionStatus("error");
      toast({
        title: "Connection Failed",
        description: "Network error or invalid endpoint",
        variant: "destructive",
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const onSubmit = (data: AddIntegrationForm) => {
    // Auto-generate name from type if not provided
    const submitData = {
      ...data,
      name: data.name || data.type
    };
    addIntegrationMutation.mutate(submitData);
  };

  const systemOptions = [
    { value: "Oracle TMS", label: "Oracle Transportation Management (TMS)" },
    { value: "Manhattan SCALE", label: "Manhattan SCALE" },
    { value: "Trimble TMS", label: "Trimble TMS" },
    { value: "SAP EWM", label: "SAP Extended Warehouse Management" },
    { value: "Blue Yonder", label: "Blue Yonder" },
    { value: "Custom API", label: "Custom API" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>➕ Add TMS/WMS Integration</DialogTitle>
          <DialogDescription>
            Connect your system to auto-sync capacity, lanes, and availability.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="apiEndpoint"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Instance URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://tms.yourcompany.com" {...field} />
                    </FormControl>
                    <FormDescription>
                      Your system's instance URL
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>System Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select system type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">Select System</SelectItem>
                        {systemOptions.map(({ value, label }) => (
                          <SelectItem key={value} value={value}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Choose your TMS, WMS, or other logistics management system
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>



            <FormField
              control={form.control}
              name="apiKey"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>API Key (Simulated)</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="Enter key (not stored)" 
                        autoComplete="off"
                        {...field} 
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={testConnection}
                      disabled={testingConnection}
                    >
                      {testingConnection ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : connectionStatus === "success" ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : connectionStatus === "error" ? (
                        <AlertCircle className="h-4 w-4 text-red-500" />
                      ) : (
                        "Test"
                      )}
                    </Button>
                  </div>
                  <FormDescription>
                    API credentials for system access (demonstration only)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="syncInterval"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Sync Interval (seconds)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="60" 
                      placeholder="300" 
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 300)}
                    />
                  </FormControl>
                  <FormDescription>
                    How often to synchronize data (minimum 60 seconds)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4 border rounded-lg p-4">
              <h4 className="font-medium">Advanced Settings</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="config.timeout"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Timeout (seconds)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="10" 
                          max="120"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 30)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="config.retries"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Retry Attempts</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          max="10"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 3)}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="config.enableLogging"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between">
                    <div className="space-y-0.5">
                      <FormLabel>Enable Detailed Logging</FormLabel>
                      <FormDescription>
                        Log sync operations for debugging and monitoring
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="active"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Active Integration</FormLabel>
                    <FormDescription>
                      Start synchronizing data immediately after creation
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )}
            />

            {/* How It Works Section */}
            <div className="border rounded-lg p-4 bg-blue-50">
              <h4 className="font-medium mb-3 flex items-center gap-2">
                📘 How It Works
              </h4>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span>After connection, we'll sync: <strong>available capacity, active lanes, equipment</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span>No manual updates needed</span>
                </li>
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span>Matchmaking becomes automatic</span>
                </li>
              </ul>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={addIntegrationMutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={addIntegrationMutation.isPending} className="min-w-[140px]">
                {addIntegrationMutation.isPending ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    Connecting...
                  </div>
                ) : (
                  "Connect System"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}