import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface AgreementConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  partnership: any;
  onConfirm: () => void;
  isLoading: boolean;
}

export function AgreementConfirmationModal({
  isOpen,
  onClose,
  partnership,
  onConfirm,
  isLoading,
}: AgreementConfirmationModalProps) {
  if (!partnership) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center space-x-3">
            <div className="flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <DialogTitle className="text-lg font-medium text-gray-900">
                Confirm Partnership Agreement
              </DialogTitle>
              <DialogDescription className="mt-1">
                Confirming this partnership will trigger the commission payment. Please review the details below.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="mt-4 bg-gray-50 rounded-lg p-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Partnership:</span>
              <span className="text-sm font-medium text-gray-900">
                Partnership #{partnership.id?.slice(0, 8)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Status:</span>
              <span className="text-sm text-gray-900">
                {partnership.status === "active" ? "Active Partnership" : partnership.status}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Contract Value:</span>
              <span className="text-sm text-gray-900">
                {partnership.contractValue 
                  ? `$${parseFloat(partnership.contractValue).toLocaleString()}`
                  : "N/A"
                }
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Commission:</span>
              <span className="text-sm font-medium text-secondary">
                ${parseFloat(partnership.feeAmount || "50").toLocaleString()}
                {partnership.feeModel === "percentage" && partnership.feePercentage 
                  ? ` (${partnership.feePercentage}%)`
                  : ""
                }
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="mt-6">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            disabled={isLoading}
            className="bg-secondary hover:bg-green-700"
          >
            {isLoading ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                Confirming...
              </>
            ) : (
              <>
                <CheckCircle className="mr-2 h-4 w-4" />
                Confirm Partnership
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
