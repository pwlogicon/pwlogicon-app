import React, { ReactNode, useState } from 'react';
import { createPortal } from 'react-dom';

interface TooltipProps {
  content: string | ReactNode;
  children: ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
  delay?: number;
}

export function Tooltip({ 
  content, 
  children, 
  position = 'top', 
  className = '', 
  delay = 500 
}: TooltipProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  const handleMouseEnter = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    
    let x = rect.left + rect.width / 2;
    let y = rect.top;

    switch (position) {
      case 'bottom':
        y = rect.bottom + 8;
        break;
      case 'top':
        y = rect.top - 8;
        break;
      case 'left':
        x = rect.left - 8;
        y = rect.top + rect.height / 2;
        break;
      case 'right':
        x = rect.right + 8;
        y = rect.top + rect.height / 2;
        break;
    }

    setTooltipPosition({ x, y });

    const id = setTimeout(() => {
      setIsVisible(true);
    }, delay);
    setTimeoutId(id);
  };

  const handleMouseLeave = () => {
    if (timeoutId) {
      clearTimeout(timeoutId);
      setTimeoutId(null);
    }
    setIsVisible(false);
  };

  const getPositionClasses = () => {
    switch (position) {
      case 'bottom':
        return 'translate-x-[-50%] translate-y-0';
      case 'top':
        return 'translate-x-[-50%] translate-y-[-100%]';
      case 'left':
        return 'translate-x-[-100%] translate-y-[-50%]';
      case 'right':
        return 'translate-x-0 translate-y-[-50%]';
      default:
        return 'translate-x-[-50%] translate-y-[-100%]';
    }
  };

  const getArrowClasses = () => {
    switch (position) {
      case 'bottom':
        return 'top-[-6px] left-1/2 transform -translate-x-1/2 border-l-[6px] border-r-[6px] border-b-[6px] border-transparent border-b-gray-900';
      case 'top':
        return 'bottom-[-6px] left-1/2 transform -translate-x-1/2 border-l-[6px] border-r-[6px] border-t-[6px] border-transparent border-t-gray-900';
      case 'left':
        return 'right-[-6px] top-1/2 transform -translate-y-1/2 border-t-[6px] border-b-[6px] border-l-[6px] border-transparent border-l-gray-900';
      case 'right':
        return 'left-[-6px] top-1/2 transform -translate-y-1/2 border-t-[6px] border-b-[6px] border-r-[6px] border-transparent border-r-gray-900';
      default:
        return 'bottom-[-6px] left-1/2 transform -translate-x-1/2 border-l-[6px] border-r-[6px] border-t-[6px] border-transparent border-t-gray-900';
    }
  };

  return (
    <>
      <div
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className="inline-block"
      >
        {children}
      </div>
      
      {isVisible && createPortal(
        <div
          className={`fixed z-50 px-3 py-2 text-sm text-white bg-gray-900 rounded-lg shadow-lg max-w-xs ${getPositionClasses()} ${className}`}
          style={{
            left: tooltipPosition.x,
            top: tooltipPosition.y,
          }}
        >
          <div className={`absolute w-0 h-0 ${getArrowClasses()}`}></div>
          {content}
        </div>,
        document.body
      )}
    </>
  );
}

// Add TooltipProvider and other exports for compatibility with existing code
export function TooltipProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

export function TooltipTrigger({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

export function TooltipContent({ children }: { children: ReactNode }) {
  return <>{children}</>;
}