import React from 'react';
import { Tooltip } from '@/components/ui/tooltip';
import { getContextualInsight, getRandomInsight } from '@/utils/logisticsInsights';

interface LogisticsTooltipProps {
  children: React.ReactNode;
  serviceType?: string;
  region?: string;
  urgency?: string;
  context?: string;
  category?: 'ftl' | 'ltl' | 'reefer' | 'intermodal' | 'onTime' | 'cost' | 'capacity' | 'matching' | 'partnership' | 'savings' | 'ai' | 'analytics';
  className?: string;
}

/**
 * A specialized tooltip component that provides contextual logistics insights
 * based on the service type, region, urgency, or category provided.
 */
export function LogisticsTooltip({ 
  children, 
  serviceType, 
  region, 
  urgency, 
  context, 
  category,
  className = ''
}: LogisticsTooltipProps) {
  let insight: string;

  if (category) {
    insight = getRandomInsight(category);
  } else {
    insight = getContextualInsight(serviceType, region, urgency, context);
  }

  return (
    <Tooltip content={insight} className={className}>
      <div className="cursor-help inline-block">
        {children}
      </div>
    </Tooltip>
  );
}

// Convenience components for common use cases
export function ServiceTypeTooltip({ children, serviceType }: { children: React.ReactNode; serviceType: string }) {
  return (
    <LogisticsTooltip serviceType={serviceType}>
      {children}
    </LogisticsTooltip>
  );
}

export function PricingTooltip({ children }: { children: React.ReactNode }) {
  return (
    <LogisticsTooltip category="cost">
      {children}
    </LogisticsTooltip>
  );
}

export function CapacityTooltip({ children }: { children: React.ReactNode }) {
  return (
    <LogisticsTooltip category="capacity">
      {children}
    </LogisticsTooltip>
  );
}

export function PartnershipTooltip({ children }: { children: React.ReactNode }) {
  return (
    <LogisticsTooltip category="partnership">
      {children}
    </LogisticsTooltip>
  );
}

export function AITooltip({ children }: { children: React.ReactNode }) {
  return (
    <LogisticsTooltip category="ai">
      {children}
    </LogisticsTooltip>
  );
}