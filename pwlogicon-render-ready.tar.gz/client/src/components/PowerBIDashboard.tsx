import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ComposedChart,
  Area,
  AreaChart,
  ScatterChart,
  Scatter,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from 'recharts';
import { 
  BarChart3, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Settings, 
  Download, 
  RefreshCw,
  Database,
  Monitor,
  Filter,
  Eye,
  Target,
  Layers,
  Grid3X3,
  Share2
} from 'lucide-react';

interface PowerBIDashboardProps {
  role?: 'ops' | 'finance' | 'exec';
  clientId?: string;
}

const COLORS = ['#0078D4', '#00BCF2', '#40E0D0', '#FFB900', '#FF8C00', '#E81123', '#8661C5'];

const PowerBIDashboard: React.FC<PowerBIDashboardProps> = ({ role = 'ops', clientId }) => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [selectedDataSources, setSelectedDataSources] = useState<string[]>(['tms', 'wms', 'telematics']);
  const [selectedTimeRange, setSelectedTimeRange] = useState('30d');
  const [selectedRole, setSelectedRole] = useState(role);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 60000);
    return () => clearInterval(interval);
  }, [selectedDataSources, selectedTimeRange, selectedRole, clientId]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/powerbi/dashboard?' + new URLSearchParams({
        role: selectedRole,
        dataSources: selectedDataSources.join(','),
        timeRange: selectedTimeRange,
        ...(clientId && { clientId })
      }));
      
      const data = await response.json();
      setDashboardData(data);
    } catch (error) {
      console.error('Failed to fetch Power BI dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
  };

  const handleExport = (format: 'pdf' | 'excel' | 'powerbi') => {
    // Mock export functionality
    const exportData = {
      format,
      role: selectedRole,
      dataSources: selectedDataSources,
      timeRange: selectedTimeRange,
      timestamp: new Date().toISOString()
    };
    
    console.log('Exporting dashboard:', exportData);
    // In real implementation, this would trigger export to Power BI, PDF, or Excel
  };

  const getRoleConfig = () => {
    switch (selectedRole) {
      case 'finance':
        return {
          title: 'Financial Analytics Dashboard',
          color: 'text-green-600',
          bgColor: 'bg-green-50',
          icon: DollarSign
        };
      case 'exec':
        return {
          title: 'Executive Summary Dashboard',
          color: 'text-purple-600',
          bgColor: 'bg-purple-50',
          icon: Target
        };
      default:
        return {
          title: 'Operations Analytics Dashboard',
          color: 'text-blue-600',
          bgColor: 'bg-blue-50',
          icon: BarChart3
        };
    }
  };

  const roleConfig = getRoleConfig();
  const IconComponent = roleConfig.icon;

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center space-y-4">
            <Monitor className="h-8 w-8 animate-pulse text-blue-500" />
            <p className="text-sm text-gray-600">Loading Power BI Dashboard...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <IconComponent className={`h-6 w-6 ${roleConfig.color}`} />
              {roleConfig.title}
              <Badge variant="outline" className="ml-2">
                Custom Analytics
              </Badge>
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button 
                onClick={handleRefresh} 
                variant="outline" 
                size="sm"
                disabled={refreshing}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Select value={selectedRole} onValueChange={(value: any) => setSelectedRole(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ops">Operations</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="exec">Executive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-4">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-600">Data Sources:</span>
              {['TMS', 'WMS', 'Telematics', 'ERP'].map((source) => (
                <Badge 
                  key={source}
                  variant={selectedDataSources.includes(source.toLowerCase()) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => {
                    const sourceKey = source.toLowerCase();
                    setSelectedDataSources(prev => 
                      prev.includes(sourceKey) 
                        ? prev.filter(s => s !== sourceKey)
                        : [...prev, sourceKey]
                    );
                  }}
                >
                  {source}
                </Badge>
              ))}
            </div>
            
            <div className="flex items-center gap-2 ml-4">
              <Filter className="h-4 w-4 text-gray-500" />
              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">7 Days</SelectItem>
                  <SelectItem value="30d">30 Days</SelectItem>
                  <SelectItem value="90d">90 Days</SelectItem>
                  <SelectItem value="1y">1 Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className={`grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 p-4 ${roleConfig.bgColor} rounded-lg`}>
            <div className="text-center">
              <h3 className={`text-2xl font-bold ${roleConfig.color}`}>
                {dashboardData?.kpis?.primary || '0'}
              </h3>
              <p className="text-sm text-gray-600">{dashboardData?.kpis?.primaryLabel || 'Primary KPI'}</p>
            </div>
            <div className="text-center">
              <h3 className={`text-2xl font-bold ${roleConfig.color}`}>
                {dashboardData?.kpis?.secondary || '0'}
              </h3>
              <p className="text-sm text-gray-600">{dashboardData?.kpis?.secondaryLabel || 'Secondary KPI'}</p>
            </div>
            <div className="text-center">
              <h3 className={`text-2xl font-bold ${roleConfig.color}`}>
                {dashboardData?.kpis?.tertiary || '0'}
              </h3>
              <p className="text-sm text-gray-600">{dashboardData?.kpis?.tertiaryLabel || 'Tertiary KPI'}</p>
            </div>
            <div className="text-center">
              <h3 className={`text-2xl font-bold ${roleConfig.color}`}>
                {dashboardData?.kpis?.quaternary || '0'}
              </h3>
              <p className="text-sm text-gray-600">{dashboardData?.kpis?.quaternaryLabel || 'Quaternary KPI'}</p>
            </div>
          </div>

          <Tabs defaultValue="analytics" className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList className="grid w-full max-w-md grid-cols-4">
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
                <TabsTrigger value="crossplatform">Cross-Platform</TabsTrigger>
                <TabsTrigger value="insights">Insights</TabsTrigger>
                <TabsTrigger value="export">Export</TabsTrigger>
              </TabsList>
              
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleExport('powerbi')}>
                  <Share2 className="h-4 w-4 mr-2" />
                  Share to Power BI
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleExport('pdf')}>
                  <Download className="h-4 w-4 mr-2" />
                  Export PDF
                </Button>
              </div>
            </div>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <BarChart3 className="h-4 w-4" />
                      Performance by Data Source
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={dashboardData?.performanceBySource || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="source" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="performance" fill="#0078D4" />
                        <Bar dataKey="efficiency" fill="#00BCF2" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <PieChartIcon className="h-4 w-4" />
                      Resource Allocation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={dashboardData?.resourceAllocation || []}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                        >
                          {(dashboardData?.resourceAllocation || []).map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="col-span-full">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Integrated KPI Trends
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <ComposedChart data={dashboardData?.kpiTrends || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Area type="monotone" dataKey="volume" fill="#E6F3FF" stroke="#0078D4" fillOpacity={0.6} />
                        <Bar dataKey="efficiency" fill="#00BCF2" />
                        <Line type="monotone" dataKey="cost" stroke="#FF8C00" strokeWidth={3} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="crossplatform" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Layers className="h-4 w-4" />
                      Multi-System Integration Health
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={dashboardData?.systemHealth || []}>
                        <PolarGrid />
                        <PolarAngleAxis dataKey="system" />
                        <PolarRadiusAxis angle={90} domain={[0, 100]} />
                        <Radar name="Health Score" dataKey="health" stroke="#0078D4" fill="#0078D4" fillOpacity={0.3} />
                        <Radar name="Performance" dataKey="performance" stroke="#00BCF2" fill="#00BCF2" fillOpacity={0.3} />
                        <Legend />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Database className="h-4 w-4" />
                      Data Source Correlation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <ScatterChart data={dashboardData?.dataCorrelation || []}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="x" name="TMS Data Quality" unit="%" />
                        <YAxis dataKey="y" name="WMS Integration" unit="%" />
                        <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                        <Scatter name="Correlation" dataKey="z" fill="#0078D4" />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="col-span-full">
                  <CardHeader>
                    <CardTitle className="text-base">System Integration Matrix</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {(dashboardData?.integrationMatrix || []).map((integration: any, index: number) => (
                        <div key={index} className="p-4 border rounded-lg hover:bg-gray-50">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium">{integration.name}</h4>
                            <Badge 
                              variant={integration.status === 'connected' ? 'default' : 'destructive'}
                              className={integration.status === 'connected' ? 'bg-green-100 text-green-800' : ''}
                            >
                              {integration.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{integration.description}</p>
                          <div className="flex justify-between text-sm">
                            <span>Sync Rate: {integration.syncRate}%</span>
                            <span>Latency: {integration.latency}ms</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="insights" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      AI-Powered Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {(dashboardData?.insights || []).map((insight: any, index: number) => (
                        <div key={index} className="p-4 border-l-4 border-blue-500 bg-blue-50 rounded-r-lg">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-medium text-blue-900">{insight.title}</h4>
                              <p className="text-sm text-blue-700 mt-1">{insight.description}</p>
                              <div className="flex items-center gap-4 mt-2">
                                <span className="text-xs text-blue-600">Impact: {insight.impact}</span>
                                <span className="text-xs text-blue-600">Confidence: {insight.confidence}%</span>
                              </div>
                            </div>
                            <Badge variant="outline" className="text-blue-600 border-blue-600">
                              {insight.category}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Action Items
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {(dashboardData?.actionItems || []).map((item: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div>
                              <h5 className="font-medium text-sm">{item.title}</h5>
                              <p className="text-xs text-gray-600 mt-1">{item.description}</p>
                            </div>
                            <Badge 
                              variant={item.priority === 'high' ? 'destructive' : 
                                      item.priority === 'medium' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {item.priority}
                            </Badge>
                          </div>
                          <div className="mt-2 text-xs text-gray-500">
                            Due: {item.dueDate} | Owner: {item.owner}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="export" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Power BI Integration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">
                      Export this dashboard directly to Power BI for advanced analytics and sharing.
                    </p>
                    <Button 
                      className="w-full" 
                      onClick={() => handleExport('powerbi')}
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Export to Power BI
                    </Button>
                    <div className="text-xs text-gray-500">
                      <p>• Maintains real-time data connections</p>
                      <p>• Preserves custom visualizations</p>
                      <p>• Enables collaborative editing</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Excel Export</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">
                      Download raw data and charts for offline analysis and reporting.
                    </p>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => handleExport('excel')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export to Excel
                    </Button>
                    <div className="text-xs text-gray-500">
                      <p>• Includes all data tables</p>
                      <p>• Charts as images</p>
                      <p>• Formatted for analysis</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">PDF Report</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">
                      Generate a comprehensive PDF report for stakeholder distribution.
                    </p>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => handleExport('pdf')}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Generate PDF
                    </Button>
                    <div className="text-xs text-gray-500">
                      <p>• Executive summary</p>
                      <p>• Key insights highlighted</p>
                      <p>• Print-ready format</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PowerBIDashboard;