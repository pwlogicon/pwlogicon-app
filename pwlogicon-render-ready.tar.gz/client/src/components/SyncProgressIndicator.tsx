import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  RefreshCw, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Database,
  Truck,
  Package,
  AlertTriangle,
  Activity
} from "lucide-react";

interface SyncStatus {
  id: string;
  name: string;
  type: 'tms' | 'wms' | 'batch' | 'carrier';
  status: 'pending' | 'syncing' | 'completed' | 'failed' | 'paused';
  progress: number;
  totalItems?: number;
  processedItems?: number;
  startTime?: Date;
  estimatedCompletion?: Date;
  errorMessage?: string;
  lastSync?: Date;
}

interface SyncProgressIndicatorProps {
  syncOperations: SyncStatus[];
  onRetry?: (id: string) => void;
  onPause?: (id: string) => void;
  onCancel?: (id: string) => void;
  showDetails?: boolean;
}

export default function SyncProgressIndicator({ 
  syncOperations, 
  onRetry, 
  onPause, 
  onCancel,
  showDetails = true 
}: SyncProgressIndicatorProps) {
  const [expandedOperation, setExpandedOperation] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'syncing': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'failed': return 'bg-red-100 text-red-800 border-red-200';
      case 'paused': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'pending': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4" />;
      case 'syncing': return <RefreshCw className="h-4 w-4 animate-spin" />;
      case 'failed': return <XCircle className="h-4 w-4" />;
      case 'paused': return <Clock className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'tms': return <Truck className="h-5 w-5 text-blue-600" />;
      case 'wms': return <Package className="h-5 w-5 text-green-600" />;
      case 'batch': return <Database className="h-5 w-5 text-purple-600" />;
      case 'carrier': return <Truck className="h-5 w-5 text-orange-600" />;
      default: return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  const formatTimeRemaining = (estimatedCompletion?: Date) => {
    if (!estimatedCompletion) return 'Unknown';
    
    const now = new Date();
    const diff = estimatedCompletion.getTime() - now.getTime();
    
    if (diff <= 0) return 'Completing...';
    
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    
    if (minutes > 0) {
      return `${minutes}m ${seconds}s remaining`;
    }
    return `${seconds}s remaining`;
  };

  const getProgressBarColor = (status: string, progress: number) => {
    if (status === 'failed') return 'bg-red-500';
    if (status === 'completed') return 'bg-green-500';
    if (status === 'paused') return 'bg-yellow-500';
    
    // Animated gradient for active syncing
    if (status === 'syncing') {
      return 'bg-gradient-to-r from-blue-500 via-blue-600 to-blue-500 bg-[length:200%_100%] animate-pulse';
    }
    
    return 'bg-blue-500';
  };

  if (syncOperations.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {syncOperations.map((operation) => (
        <Card 
          key={operation.id} 
          className={`transition-all duration-300 ${
            operation.status === 'syncing' ? 'ring-2 ring-blue-200 shadow-lg' : 'hover:shadow-md'
          }`}
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {getTypeIcon(operation.type)}
                <div>
                  <CardTitle className="text-lg">{operation.name}</CardTitle>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge className={getStatusColor(operation.status)}>
                      {getStatusIcon(operation.status)}
                      <span className="ml-1 capitalize">{operation.status}</span>
                    </Badge>
                    {operation.totalItems && (
                      <span className="text-sm text-muted-foreground">
                        {operation.processedItems || 0} / {operation.totalItems} items
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {operation.status === 'syncing' && onPause && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onPause(operation.id)}
                  >
                    Pause
                  </Button>
                )}
                {operation.status === 'failed' && onRetry && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onRetry(operation.id)}
                  >
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Retry
                  </Button>
                )}
                {onCancel && ['pending', 'syncing', 'paused'].includes(operation.status) && (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => onCancel(operation.id)}
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pt-0">
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{Math.round(operation.progress)}%</span>
              </div>
              
              <div className="relative">
                <Progress 
                  value={operation.progress} 
                  className="h-3"
                />
                {operation.status === 'syncing' && (
                  <div 
                    className={`absolute top-0 left-0 h-full rounded-full transition-all duration-500 ${getProgressBarColor(operation.status, operation.progress)}`}
                    style={{ width: `${operation.progress}%` }}
                  />
                )}
              </div>
            </div>

            {/* Details Section */}
            {showDetails && (
              <div className="mt-4 space-y-2">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  {operation.startTime && (
                    <div>
                      <span className="text-muted-foreground">Started:</span>
                      <span className="ml-2 font-medium">
                        {operation.startTime.toLocaleTimeString()}
                      </span>
                    </div>
                  )}
                  
                  {operation.estimatedCompletion && operation.status === 'syncing' && (
                    <div>
                      <span className="text-muted-foreground">ETA:</span>
                      <span className="ml-2 font-medium">
                        {formatTimeRemaining(operation.estimatedCompletion)}
                      </span>
                    </div>
                  )}
                  
                  {operation.lastSync && operation.status === 'completed' && (
                    <div className="col-span-2">
                      <span className="text-muted-foreground">Completed:</span>
                      <span className="ml-2 font-medium text-green-600">
                        {operation.lastSync.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {operation.status === 'failed' && operation.errorMessage && (
                  <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-md">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-red-800">Sync Failed</p>
                        <p className="text-sm text-red-700 mt-1">{operation.errorMessage}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Success Message */}
                {operation.status === 'completed' && (
                  <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-md">
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                      <p className="text-sm font-medium text-green-800">
                        Synchronization completed successfully
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}