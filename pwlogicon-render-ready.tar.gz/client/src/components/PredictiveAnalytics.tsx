import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { 
  TrendingUpIcon, 
  TrendingDownIcon,
  AlertTriangleIcon,
  BrainIcon,
  ZapIcon,
  TargetIcon,
  ClockIcon,
  DollarSignIcon,
  TruckIcon,
  ActivityIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from "lucide-react";

interface PredictionData {
  capacityGaps: Array<{
    lane: string;
    predictedGap: number;
    confidence: number;
    timeframe: string;
    impact: 'high' | 'medium' | 'low';
    suggestedActions: string[];
  }>;
  demandForecast: Array<{
    region: string;
    currentDemand: number;
    predictedDemand: number;
    growthPercentage: number;
    peakPeriods: string[];
  }>;
  priceOptimization: Array<{
    lane: string;
    currentRate: number;
    suggestedRate: number;
    competitorRate: number;
    marketTrend: 'up' | 'down' | 'stable';
    confidence: number;
  }>;
  exceptions: Array<{
    id: string;
    type: string;
    severity: 'critical' | 'high' | 'medium' | 'low';
    description: string;
    prediction: string;
    autoResolution: boolean;
    estimatedImpact: string;
    suggestedAction: string;
  }>;
  kpis: {
    predictionAccuracy: number;
    exceptionsAutoResolved: number;
    costSavingsFromOptimization: number;
    capacityUtilizationImprovement: number;
  };
}

interface PredictiveAnalyticsProps {
  onApplyOptimization?: (optimizationId: string) => void;
  onResolveException?: (exceptionId: string, action: string) => void;
  onSchedulePrediction?: (lane: string, timeframe: string) => void;
}

export default function PredictiveAnalytics({ 
  onApplyOptimization, 
  onResolveException, 
  onSchedulePrediction 
}: PredictiveAnalyticsProps) {
  const [timeframe, setTimeframe] = useState("7d");
  const [region, setRegion] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch predictive analytics data
  const { data: predictionsData, isLoading, error } = useQuery<PredictionData>({
    queryKey: ['/api/predictive-analytics', timeframe, region],
    refetchInterval: 60000, // Refresh every minute for real-time predictions
  });

  // Generate new predictions mutation
  const generatePredictionsMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/predictive-analytics/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeframe, region })
      });
      if (!response.ok) throw new Error('Failed to generate predictions');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/predictive-analytics'] });
      toast({ title: "New predictions generated using AI analysis" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Prediction generation failed", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityVariant = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'default';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-8 bg-gray-200 rounded mb-2"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-red-600">
            <AlertTriangleIcon className="h-5 w-5" />
            <span>Failed to load predictive analytics</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Analytics Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BrainIcon className="h-6 w-6 text-purple-600" />
            AI Predictive Analytics
          </h2>
          <p className="text-gray-600">Advanced forecasting and automated optimization powered by machine learning</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
              <SelectItem value="90d">90 Days</SelectItem>
              <SelectItem value="180d">6 Months</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="midwest">Midwest</SelectItem>
              <SelectItem value="southeast">Southeast</SelectItem>
              <SelectItem value="west">West Coast</SelectItem>
              <SelectItem value="northeast">Northeast</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            onClick={() => generatePredictionsMutation.mutate()}
            disabled={generatePredictionsMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <BrainIcon className={`h-4 w-4 mr-2 ${generatePredictionsMutation.isPending ? 'animate-spin' : ''}`} />
            Generate AI Predictions
          </Button>
        </div>
      </div>

      {/* KPI Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700">Prediction Accuracy</p>
                <p className="text-2xl font-bold text-purple-900">{predictionsData?.kpis.predictionAccuracy || 0}%</p>
              </div>
              <TargetIcon className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700">Auto-Resolved Exceptions</p>
                <p className="text-2xl font-bold text-green-900">{predictionsData?.kpis.exceptionsAutoResolved || 0}%</p>
              </div>
              <ZapIcon className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700">Cost Savings</p>
                <p className="text-2xl font-bold text-blue-900">{formatCurrency(predictionsData?.kpis.costSavingsFromOptimization || 0)}</p>
              </div>
              <DollarSignIcon className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700">Capacity Improvement</p>
                <p className="text-2xl font-bold text-orange-900">+{predictionsData?.kpis.capacityUtilizationImprovement || 0}%</p>
              </div>
              <TruckIcon className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Predictive Analytics Tabs */}
      <Tabs defaultValue="capacity" className="space-y-4">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="capacity">Capacity Gaps</TabsTrigger>
          <TabsTrigger value="demand">Demand Forecast</TabsTrigger>
          <TabsTrigger value="pricing">Price Optimization</TabsTrigger>
          <TabsTrigger value="exceptions">Exception Handling</TabsTrigger>
        </TabsList>

        <TabsContent value="capacity">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangleIcon className="h-5 w-5" />
                Predicted Capacity Gaps
              </CardTitle>
              <CardDescription>AI-powered forecasting of capacity shortages and oversupply</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictionsData?.capacityGaps?.map((gap, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold">{gap.lane}</h4>
                        <p className="text-sm text-gray-600">{gap.timeframe}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <Badge variant={getSeverityVariant(gap.impact)}>{gap.impact} impact</Badge>
                          <div className="text-sm">
                            <span className="font-medium">{gap.confidence}% confidence</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm">Predicted Gap</span>
                        <span className="text-sm font-medium">{gap.predictedGap} loads</span>
                      </div>
                      <Progress value={gap.confidence} className="h-2" />
                    </div>

                    <div className="mb-3">
                      <p className="text-sm font-medium mb-2">Suggested Actions:</p>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {gap.suggestedActions.map((action, actionIndex) => (
                          <li key={actionIndex} className="flex items-start gap-2">
                            <span className="text-blue-500">•</span>
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => onSchedulePrediction?.(gap.lane, gap.timeframe)}
                      >
                        Schedule Alert
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => onApplyOptimization?.(`capacity-${index}`)}
                      >
                        Apply Optimization
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="demand">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUpIcon className="h-5 w-5" />
                Demand Forecasting
              </CardTitle>
              <CardDescription>Regional demand predictions and growth opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictionsData?.demandForecast?.map((forecast, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-semibold">{forecast.region}</h4>
                      <div className="flex items-center gap-2">
                        {forecast.growthPercentage > 0 ? (
                          <ArrowUpIcon className="h-4 w-4 text-green-500" />
                        ) : (
                          <ArrowDownIcon className="h-4 w-4 text-red-500" />
                        )}
                        <span className={`font-medium ${forecast.growthPercentage > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {forecast.growthPercentage > 0 ? '+' : ''}{forecast.growthPercentage}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-sm text-gray-600">Current Demand</p>
                        <p className="text-lg font-medium">{forecast.currentDemand} loads/week</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Predicted Demand</p>
                        <p className="text-lg font-medium">{forecast.predictedDemand} loads/week</p>
                      </div>
                    </div>

                    <div className="mb-3">
                      <p className="text-sm font-medium mb-2">Peak Periods:</p>
                      <div className="flex flex-wrap gap-2">
                        {forecast.peakPeriods.map((period, periodIndex) => (
                          <Badge key={periodIndex} variant="secondary">{period}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pricing">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSignIcon className="h-5 w-5" />
                AI Price Optimization
              </CardTitle>
              <CardDescription>Market-driven pricing recommendations for maximum profitability</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictionsData?.priceOptimization?.map((optimization, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold">{optimization.lane}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={optimization.marketTrend === 'up' ? 'default' : optimization.marketTrend === 'down' ? 'destructive' : 'secondary'}>
                            {optimization.marketTrend === 'up' ? '↗️ Rising' : optimization.marketTrend === 'down' ? '↘️ Falling' : '→ Stable'}
                          </Badge>
                          <span className="text-sm text-gray-600">{optimization.confidence}% confidence</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-3">
                      <div>
                        <p className="text-sm text-gray-600">Current Rate</p>
                        <p className="text-lg font-medium">{formatCurrency(optimization.currentRate)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">AI Suggested</p>
                        <p className="text-lg font-medium text-green-600">{formatCurrency(optimization.suggestedRate)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Market Average</p>
                        <p className="text-lg font-medium">{formatCurrency(optimization.competitorRate)}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => onApplyOptimization?.(`pricing-${index}`)}
                      >
                        Apply Pricing
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                      >
                        Schedule Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="exceptions">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ZapIcon className="h-5 w-5" />
                Automated Exception Handling
              </CardTitle>
              <CardDescription>AI-powered prediction and resolution of operational exceptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictionsData?.exceptions?.map((exception) => (
                  <div key={exception.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold flex items-center gap-2">
                          {exception.type}
                          {exception.autoResolution && (
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              <ZapIcon className="h-3 w-3 mr-1" />
                              Auto-resolving
                            </Badge>
                          )}
                        </h4>
                        <p className="text-sm text-gray-600 mt-1">{exception.description}</p>
                      </div>
                      <Badge variant={getSeverityVariant(exception.severity)}>{exception.severity}</Badge>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">AI Prediction:</p>
                      <p className="text-sm text-gray-700">{exception.prediction}</p>
                    </div>

                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">Estimated Impact:</p>
                      <p className="text-sm text-gray-700">{exception.estimatedImpact}</p>
                    </div>

                    <div className="mb-3">
                      <p className="text-sm font-medium mb-1">Suggested Action:</p>
                      <p className="text-sm text-gray-700">{exception.suggestedAction}</p>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => onResolveException?.(exception.id, 'auto')}
                        disabled={exception.autoResolution}
                      >
                        {exception.autoResolution ? 'Auto-Resolving...' : 'Resolve Now'}
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => onResolveException?.(exception.id, 'manual')}
                      >
                        Manual Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}