import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Truck, 
  Shield, 
  Clock, 
  MapPin, 
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Activity,
  FileText,
  Users
} from 'lucide-react';

interface MacroPointIntegrationProps {
  brokerId?: string;
}

const MacroPointIntegration: React.FC<MacroPointIntegrationProps> = ({ brokerId }) => {
  const [carrierData, setCarrierData] = useState<any[]>([]);
  const [complianceData, setComplianceData] = useState<any>(null);
  const [trackingData, setTrackingData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMacroPointData();
    const interval = setInterval(fetchMacroPointData, 30000);
    return () => clearInterval(interval);
  }, [brokerId]);

  const fetchMacroPointData = async () => {
    try {
      setLoading(true);
      const [carriersRes, complianceRes, trackingRes] = await Promise.all([
        fetch(`/api/macropoint/carriers${brokerId ? `?brokerId=${brokerId}` : ''}`),
        fetch(`/api/macropoint/compliance${brokerId ? `?brokerId=${brokerId}` : ''}`),
        fetch(`/api/macropoint/tracking${brokerId ? `?brokerId=${brokerId}` : ''}`)
      ]);

      const [carriers, compliance, tracking] = await Promise.all([
        carriersRes.json(),
        complianceRes.json(),
        trackingRes.json()
      ]);

      setCarrierData(carriers.carriers || []);
      setComplianceData(compliance);
      setTrackingData(tracking.loads || []);
    } catch (error) {
      console.error('Failed to fetch MacroPoint data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getComplianceScore = (carrier: any) => {
    const onTime = carrier.onTimePercentage || 0;
    const acceptance = carrier.tenderAcceptanceRate || 0;
    const eldCompliance = carrier.eldComplianceScore || 0;
    return Math.round((onTime + acceptance + eldCompliance) / 3);
  };

  const getComplianceColor = (score: number) => {
    if (score >= 90) return 'bg-green-500';
    if (score >= 80) return 'bg-yellow-500';
    if (score >= 70) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'compliant': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'violation': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center space-y-4">
            <Activity className="h-8 w-8 animate-spin text-blue-500" />
            <p className="text-sm text-gray-600">Loading MacroPoint data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-6 w-6 text-blue-600" />
            Descartes MacroPoint Integration
            <Badge variant="outline" className="ml-auto">
              {carrierData.length} Carriers
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="text-2xl font-bold text-blue-600">
                {complianceData?.averageOnTimePercentage || 0}%
              </h3>
              <p className="text-sm text-gray-600">Average On-Time</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="text-2xl font-bold text-green-600">
                {complianceData?.compliantCarriers || 0}
              </h3>
              <p className="text-sm text-gray-600">Compliant Carriers</p>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <h3 className="text-2xl font-bold text-yellow-600">
                {complianceData?.activeLoads || 0}
              </h3>
              <p className="text-sm text-gray-600">Active Loads</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="text-2xl font-bold text-purple-600">
                {complianceData?.eldCompliance || 0}%
              </h3>
              <p className="text-sm text-gray-600">ELD Compliance</p>
            </div>
          </div>

          <Tabs defaultValue="carriers" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="carriers">Carrier Scorecards</TabsTrigger>
              <TabsTrigger value="tracking">Load Tracking</TabsTrigger>
              <TabsTrigger value="compliance">Compliance Dashboard</TabsTrigger>
            </TabsList>

            <TabsContent value="carriers" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Carrier Performance Scorecards</h3>
                <Button onClick={fetchMacroPointData} variant="outline" size="sm">
                  <Activity className="h-4 w-4 mr-2" />
                  Refresh Data
                </Button>
              </div>
              
              <div className="grid gap-4">
                {carrierData.map((carrier, index) => {
                  const score = getComplianceScore(carrier);
                  return (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="flex items-center space-x-2">
                              <Truck className="h-5 w-5 text-blue-600" />
                              <h4 className="font-semibold">{carrier.carrierName}</h4>
                            </div>
                            <Badge variant="outline">{carrier.mcNumber}</Badge>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getComplianceColor(score)}>
                              {score}% Score
                            </Badge>
                            {getStatusIcon(carrier.complianceStatus)}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm text-gray-600">On-Time %</span>
                              <span className="text-sm font-medium">
                                {carrier.onTimePercentage || 0}%
                              </span>
                            </div>
                            <Progress value={carrier.onTimePercentage || 0} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm text-gray-600">Tender Acceptance</span>
                              <span className="text-sm font-medium">
                                {carrier.tenderAcceptanceRate || 0}%
                              </span>
                            </div>
                            <Progress value={carrier.tenderAcceptanceRate || 0} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm text-gray-600">ELD Compliance</span>
                              <span className="text-sm font-medium">
                                {carrier.eldComplianceScore || 0}%
                              </span>
                            </div>
                            <Progress value={carrier.eldComplianceScore || 0} className="h-2" />
                          </div>
                        </div>
                        
                        <div className="mt-3 pt-3 border-t">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Active Loads: {carrier.activeLoads || 0}</span>
                            <span className="text-gray-600">Last Update: {carrier.lastUpdate}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="tracking" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Real-Time Load Tracking</h3>
                <Badge variant="outline">{trackingData.length} Active Loads</Badge>
              </div>
              
              <div className="grid gap-4">
                {trackingData.map((load, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-5 w-5 text-green-600" />
                          <div>
                            <h4 className="font-semibold">Load #{load.loadNumber}</h4>
                            <p className="text-sm text-gray-600">{load.carrierName}</p>
                          </div>
                        </div>
                        <Badge variant={load.status === 'on_time' ? 'default' : 'destructive'}>
                          {load.status === 'on_time' ? 'On Time' : 'Delayed'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                        <div>
                          <p className="text-sm text-gray-600">Origin</p>
                          <p className="font-medium">{load.origin}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Destination</p>
                          <p className="font-medium">{load.destination}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Progress</span>
                          <span className="text-sm font-medium">{load.progressPercentage}%</span>
                        </div>
                        <Progress value={load.progressPercentage} className="h-2" />
                      </div>
                      
                      <div className="mt-3 pt-3 border-t flex justify-between text-sm">
                        <span className="text-gray-600">ETA: {load.estimatedArrival}</span>
                        <span className="text-gray-600">Last Ping: {load.lastEldPing}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="compliance" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      Compliance Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Compliant Carriers</span>
                        <span className="font-medium">{complianceData?.compliantCarriers || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Non-Compliant</span>
                        <span className="font-medium text-red-600">{complianceData?.nonCompliantCarriers || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Under Review</span>
                        <span className="font-medium text-yellow-600">{complianceData?.underReviewCarriers || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Performance Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Avg On-Time %</span>
                        <span className="font-medium">{complianceData?.averageOnTimePercentage || 0}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Avg Tender Accept</span>
                        <span className="font-medium">{complianceData?.averageTenderAcceptance || 0}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">ELD Compliance</span>
                        <span className="font-medium">{complianceData?.eldCompliance || 0}%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Capacity Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Available Capacity</span>
                        <span className="font-medium">{complianceData?.availableCapacity || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Utilization Rate</span>
                        <span className="font-medium">{complianceData?.utilizationRate || 0}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Active Contracts</span>
                        <span className="font-medium">{complianceData?.activeContracts || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Compliance Reports & Procurement Strategy
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Recent Compliance Issues</h4>
                      <div className="space-y-2">
                        {complianceData?.recentIssues?.map((issue: any, index: number) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-red-50 rounded">
                            <span className="text-sm">{issue.carrier}</span>
                            <Badge variant="destructive" className="text-xs">{issue.type}</Badge>
                          </div>
                        )) || []}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Top Performing Carriers</h4>
                      <div className="space-y-2">
                        {complianceData?.topPerformers?.map((performer: any, index: number) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-green-50 rounded">
                            <span className="text-sm">{performer.carrier}</span>
                            <Badge variant="default" className="text-xs">{performer.score}%</Badge>
                          </div>
                        )) || []}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default MacroPointIntegration;