import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { mountPredictiveETA } from "./components/PredictiveETAMount";

// Make PredictiveETA component globally available for EJS templates
if (typeof window !== 'undefined') {
  (window as any).mountPredictiveETA = mountPredictiveETA;
}

createRoot(document.getElementById("root")!).render(<App />);
