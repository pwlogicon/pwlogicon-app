// Witty logistics insights for contextual tooltips
export const logisticsInsights = {
  // Shipping and transportation
  ftl: [
    "💡 Fun fact: A typical FTL truck can carry 26-34 pallets, or about 48,000 lbs. That's equivalent to 24 small cars!",
    "🚛 Did you know? FTL shipments are like dating exclusively - one truck, one customer, maximum efficiency!",
    "⚡ FTL tip: Direct routes save 15-30% on transit time compared to LTL consolidation stops.",
    "🎯 FTL secret: Premium service that's actually cost-effective for shipments over 12,000 lbs."
  ],
  
  ltl: [
    "📦 LTL wisdom: 'Less Than Truckload' but more than a headache when planned right!",
    "🧩 LTL is like a puzzle - multiple shipments sharing space, optimized to perfection.",
    "💰 Smart move: LTL can save 40-60% vs. FTL for smaller shipments under 10,000 lbs.",
    "🚀 LTL networks move 10+ billion shipments annually in the US alone!"
  ],

  reefer: [
    "❄️ Reefer magic: Maintains temps from -20°F to +70°F with NASA-level precision!",
    "🥶 Cool fact: Reefer units can freeze or thaw cargo mid-transit. Temperature control = profit protection!",
    "⚡ Reefer reality: Uses 20% more fuel but prevents 100% product loss for perishables.",
    "🌡️ Pro tip: Pre-cooling saves 15-20 minutes per stop and extends product shelf life."
  ],

  intermodal: [
    "🚂 Intermodal insight: Rail moves freight 4x more fuel-efficiently than trucks!",
    "🔄 Smart logistics: Combines rail's efficiency with truck's flexibility - best of both worlds.",
    "🌍 Green choice: Intermodal reduces CO2 emissions by 65% compared to truck-only transport.",
    "📈 Intermodal growth: 40% increase in usage over the past decade - the future is multimodal!"
  ],

  // Performance metrics
  onTime: [
    "⏰ Industry standard: 95%+ on-time delivery separates the pros from the amateurs.",
    "🎯 On-time delivery: The difference between a happy customer and a former customer!",
    "📊 Data point: Every 1% improvement in on-time delivery increases customer retention by 3%.",
    "⚡ Speed secret: Predictive analytics can improve on-time performance by 15-25%."
  ],

  cost: [
    "💡 Cost optimization: Route planning software can reduce fuel costs by 10-15%.",
    "📈 Hidden savings: Proper load consolidation can cut shipping costs by 20-30%.",
    "🎯 Smart logistics: Every mile saved in routing equals $1.50-$2.00 in operational savings.",
    "💰 Industry fact: Fuel represents 25-30% of total transportation costs."
  ],

  capacity: [
    "📦 Capacity crunch: Peak seasons can see 40% capacity shortages - plan ahead!",
    "🚛 Utilization wisdom: 85% capacity utilization is the sweet spot for profitability.",
    "⚡ Flexibility pays: Multi-modal capacity options reduce costs by 15-25%.",
    "📊 Market insight: Capacity constraints drive 60% of rate increases."
  ],

  // Partnerships and matching
  matching: [
    "🤝 Perfect match: Our AI considers 40+ factors to find your logistics soulmate!",
    "🎯 Match quality: Higher compatibility scores lead to 50% longer partnerships.",
    "⚡ Smart pairing: Geographic coverage overlap increases success rates by 35%.",
    "💡 Pro tip: Service type alignment is the #1 predictor of partnership success."
  ],

  partnership: [
    "🤝 Partnership power: Collaborative logistics reduce costs by 12-18% on average.",
    "🎯 Trust factor: Verified partners have 95% higher success rates.",
    "📈 Network effect: Each new quality partner increases opportunities by 25%.",
    "💡 Industry secret: Long-term partnerships outperform spot rates by 15-20%."
  ],

  savings: [
    "💰 Smart savings: PWLoGiCon members average 12% cost reduction in year one.",
    "📊 Efficiency gains: Shared networks reduce empty miles by 25-30%.",
    "🎯 ROI reality: Platform partnerships pay for themselves in 2-3 shipments.",
    "⚡ Optimization: Collaborative routing saves $0.15-0.25 per mile."
  ],

  // Technology and innovation
  ai: [
    "🤖 AI advantage: Machine learning improves matching accuracy by 89%.",
    "⚡ Predictive power: AI forecasts demand surges 48-72 hours in advance.",
    "🎯 Smart routing: AI optimization reduces planning time from hours to minutes.",
    "📈 Future-ready: AI-driven logistics show 35% better performance metrics."
  ],

  analytics: [
    "📊 Data drives success: Analytics-powered decisions are 75% more accurate.",
    "🎯 Performance insight: Real-time tracking improves customer satisfaction by 40%.",
    "💡 Smart metrics: KPI monitoring prevents 80% of potential service failures.",
    "⚡ Business intelligence: Data visualization speeds decision-making by 50%."
  ],

  // Geographic and regional
  midwest: [
    "🌾 Midwest advantage: Central location reduces average transit time by 1-2 days.",
    "🚛 Hub reality: Chicago processes 25% of all US rail-truck intermodal traffic.",
    "📦 Agricultural powerhouse: Midwest moves 40% of US grain and livestock.",
    "⚡ Strategic positioning: Midwest locations serve 70% of US population within 48 hours."
  ],

  westCoast: [
    "🌊 Pacific gateway: West Coast handles 65% of US-Asia trade volume.",
    "🚛 Import reality: LA/Long Beach ports process 40% of US container imports.",
    "⚡ Speed advantage: West Coast routing saves 3-5 days vs. East Coast for Asia shipments.",
    "📦 Tech corridor: California ships 35% of US high-tech products."
  ],

  eastCoast: [
    "🗽 Atlantic advantage: East Coast serves 60% of US population within 500 miles.",
    "📦 Manufacturing hub: Northeast produces 30% of US finished goods.",
    "⚡ European gateway: East Coast ports handle 70% of transatlantic trade.",
    "🚛 Density benefits: Higher population density reduces last-mile costs by 20%."
  ]
};

// Function to get random insight by category
export function getRandomInsight(category: keyof typeof logisticsInsights): string {
  const insights = logisticsInsights[category];
  if (!insights || insights.length === 0) {
    return "💡 Logistics wisdom: Every shipment tells a story of supply chain success!";
  }
  return insights[Math.floor(Math.random() * insights.length)];
}

// Function to get contextual insight based on multiple factors
export function getContextualInsight(
  serviceType?: string,
  region?: string,
  urgency?: string,
  context?: string
): string {
  // Priority order for insight selection
  if (serviceType) {
    const service = serviceType.toLowerCase() as keyof typeof logisticsInsights;
    if (logisticsInsights[service]) {
      return getRandomInsight(service);
    }
  }

  if (region && region.toLowerCase().includes('midwest')) {
    return getRandomInsight('midwest');
  }

  if (region && (region.toLowerCase().includes('california') || region.toLowerCase().includes('west'))) {
    return getRandomInsight('westCoast');
  }

  if (region && (region.toLowerCase().includes('east') || region.toLowerCase().includes('atlantic'))) {
    return getRandomInsight('eastCoast');
  }

  if (context) {
    const ctx = context.toLowerCase() as keyof typeof logisticsInsights;
    if (logisticsInsights[ctx]) {
      return getRandomInsight(ctx);
    }
  }

  // Default fallback insights
  const generalInsights = [
    "🚀 Logistics mastery: Efficiency isn't just about speed - it's about smart decisions!",
    "💡 Supply chain wisdom: The best logistics solutions are invisible to the customer.",
    "⚡ Pro tip: Flexibility and reliability are the twin pillars of logistics excellence.",
    "🎯 Industry insight: Great logistics turn challenges into competitive advantages.",
    "📈 Success formula: Right product + Right place + Right time = Happy customers!"
  ];

  return generalInsights[Math.floor(Math.random() * generalInsights.length)];
}