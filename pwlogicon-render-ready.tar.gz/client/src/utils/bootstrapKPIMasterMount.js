// Bootstrap KPI Master Dashboard mounting utility
import React from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import BootstrapKPIMasterDashboard from '../components/BootstrapKPIMasterDashboard';

// Global mounting function for Bootstrap integration
window.mountBootstrapKPIMasterDashboard = function(containerId, options = {}) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Container with ID "${containerId}" not found`);
    return;
  }

  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: 2,
        staleTime: 5 * 60 * 1000,
        refetchOnWindowFocus: false,
      },
    },
  });

  const root = createRoot(container);
  root.render(
    React.createElement(QueryClientProvider, { client: queryClient },
      React.createElement(BootstrapKPIMasterDashboard, {
        sid: options.sid || null,
        ...options
      })
    )
  );

  return {
    unmount: () => root.unmount(),
    update: (newOptions) => {
      root.render(
        React.createElement(QueryClientProvider, { client: queryClient },
          React.createElement(BootstrapKPIMasterDashboard, {
            sid: newOptions.sid || options.sid || null,
            ...options,
            ...newOptions
          })
        )
      );
    }
  };
};

// Auto-mount for Bootstrap elements
document.addEventListener('DOMContentLoaded', function() {
  const containers = document.querySelectorAll('[data-bootstrap-kpi-dashboard]');
  containers.forEach(container => {
    const sid = container.getAttribute('data-sid');
    
    window.mountBootstrapKPIMasterDashboard(container.id || `bootstrap-kpi-${Date.now()}`, {
      sid
    });
  });
});

// Vanilla JavaScript fallback for pure Bootstrap environments
window.createBootstrapKPIChart = function(containerId, kpiData) {
  const canvas = document.getElementById(containerId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  
  // Import Chart.js dynamically
  import('chart.js/auto').then(ChartModule => {
    const Chart = ChartModule.default;
    
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: kpiData.map(k => k.name.replace(' %', '').replace(' ($)', '')),
        datasets: [
          {
            label: 'Current',
            data: kpiData.map(k => k.current),
            backgroundColor: 'rgba(255, 159, 64, 0.7)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 2
          },
          {
            label: 'Target',
            data: kpiData.map(k => k.target),
            backgroundColor: 'rgba(255, 192, 0, 0.7)',
            borderColor: 'rgba(255, 192, 0, 1)',
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: 'PWLoGiCon Master Dashboard – Current vs. Target KPIs',
            font: {
              size: 14,
              weight: 'bold'
            }
          },
          legend: {
            position: 'top',
            labels: {
              usePointStyle: true,
              padding: 15
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            }
          },
          x: {
            grid: {
              display: false
            },
            ticks: {
              maxRotation: 45,
              font: {
                size: 10
              }
            }
          }
        }
      }
    });
  });
};

export default window.mountBootstrapKPIMasterDashboard;