// Global mounting utility for ComplianceBadge in EJS templates
// This allows the React component to be used in server-side rendered pages

window.mountComplianceBadge = function(containerId, userId, sid, options = {}) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Container with id '${containerId}' not found`);
    return;
  }

  // Fallback vanilla JS implementation for when React isn't available
  if (typeof React === 'undefined') {
    renderVanillaComplianceBadge(container, userId, sid, options);
    return;
  }

  // React implementation (when available)
  try {
    const ComplianceBadge = window.ComplianceBadge;
    if (ComplianceBadge) {
      const root = ReactDOM.createRoot(container);
      root.render(React.createElement(ComplianceBadge, {
        userId,
        sid,
        compact: options.compact || false,
        showDetails: options.showDetails !== false
      }));
    } else {
      renderVanillaComplianceBadge(container, userId, sid, options);
    }
  } catch (error) {
    console.error('Error mounting React ComplianceBadge:', error);
    renderVanillaComplianceBadge(container, userId, sid, options);
  }
};

function renderVanillaComplianceBadge(container, userId, sid, options) {
  // Set initial loading state
  container.innerHTML = `
    <span class="badge bg-secondary">
      <span class="spinner-border spinner-border-sm me-1" role="status"></span>
      Verifying...
    </span>
  `;

  // Fetch compliance data
  const url = sid ? `/api/compliance/${userId}?sid=${sid}` : `/api/compliance/${userId}`;
  
  fetch(url)
    .then(response => response.json())
    .then(compliance => {
      const statusClass = getBootstrapStatusClass(compliance.status);
      const statusIcon = getStatusIcon(compliance.status);
      
      let badgeHTML = `
        <div class="d-flex align-items-center gap-2">
          <span class="badge ${statusClass} d-flex align-items-center gap-1">
            ${statusIcon}
            <span>${compliance.status}</span>
            <span class="font-monospace">• ${compliance.score}%</span>
          </span>
      `;

      if (options.showDetails !== false) {
        badgeHTML += `
          <div class="d-flex align-items-center gap-1" style="font-size: 0.75rem; color: #6c757d;">
            <span class="${compliance.mcNumber === '✅' ? 'text-success' : 'text-danger'}">MC</span>
            <span class="${compliance.insuranceOnFile === '✅' ? 'text-success' : 'text-danger'}">INS</span>
            <span class="${compliance.dotCompliant === '✅' ? 'text-success' : 'text-danger'}">DOT</span>
          </div>
        `;
      }

      badgeHTML += '</div>';
      container.innerHTML = badgeHTML;
    })
    .catch(error => {
      console.error('Failed to fetch compliance data:', error);
      container.innerHTML = `
        <span class="badge bg-danger d-flex align-items-center gap-1">
          <i class="fas fa-exclamation-triangle"></i>
          <span>Error</span>
        </span>
      `;
    });
}

function getBootstrapStatusClass(status) {
  switch (status) {
    case 'Verified':
      return 'bg-success text-white';
    case 'Pending':
      return 'bg-warning text-dark';
    case 'Rejected':
      return 'bg-danger text-white';
    case 'Expired':
      return 'bg-secondary text-white';
    default:
      return 'bg-secondary text-white';
  }
}

function getStatusIcon(status) {
  switch (status) {
    case 'Verified':
      return '<i class="fas fa-shield-alt"></i>';
    case 'Pending':
      return '<i class="fas fa-clock"></i>';
    case 'Rejected':
    case 'Expired':
      return '<i class="fas fa-exclamation-triangle"></i>';
    default:
      return '<i class="fas fa-clock"></i>';
  }
}