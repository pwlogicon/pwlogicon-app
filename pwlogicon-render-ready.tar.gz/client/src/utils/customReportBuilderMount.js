// Global mounting utility for CustomReportBuilder in EJS templates
// Provides vanilla JavaScript fallback when React isn't available

window.mountCustomReportBuilder = function(containerId, sid, options = {}) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Container with id '${containerId}' not found`);
    return;
  }

  // Fallback vanilla JS implementation for EJS templates
  if (typeof React === 'undefined') {
    renderVanillaReportBuilder(container, sid, options);
    return;
  }

  // React implementation (when available)
  try {
    const CustomReportBuilder = window.CustomReportBuilder;
    if (CustomReportBuilder) {
      const root = ReactDOM.createRoot(container);
      root.render(React.createElement(CustomReportBuilder, { sid }));
    } else {
      renderVanillaReportBuilder(container, sid, options);
    }
  } catch (error) {
    console.error('Error mounting React CustomReportBuilder:', error);
    renderVanillaReportBuilder(container, sid, options);
  }
};

function renderVanillaReportBuilder(container, sid, options) {
  let type = 'performance';
  let format = 'json';
  let filters = { region: '', service: '' };

  const html = `
    <div class="card report-builder">
      <div class="card-header">
        <h5 class="card-title d-flex align-items-center gap-2">
          <i class="fas fa-chart-bar"></i>
          📊 Custom Report Builder
        </h5>
      </div>
      <div class="card-body">
        <div class="mb-3">
          <label for="report-type" class="form-label">Report Type</label>
          <select id="report-type" class="form-select">
            <option value="performance">Performance Analysis</option>
            <option value="cost">Cost Analysis</option>
            <option value="compliance">Compliance Summary</option>
            <option value="lane_performance">Lane Performance</option>
            <option value="carrier_analytics">Carrier Analytics</option>
          </select>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="region-filter" class="form-label">Region Filter</label>
            <select id="region-filter" class="form-select">
              <option value="">All Regions</option>
              <option value="midwest">Midwest</option>
              <option value="south">South</option>
              <option value="west">West</option>
              <option value="northeast">Northeast</option>
            </select>
          </div>
          <div class="col-md-6">
            <label for="service-filter" class="form-label">Service Filter</label>
            <select id="service-filter" class="form-select">
              <option value="">All Services</option>
              <option value="ftl">Full Truckload</option>
              <option value="ltl">Less Than Truckload</option>
              <option value="reefer">Refrigerated</option>
              <option value="intermodal">Intermodal</option>
            </select>
          </div>
        </div>

        <div class="mb-3">
          <label for="output-format" class="form-label">Output Format</label>
          <select id="output-format" class="form-select">
            <option value="json">View in App</option>
            <option value="csv">CSV Download</option>
            <option value="pdf">PDF Download</option>
            <option value="excel">Excel Download</option>
          </select>
        </div>

        <button id="generate-report-btn" class="btn btn-primary w-100">
          <i class="fas fa-download me-2"></i>
          📤 Generate Report
        </button>

        <div id="report-status" class="mt-3 d-none">
          <div class="alert alert-info d-flex align-items-center">
            <div class="spinner-border spinner-border-sm me-2" role="status"></div>
            <span>Generating report...</span>
          </div>
        </div>
      </div>
    </div>
  `;

  container.innerHTML = html;

  // Add event listeners
  const typeSelect = container.querySelector('#report-type');
  const regionSelect = container.querySelector('#region-filter');
  const serviceSelect = container.querySelector('#service-filter');
  const formatSelect = container.querySelector('#output-format');
  const generateBtn = container.querySelector('#generate-report-btn');
  const statusDiv = container.querySelector('#report-status');

  typeSelect.addEventListener('change', (e) => {
    type = e.target.value;
  });

  regionSelect.addEventListener('change', (e) => {
    filters.region = e.target.value;
  });

  serviceSelect.addEventListener('change', (e) => {
    filters.service = e.target.value;
  });

  formatSelect.addEventListener('change', (e) => {
    format = e.target.value;
  });

  generateBtn.addEventListener('click', async () => {
    generateBtn.disabled = true;
    statusDiv.classList.remove('d-none');

    try {
      const response = await fetch('/api/report/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, filters, format })
      });

      if (!response.ok) {
        throw new Error('Failed to generate report');
      }

      if (format === 'json') {
        const data = await response.json();
        statusDiv.innerHTML = `
          <div class="alert alert-success">
            <strong>Report Generated!</strong><br>
            ${data.title} is ready with ${data.data.length} records.
          </div>
        `;
      } else {
        // Handle file download
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `report_${type}_${new Date().toISOString().split('T')[0]}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        statusDiv.innerHTML = `
          <div class="alert alert-success">
            <strong>Download Started!</strong><br>
            Your ${format.toUpperCase()} report is downloading.
          </div>
        `;
      }
    } catch (error) {
      console.error('Error generating report:', error);
      statusDiv.innerHTML = `
        <div class="alert alert-danger">
          <strong>Error!</strong><br>
          Failed to generate report. Please try again.
        </div>
      `;
    } finally {
      generateBtn.disabled = false;
      setTimeout(() => {
        statusDiv.classList.add('d-none');
      }, 5000);
    }
  });
}