# Overview

PWLoGiCon is a comprehensive logistics intelligence platform designed to connect carriers, 3PLs, brokers, and shippers through AI-powered matchmaking and advanced geospatial visualization. The platform facilitates opportunity sharing, partnership formation, and transaction management within the logistics industry, operating on a commission-based monetization model. Key capabilities include interactive map visualization of logistics lanes, dual-role management for 3PL companies, comprehensive trust and verification systems, multi-carrier integration, advanced analytics, and robust API integrations with existing TMS/WMS systems. The business vision is to become the leading intelligence platform for logistics, offering a unique blend of AI-powered insights and real-time operational visibility to optimize supply chains and foster efficient partnerships.

## Recent Changes

**Date: 2025-02-02**
- Initialized Git repository for version control with comprehensive commit history
- Enhanced unified dashboard template with cleaner Bootstrap styling and streamlined KPI displays
- Implemented interactive geospatial heatmap with multi-layer visualization (volume, density, performance, cost)
- Created AI predictive analytics dashboard with machine learning insights and Chart.js visualizations
- All dashboards now use authentic PostgreSQL data with comprehensive lane analysis
- Platform confirmed fully operational with real-time GPS tracking and analytics integrations
- Professional contact established: Ian G James MBA, CEO PwLoGiCon Group

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite.
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS.
- **Routing**: Wouter for client-side routing with role-based protection.
- **State Management**: TanStack Query for server state management and caching.
- **Authentication**: Session-based authentication with OpenID Connect (OIDC) integration.
- **Component Mounting**: Global React component mounting system for EJS templates with vanilla JavaScript fallback.
- **UI/UX Decisions**: Professional styling with contextual tooltips for enhanced user experience, including witty logistics insights and smart positioning.

## Backend Architecture
- **Runtime**: Node.js with Express.js.
- **Database**: PostgreSQL with Drizzle ORM.
- **Authentication**: Passport.js with OpenID Connect strategy.
- **Session Management**: Express sessions stored in PostgreSQL.
- **API Architecture**: RESTful API design with centralized error handling, role-based access control, and custom logging middleware.

## Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect.
- **Schema Structure**: Includes tables for users (with role-based access), opportunities, partnerships, transactions, sessions, conversations, messages, and conversation participants.
- **Enums**: Strongly typed enums for various statuses and types (user roles, service types, etc.).

## System Design Choices
- **Enhanced Shipment Management**: Multi-carrier platform with real-time rate quotes, batch processing, and KPIs.
- **AI-Powered Partner Matching System**: 4-factor scoring algorithm for connecting logistics opportunities with partners, displaying match reasoning.
- **Contextual AI-Powered Partnership Recommendation Engine**: Utilizes GPT-4o for intelligent partnership analysis, strategic recommendations, and market intelligence.
- **Interactive Geospatial Heat Map**: Advanced network visualization with multi-layer analysis (volume, density, performance, cost), real-time node tracking, and regional metrics analysis. Both React and server-side EJS implementations.
- **Unified Workflow Dashboard**: End-to-end WMS→TMS visibility with real-time KPIs, operational monitoring, and automated handoff capabilities. Available in React and server-side EJS.
- **AI Predictive Analytics**: Advanced forecasting for capacity gaps, demand prediction, price optimization, and automated exception handling using machine learning models.
- **Predictive ETA Intelligence**: Machine learning-based transit time calculations with high accuracy, real-time confidence intervals, automated delay alerts, and cross-platform integration (React + EJS).
- **Transaction and Commission System**: Supports dual fee structures (flat fee and percentage of contract value) with automated calculation and payment processing.
- **Interactive Logistics Map Visualization**: Leaflet.js-based mapping system displaying real-time logistics lanes, density analysis, interactive route popups, and filtering.
- **Dual-Role Management System**: Allows 3PL companies to switch between service provider and requester roles with dedicated tracking and dashboards.
- **Comprehensive Trust & Verification Center**: KYC document management, identity verification, insurance tracking, dispute resolution, and performance metrics.
- **TMS/WMS API Integrations**: System for connecting major logistics management systems with real-time connection testing and automated data synchronization.
- **Real-Time Messaging System**: WebSocket-based platform for business communication, supporting threading, attachments, and notifications.
- **Real-Time GPS Fleet Tracking**: Comprehensive truck location monitoring with in-memory storage, automated simulation, dual view modes, and Google Maps integration.
- **External TMS Webhook Integration**: FourKites webhook receiver for unified shipment visibility and status mapping.
- **Multi-Platform TMS Integration**: Project44 API connectivity and a unified tracking dashboard combining GPS simulation, FourKites webhooks, and Project44 API data.
- **Enhanced Tracking Visualization**: Integrated tracking sources section with visual status indicators and system health monitoring.
- **Carrier Compliance Center**: Professional React component for MC number validation, insurance, safety rating, DOT compliance, and cargo coverage checks.
- **Server-Side Rendering**: Extensive use of EJS templates for server-side rendered pages, integrating data from SQLite and maintaining consistent styling.

# External Dependencies

## Core Infrastructure
- **Database**: Neon PostgreSQL serverless database.
- **Authentication**: Replit OIDC.

## Payment Processing
- **Stripe**: Complete payment infrastructure (payment intents, webhooks, commission processing).
- **React Stripe.js**: Frontend payment form components.

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework.
- **Radix UI**: Accessible, unstyled UI primitives.
- **Lucide React**: Icon library.
- **Shadcn/ui**: Pre-built component library.

## Development and Build Tools
- **TypeScript**: For type safety.
- **Vite**: Fast development server and optimized production builds.
- **ESBuild**: Fast JavaScript bundling.
- **Drizzle Kit**: Database migration and schema management.

## Third-party Services
- **OpenAI Integration**: GPT-4o for AI-powered recommendations and market analysis.
- **WebSocket Support**: Native WebSocket constructor for real-time communication.
- **Form Handling**: React Hook Form with Zod validation.
- **Date Utilities**: date-fns for date formatting and manipulation.
- **Mapping**: Leaflet.js for interactive map visualizations.
- **External TMS/Tracking APIs**: FourKites, Project44.